<?php

/* overall/layout-404.twig */
class __TwigTemplate_372bf94dd2a70401eaf5eb9970c922549b334cc67f4c52dba6cfb7a7e83f8749 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/font-awesome/css/font-awesome.css\" rel=\"stylesheet\">
    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"views/css/style.css\" rel=\"stylesheet\">
    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    ";
        // line 17
        $this->displayBlock('appHeader', $context, $blocks);
        // line 19
        echo "
    <title>";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body class=\"gray-bd\">
    ";
        // line 23
        $this->displayBlock('appBody', $context, $blocks);
        // line 25
        echo "

    ";
        // line 28
        echo "    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->

    <!-- BOOTSTRAP 4-->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\">
    </script>
    
    ";
        // line 36
        $this->displayBlock('appFooter', $context, $blocks);
        // line 38
        echo "

</body>
</html>";
    }

    // line 17
    public function block_appHeader($context, array $blocks = array())
    {
        // line 18
        echo "    ";
    }

    // line 23
    public function block_appBody($context, array $blocks = array())
    {
        // line 24
        echo "    ";
    }

    // line 36
    public function block_appFooter($context, array $blocks = array())
    {
        // line 37
        echo "    ";
    }

    public function getTemplateName()
    {
        return "overall/layout-404.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  93 => 36,  89 => 24,  86 => 23,  82 => 18,  79 => 17,  72 => 38,  70 => 36,  60 => 28,  56 => 25,  54 => 23,  48 => 20,  45 => 19,  43 => 17,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/layout-404.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layout-404.twig");
    }
}

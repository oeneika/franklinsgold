<?php

/* usuarios/usuarios.twig */
class __TwigTemplate_7703235c7bda7e8cc201a5b1ae93e8c4b66dfca287470c839a19ad7d0b9f30a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "usuarios/usuarios.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "usuarios/usuarios.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-user\"></i> Usuarios</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Usuarios</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">

                <a onclick=\"crearUsuario()\"class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-user\"></i> Crear Usuario</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Usuarios registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover dataTables-example\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 10));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            echo "  
                                            <tr>
                                                <td>1<td>
                                                <td>Alexander</td>
                                                <td>Jesus</td>
                                                <td>De Azevedo</td>
                                                <td>Ilarraza</td>
                                                <td>oeneika</td>
                                                <td>Masculino</td>
                                                <td>02121234567</td>
                                                <td>oeneikaphotos@gmail.com</td>
                                                <td>
                                                <a href=\"usuarios/editar/";
            // line 68
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "idusuario", array()), "html", null, true);
            echo "\" style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" data-target=\"#editarUsuario\"><i class=\"fa fa-sliders naranja\"></i></a>
                                                <a href=\"\" style=\"margin-left: 20px;font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 73
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
";
        // line 96
        $this->loadTemplate("usuarios/crear", "usuarios/usuarios.twig", 96)->display($context);
        // line 97
        $this->loadTemplate("usuarios/editar", "usuarios/usuarios.twig", 97)->display($context);
        // line 98
        $this->loadTemplate("overall/footer", "usuarios/usuarios.twig", 98)->display($context);
        // line 99
        echo "</div>
";
    }

    // line 102
    public function block_appFooter($context, array $blocks = array())
    {
        // line 103
        echo "    <script src=\"views/propios/js/usuarios/crear.js\"></script>
    <script src=\"views/propios/js/usuarios/editar.js\"></script>
    <script>
        \$(document).ready(function(){
            \$('.dataTables-example').DataTable({
                dom: '<\"html5buttons\"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            \$(win.document.body).addClass('white-bg');
                            \$(win.document.body).css('font-size', '10px');

                            \$(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });


        });
    </script>
";
    }

    public function getTemplateName()
    {
        return "usuarios/usuarios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 103,  159 => 102,  154 => 99,  152 => 98,  150 => 97,  148 => 96,  125 => 75,  118 => 73,  108 => 68,  90 => 56,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    {% include 'overall/header' %}
</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-user\"></i> Usuarios</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Usuarios</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">

                <a onclick=\"crearUsuario()\"class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-user\"></i> Crear Usuario</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Usuarios registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover dataTables-example\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            {% for u in 1..10 %}  
                                            <tr>
                                                <td>1<td>
                                                <td>Alexander</td>
                                                <td>Jesus</td>
                                                <td>De Azevedo</td>
                                                <td>Ilarraza</td>
                                                <td>oeneika</td>
                                                <td>Masculino</td>
                                                <td>02121234567</td>
                                                <td>oeneikaphotos@gmail.com</td>
                                                <td>
                                                <a href=\"usuarios/editar/{{ u.idusuario }}\" style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" data-target=\"#editarUsuario\"><i class=\"fa fa-sliders naranja\"></i></a>
                                                <a href=\"\" style=\"margin-left: 20px;font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            {% else %}
                                                 <tr><td>No hay resultados</td></tr>
                                            {% endfor %}
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
{% include 'usuarios/crear' %}
{% include 'usuarios/editar' %}
{% include 'overall/footer' %}
</div>
{% endblock %}

{% block appFooter %}
    <script src=\"views/propios/js/usuarios/crear.js\"></script>
    <script src=\"views/propios/js/usuarios/editar.js\"></script>
    <script>
        \$(document).ready(function(){
            \$('.dataTables-example').DataTable({
                dom: '<\"html5buttons\"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            \$(win.document.body).addClass('white-bg');
                            \$(win.document.body).css('font-size', '10px');

                            \$(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });


        });
    </script>
{% endblock %}
", "usuarios/usuarios.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\usuarios.twig");
    }
}

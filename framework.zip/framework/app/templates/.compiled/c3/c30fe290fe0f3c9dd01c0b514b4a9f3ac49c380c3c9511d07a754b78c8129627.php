<?php

/* overall/menu.twig */
class __TwigTemplate_e138cd9ab9e7b5935129f791b9ecc54c21728208ff6f4f4b564c8beb312ea14a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "        <nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
            <div class=\"sidebar-collapse\">
                <ul class=\"nav metismenu\" id=\"side-menu\">
                    <li class=\"nav-header\">
                        <div class=\"dropdown profile-element\"> <span>
                            <img alt=\"image\" class=\"img-circle\" src=\"views/img/profile_small.jpg\" />
                             </span>
                            <a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\">
                            <span class=\"clear\"> <span class=\"block m-t-xs\"> <strong class=\"font-bold\">Franklins Gold</strong>
                             </span> <span class=\"text-muted text-xs block\">Presidente Ejecutivo</span> </span> </a>
                        </div>
                        <div class=\"logo-element\">
                            <a href=\"home/\">FG</a>
                        </div>
                    </li>
                    <li class=\"\">
                        <a href=\"usuarios/\"><i class=\"fa fa-user\"></i> <span class=\"nav-label\">Usuarios</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"monedas/\"><i class=\"fa fa-money\"></i> <span class=\"nav-label\">Moneda</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"sucursal/\"><i class=\"fa fa-sun-o\"></i> <span class=\"nav-label\">Sucursal</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"transacciones/\"><i class=\"fa fa-line-chart\"></i> <span class=\"nav-label\">Transacciones</span></a>
                    </li>
                </ul>
            </div>
        </nav>";
    }

    public function getTemplateName()
    {
        return "overall/menu.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
            <div class=\"sidebar-collapse\">
                <ul class=\"nav metismenu\" id=\"side-menu\">
                    <li class=\"nav-header\">
                        <div class=\"dropdown profile-element\"> <span>
                            <img alt=\"image\" class=\"img-circle\" src=\"views/img/profile_small.jpg\" />
                             </span>
                            <a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\">
                            <span class=\"clear\"> <span class=\"block m-t-xs\"> <strong class=\"font-bold\">Franklins Gold</strong>
                             </span> <span class=\"text-muted text-xs block\">Presidente Ejecutivo</span> </span> </a>
                        </div>
                        <div class=\"logo-element\">
                            <a href=\"home/\">FG</a>
                        </div>
                    </li>
                    <li class=\"\">
                        <a href=\"usuarios/\"><i class=\"fa fa-user\"></i> <span class=\"nav-label\">Usuarios</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"monedas/\"><i class=\"fa fa-money\"></i> <span class=\"nav-label\">Moneda</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"sucursal/\"><i class=\"fa fa-sun-o\"></i> <span class=\"nav-label\">Sucursal</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"transacciones/\"><i class=\"fa fa-line-chart\"></i> <span class=\"nav-label\">Transacciones</span></a>
                    </li>
                </ul>
            </div>
        </nav>", "overall/menu.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\menu.twig");
    }
}

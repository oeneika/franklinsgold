<?php

/* sucursal/sucursal.twig */
class __TwigTemplate_8509257decfdfd9620def085920191227f8713ba68f4f6b6a362e1a9cf80d9dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "sucursal/sucursal.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "sucursal/sucursal.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-money\"></i> Sucursales</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Sucursales</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <a data-toggle=\"modal\" data-target=\"#crearSucursal\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-user\"></i> Crear Sucursal</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Sucursales registradas en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover dataTables-example\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Nombre</th>
                                            <th>Dirección</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["sucursal"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            if ((false != ($context["sucursal"] ?? null))) {
                echo "  
                                            <tr>
                                                <td>";
                // line 51
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "idsucursal", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 52
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "nombre", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 53
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "direccion", array()), "html", null, true);
                echo "</td>
                                                <td>
                                                <a href=\"\" style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" data-target=\"#editarSucursal\"><i class=\"fa fa-sliders naranja\"></i></a>
                                                <a href=\"\" style=\"margin-left: 20px;font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            ";
                $context['_iterated'] = true;
            }
        }
        if (!$context['_iterated']) {
            // line 60
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Nombre</th>
                                            <th>Dirección</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>

";
        // line 79
        $this->loadTemplate("sucursal/crear", "sucursal/sucursal.twig", 79)->display($context);
        // line 80
        $this->loadTemplate("sucursal/editar", "sucursal/sucursal.twig", 80)->display($context);
        // line 81
        $this->loadTemplate("overall/footer", "sucursal/sucursal.twig", 81)->display($context);
        // line 82
        echo "</div>
";
    }

    // line 85
    public function block_appFooter($context, array $blocks = array())
    {
        // line 86
        echo "    <script>
        \$(document).ready(function(){
            \$('.dataTables-example').DataTable({
                dom: '<\"html5buttons\"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            \$(win.document.body).addClass('white-bg');
                            \$(win.document.body).css('font-size', '10px');

                            \$(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });


        });
    </script>


";
    }

    public function getTemplateName()
    {
        return "sucursal/sucursal.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 86,  150 => 85,  145 => 82,  143 => 81,  141 => 80,  139 => 79,  120 => 62,  113 => 60,  100 => 53,  96 => 52,  92 => 51,  83 => 49,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "sucursal/sucursal.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\sucursal\\sucursal.twig");
    }
}

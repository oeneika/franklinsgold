<?php

/* sucursal/crear.twig */
class __TwigTemplate_1479a20fc135ebed12d29d0e7c959062a6e3f813b75075e15d26347de5349beb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearSucursal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                                    <div class=\"modal-content animated flipInY\">
                                        <div class=\"modal-header\">
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                                            <h4 class=\"modal-title\">Creación de Sucursal</h4>
                                            <small class=\"font-bold\">Franklins Gold</small>
                                        </div>
                                        <div class=\"modal-body\">
                                            <form id=\"crear_sucursal_form\">
                                                <div class=\"row\">
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Dirección</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                                            <button type=\"button\" id=\"crearsucursalbtn\" class=\"btn btn-primary\">Guardar</button>
                                        </div>
                                    </div>
            </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "sucursal/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "sucursal/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\sucursal\\crear.twig");
    }
}

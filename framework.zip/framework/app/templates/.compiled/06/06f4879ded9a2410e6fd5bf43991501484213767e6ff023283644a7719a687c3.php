<?php

/* monedas/editar.twig */
class __TwigTemplate_9165674384453610c0559f84a9e297d183320889e634cc7a86d04464a16c46bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarMonedas\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                                    <div class=\"modal-content animated flipInY\">
                                        <div class=\"modal-header\">
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                                            <h4 class=\"modal-title\">Edición de Monedas</h4>
                                            <small class=\"font-bold\">Franklins Gold</small>
                                        </div>
                                        <div class=\"modal-body\">
                                            <form action=\"\">
                                                <div class=\"row\">
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Elaboración</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Diametro</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Espesor</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Composición</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=\"row\">
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"usuario\" class=\"control-label mb-1\">Peso</label>
                                                            <input id=\"usuario\" name=\"usuario\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"telefono\" class=\"control-label mb-1\">Origen</label>
                                                            <input id=\"telefono\" name=\"telefono\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                                            <button type=\"button\" class=\"btn btn-primary\">Guardar</button>
                                        </div>
                                    </div>
            </div>
</div>";
    }

    public function getTemplateName()
    {
        return "monedas/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"editarMonedas\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                                    <div class=\"modal-content animated flipInY\">
                                        <div class=\"modal-header\">
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                                            <h4 class=\"modal-title\">Edición de Monedas</h4>
                                            <small class=\"font-bold\">Franklins Gold</small>
                                        </div>
                                        <div class=\"modal-body\">
                                            <form action=\"\">
                                                <div class=\"row\">
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Elaboración</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Diametro</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Espesor</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-3 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"cc-payment\" class=\"control-label mb-1\">Composición</label>
                                                            <input id=\"cc-pament\" name=\"cc-payment\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=\"row\">
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"usuario\" class=\"control-label mb-1\">Peso</label>
                                                            <input id=\"usuario\" name=\"usuario\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"telefono\" class=\"control-label mb-1\">Origen</label>
                                                            <input id=\"telefono\" name=\"telefono\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                                            <button type=\"button\" class=\"btn btn-primary\">Guardar</button>
                                        </div>
                                    </div>
            </div>
</div>", "monedas/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\monedas\\editar.twig");
    }
}

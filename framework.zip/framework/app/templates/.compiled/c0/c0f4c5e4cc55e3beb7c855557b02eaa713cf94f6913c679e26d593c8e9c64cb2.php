<?php

/* monedas/monedas.twig */
class __TwigTemplate_033c12dbcc381ec863729157733fea74e02bc65baafec42ca1e6eb0473ef7f40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "monedas/monedas.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "monedas/monedas.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-money\"></i> Monedas</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Monedas</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <a href=\"crear/\" data-toggle=\"modal\" data-target=\"#crearMonedas\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-user\"></i> Crear Moneda</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Monedas registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover dataTables-example\" >
                                        <thead>
                                        <tr>
                                            <th>Codigo</th>
                                            <th>Fecha Elaboración</th>
                                            <th>Diametro</th>
                                            <th>Espesor</th>
                                            <th>Composición</th>
                                            <th>Peso</th>
                                            <th>Origen</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["monedas"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            if ((false != ($context["monedas"] ?? null))) {
                echo "  
                                            <tr>
                                                <td>";
                // line 55
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "codigo", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 56
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "fecha_elaboracion", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 57
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "diametro", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 58
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "espesor", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 59
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "composicion", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 60
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "peso", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "origen_idorigen", array()), "html", null, true);
                echo "</td>
                                                <td>
                                                <a href=\"\" style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" data-target=\"#editarMonedas\"><i class=\"fa fa-sliders naranja\"></i></a>
                                                <a href=\"\" style=\"margin-left: 20px;font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            ";
                $context['_iterated'] = true;
            }
        }
        if (!$context['_iterated']) {
            // line 68
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Codigo</th>
                                            <th>Fecha Elaboración</th>
                                            <th>Diametro</th>
                                            <th>Espesor</th>
                                            <th>Composición</th>
                                            <th>Peso</th>
                                            <th>Origen</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>

";
        // line 90
        $this->loadTemplate("monedas/crear", "monedas/monedas.twig", 90)->display($context);
        // line 91
        $this->loadTemplate("monedas/editar", "monedas/monedas.twig", 91)->display($context);
        // line 92
        $this->loadTemplate("overall/footer", "monedas/monedas.twig", 92)->display($context);
        // line 93
        echo "</div>
";
    }

    // line 96
    public function block_appFooter($context, array $blocks = array())
    {
        // line 97
        echo "    <script>
        \$(document).ready(function(){
            \$('.dataTables-example').DataTable({
                dom: '<\"html5buttons\"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            \$(win.document.body).addClass('white-bg');
                            \$(win.document.body).css('font-size', '10px');

                            \$(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });


        });
    </script>


";
    }

    public function getTemplateName()
    {
        return "monedas/monedas.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 97,  173 => 96,  168 => 93,  166 => 92,  164 => 91,  162 => 90,  140 => 70,  133 => 68,  120 => 61,  116 => 60,  112 => 59,  108 => 58,  104 => 57,  100 => 56,  96 => 55,  87 => 53,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "monedas/monedas.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\monedas\\monedas.twig");
    }
}

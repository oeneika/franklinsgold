<?php

/* overall/header.twig */
class __TwigTemplate_a2e2472682ea841d4c051185bec7b0933470fddae0d7b763536b6219b410de9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header oculto\">
            <a class=\"navbar-minimalize minimalize-styl-2 btn btn-warning \" href=\"#\"><i class=\"fa fa-bars\"></i> </a> 
        </div>
        <ul class=\"nav navbar-top-links navbar-right\">
            <li>
                <a href=\"login.html\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
</nav>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/header.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\header.twig");
    }
}

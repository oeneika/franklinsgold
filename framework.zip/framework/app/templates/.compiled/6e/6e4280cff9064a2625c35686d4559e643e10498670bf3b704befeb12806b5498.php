<?php

/* overall/layout.twig */
class __TwigTemplate_b1e8058f75be4483ae10bff593ef64b0a054db44b87180d1638412da8c0172c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/font-awesome/css/font-awesome.css\" rel=\"stylesheet\">

    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    <link href=\"views/css/plugins/dataTables/datatables.min.css\" rel=\"stylesheet\">

    <!-- Gritter -->
    <link href=\"views/js/plugins/gritter/jquery.gritter.css\" rel=\"stylesheet\">

    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"views/css/style.css\" rel=\"stylesheet\">

    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    ";
        // line 27
        $this->displayBlock('appHeader', $context, $blocks);
        // line 29
        echo "
    <title>";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body class=\"pace-done\">
    <div id=\"wrapper\">
    ";
        // line 34
        $this->loadTemplate("overall/menu", "overall/layout.twig", 34)->display($context);
        // line 35
        echo "    
    ";
        // line 36
        $this->displayBlock('appBody', $context, $blocks);
        // line 38
        echo "    </div>


    ";
        // line 42
        echo "    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->

    <!-- BOOTSTRAP 4-->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\">
    </script>

    <script src=\"views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Flot -->
    <script src=\"views/js/plugins/flot/jquery.flot.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.tooltip.min.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.spline.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.resize.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.pie.js\"></script>

    <!-- Peity -->
    <script src=\"views/js/plugins/peity/jquery.peity.min.js\"></script>
    <script src=\"views/js/demo/peity-demo.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"views/js/inspinia.js\"></script>
    <script src=\"views/js/plugins/pace/pace.min.js\"></script>

    <!-- jQuery UI -->
    <script src=\"views/js/plugins/jquery-ui/jquery-ui.min.js\"></script>

    <!-- GITTER -->
    <script src=\"views/js/plugins/gritter/jquery.gritter.min.js\"></script>

    <!-- Jvectormap -->
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js\"></script>
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>

    <!-- Sparkline -->
    <script src=\"views/js/plugins/sparkline/jquery.sparkline.min.js\"></script>

    <!-- Sparkline demo data  -->
    <script src=\"views/js/demo/sparkline-demo.js\"></script>

    <!-- ChartJS-->
    <script src=\"views/js/plugins/chartJs/Chart.min.js\"></script>

    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    <script src=\"views/js/plugins/dataTables/datatables.min.js\"></script>

    
    ";
        // line 93
        $this->displayBlock('appFooter', $context, $blocks);
        // line 95
        echo "

</body>
</html>";
    }

    // line 27
    public function block_appHeader($context, array $blocks = array())
    {
        // line 28
        echo "    ";
    }

    // line 36
    public function block_appBody($context, array $blocks = array())
    {
        // line 37
        echo "    ";
    }

    // line 93
    public function block_appFooter($context, array $blocks = array())
    {
        // line 94
        echo "    ";
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 94,  153 => 93,  149 => 37,  146 => 36,  142 => 28,  139 => 27,  132 => 95,  130 => 93,  77 => 42,  72 => 38,  70 => 36,  67 => 35,  65 => 34,  58 => 30,  55 => 29,  53 => 27,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    {# Formato #}
    {{ base_assets()|raw }}
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/font-awesome/css/font-awesome.css\" rel=\"stylesheet\">

    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    <link href=\"views/css/plugins/dataTables/datatables.min.css\" rel=\"stylesheet\">

    <!-- Gritter -->
    <link href=\"views/js/plugins/gritter/jquery.gritter.css\" rel=\"stylesheet\">

    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"views/css/style.css\" rel=\"stylesheet\">

    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    {% block appHeader %}
    {% endblock %}

    <title>{{ config.build.name }}</title>
</head>
<body class=\"pace-done\">
    <div id=\"wrapper\">
    {% include 'overall/menu' %}
    
    {% block appBody %}
    {% endblock %}
    </div>


    {# Sólamente necesario para facilitar las peticiones AJAX del generador, puede eliminarse #}
    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->

    <!-- BOOTSTRAP 4-->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\">
    </script>

    <script src=\"views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Flot -->
    <script src=\"views/js/plugins/flot/jquery.flot.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.tooltip.min.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.spline.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.resize.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.pie.js\"></script>

    <!-- Peity -->
    <script src=\"views/js/plugins/peity/jquery.peity.min.js\"></script>
    <script src=\"views/js/demo/peity-demo.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"views/js/inspinia.js\"></script>
    <script src=\"views/js/plugins/pace/pace.min.js\"></script>

    <!-- jQuery UI -->
    <script src=\"views/js/plugins/jquery-ui/jquery-ui.min.js\"></script>

    <!-- GITTER -->
    <script src=\"views/js/plugins/gritter/jquery.gritter.min.js\"></script>

    <!-- Jvectormap -->
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js\"></script>
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>

    <!-- Sparkline -->
    <script src=\"views/js/plugins/sparkline/jquery.sparkline.min.js\"></script>

    <!-- Sparkline demo data  -->
    <script src=\"views/js/demo/sparkline-demo.js\"></script>

    <!-- ChartJS-->
    <script src=\"views/js/plugins/chartJs/Chart.min.js\"></script>

    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    <script src=\"views/js/plugins/dataTables/datatables.min.js\"></script>

    
    {% block appFooter %}
    {% endblock %}


</body>
</html>", "overall/layout.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layout.twig");
    }
}

<?php

/* overall/header.twig */
class __TwigTemplate_c589ab33cf8be1cc7fbe6573e7dfc764b8ef2c837f1de5fea2b279fb59b3fe2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header oculto\">
            <a class=\"navbar-minimalize minimalize-styl-2 btn btn-warning \" href=\"#\"><i class=\"fa fa-bars\"></i> </a> 
        </div>
        <ul class=\"nav navbar-top-links navbar-right\">
            <li>
                <a href=\"login.html\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
</nav>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header oculto\">
            <a class=\"navbar-minimalize minimalize-styl-2 btn btn-warning \" href=\"#\"><i class=\"fa fa-bars\"></i> </a> 
        </div>
        <ul class=\"nav navbar-top-links navbar-right\">
            <li>
                <a href=\"login.html\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
</nav>", "overall/header.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\header.twig");
    }
}

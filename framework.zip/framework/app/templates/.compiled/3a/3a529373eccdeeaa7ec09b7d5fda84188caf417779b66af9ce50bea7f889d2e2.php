<?php

/* usuarios/usuarios.twig */
class __TwigTemplate_e3ea7a2a38e810c1e997ec775d6d1340b7c10344169b463eecaa334ffe929722 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "usuarios/usuarios.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "usuarios/usuarios.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-user\"></i> Usuarios</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Usuarios</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">

                <a data-toggle=\"modal\" data-target=\"#crearUsuario\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-user\"></i> Crear Usuario</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Usuarios registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover dataTables-example\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["usuario"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            if ((false != ($context["usuario"] ?? null))) {
                echo "  
                                            <tr>
                                                <td>";
                // line 58
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "idusuario", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 59
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_nombre", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 60
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_nombre", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_apellido", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_apellido", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "usuario", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 64
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "sexo", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 65
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "telefono", array()), "html", null, true);
                echo "</td>
                                                <td>";
                // line 66
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "correo", array()), "html", null, true);
                echo "</td>
                                                <td>
                                                <a href=\"\" style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" data-target=\"#editarUsuario\"><i class=\"fa fa-sliders naranja\"></i></a>
                                                <a href=\"\" style=\"margin-left: 20px;font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            ";
                $context['_iterated'] = true;
            }
        }
        if (!$context['_iterated']) {
            // line 73
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Télefono</th>
                                            <th>Correo</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
";
        // line 96
        $this->loadTemplate("usuarios/crear", "usuarios/usuarios.twig", 96)->display($context);
        // line 97
        $this->loadTemplate("usuarios/editar", "usuarios/usuarios.twig", 97)->display($context);
        // line 98
        $this->loadTemplate("overall/footer", "usuarios/usuarios.twig", 98)->display($context);
        // line 99
        echo "</div>
";
    }

    // line 102
    public function block_appFooter($context, array $blocks = array())
    {
        // line 103
        echo "    <script>
        \$(document).ready(function(){
            \$('.dataTables-example').DataTable({
                dom: '<\"html5buttons\"B>lTfgitp',
                buttons: [
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            \$(win.document.body).addClass('white-bg');
                            \$(win.document.body).css('font-size', '10px');

                            \$(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });


        });
    </script>


";
    }

    public function getTemplateName()
    {
        return "usuarios/usuarios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 103,  185 => 102,  180 => 99,  178 => 98,  176 => 97,  174 => 96,  151 => 75,  144 => 73,  131 => 66,  127 => 65,  123 => 64,  119 => 63,  115 => 62,  111 => 61,  107 => 60,  103 => 59,  99 => 58,  90 => 56,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "usuarios/usuarios.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\usuarios.twig");
    }
}

<?php

/* overall/layout-404.twig */
class __TwigTemplate_302d93561954cdd6edb45ffa4f78ebe2c2d18ad12bcae011f7391ef4241773b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"views/propios/img/favicon/favicon (1).ico\">
    <link rel=\"apple-touch-icon-precomposed\" href=\"views/propios/img/favicon/favicon (3).png\">
    <meta name=\"msapplication-TileColor\" content=\"#ffffff\" />
    <meta name=\"msapplication-TileImage\" content=\"views/propios/img/favicon/favicon (2).png\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/font-awesome/css/font-awesome.css\" rel=\"stylesheet\">
    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/4.4.9/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />

    <link href=\"views/css/style.css\" rel=\"stylesheet\">
    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">
    <link href=\"views/propios/css/estilo-register.css\" rel=\"stylesheet\">
    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    ";
        // line 27
        $this->displayBlock('appHeader', $context, $blocks);
        // line 29
        echo "
    <title>";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body class=\"gray-bd\">
    ";
        // line 33
        $this->displayBlock('appBody', $context, $blocks);
        // line 35
        echo "

    ";
        // line 38
        echo "    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->

    <!-- BOOTSTRAP 4-->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\">
    </script>
    
    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    ";
        // line 49
        $this->displayBlock('appFooter', $context, $blocks);
        // line 51
        echo "

</body>
</html>";
    }

    // line 27
    public function block_appHeader($context, array $blocks = array())
    {
        // line 28
        echo "    ";
    }

    // line 33
    public function block_appBody($context, array $blocks = array())
    {
        // line 34
        echo "    ";
    }

    // line 49
    public function block_appFooter($context, array $blocks = array())
    {
        // line 50
        echo "    ";
    }

    public function getTemplateName()
    {
        return "overall/layout-404.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 50,  106 => 49,  102 => 34,  99 => 33,  95 => 28,  92 => 27,  85 => 51,  83 => 49,  70 => 38,  66 => 35,  64 => 33,  58 => 30,  55 => 29,  53 => 27,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    {# Formato #}
    {{ base_assets()|raw }}
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"views/propios/img/favicon/favicon (1).ico\">
    <link rel=\"apple-touch-icon-precomposed\" href=\"views/propios/img/favicon/favicon (3).png\">
    <meta name=\"msapplication-TileColor\" content=\"#ffffff\" />
    <meta name=\"msapplication-TileImage\" content=\"views/propios/img/favicon/favicon (2).png\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/font-awesome/css/font-awesome.css\" rel=\"stylesheet\">
    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/4.4.9/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />

    <link href=\"views/css/style.css\" rel=\"stylesheet\">
    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">
    <link href=\"views/propios/css/estilo-register.css\" rel=\"stylesheet\">
    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    {% block appHeader %}
    {% endblock %}

    <title>{{ config.build.name }}</title>
</head>
<body class=\"gray-bd\">
    {% block appBody %}
    {% endblock %}


    {# Sólamente necesario para facilitar las peticiones AJAX del generador, puede eliminarse #}
    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->

    <!-- BOOTSTRAP 4-->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\">
    </script>
    
    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    {% block appFooter %}
    {% endblock %}


</body>
</html>", "overall/layout-404.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layout-404.twig");
    }
}

<?php

/* login/lostpass.twig */
class __TwigTemplate_dde592b4f57b35b00ad12b8692ce41e1e475757dfdae37a65193c90b985d3003 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"lostpassModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content animated flipInY\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                    <h4 class=\"modal-title\">Recuperar Contraseña</h4>
                    <small class=\"font-bold\">Franklins Gold</small>
                </div>
                <div class=\"modal-body\">
                    <form role=\"form\" id=\"lostpass_form\">
                        <div class=\"row\">
                            <div class=\"col-md-12 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"nombre\" class=\"control-label mb-1\">E-mail</label>
                                    <input name=\"email\" type=\"text\" class=\"form-control\" style=\"background-color:white; color:black;\" aria-required=\"true\" aria-invalid=\"false\">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                    <button type=\"button\" id=\"recuperarbtn\" class=\"btn btn-primary\">Recuperar</button>
                </div>
            </div>
        </div>
</div>";
    }

    public function getTemplateName()
    {
        return "login/lostpass.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"lostpassModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content animated flipInY\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                    <h4 class=\"modal-title\">Recuperar Contraseña</h4>
                    <small class=\"font-bold\">Franklins Gold</small>
                </div>
                <div class=\"modal-body\">
                    <form role=\"form\" id=\"lostpass_form\">
                        <div class=\"row\">
                            <div class=\"col-md-12 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"nombre\" class=\"control-label mb-1\">E-mail</label>
                                    <input name=\"email\" type=\"text\" class=\"form-control\" style=\"background-color:white; color:black;\" aria-required=\"true\" aria-invalid=\"false\">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                    <button type=\"button\" id=\"recuperarbtn\" class=\"btn btn-primary\">Recuperar</button>
                </div>
            </div>
        </div>
</div>", "login/lostpass.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\login\\lostpass.twig");
    }
}

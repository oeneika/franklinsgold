<?php

/* monedas/editar.twig */
class __TwigTemplate_9165674384453610c0559f84a9e297d183320889e634cc7a86d04464a16c46bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarMoneda\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Monedas</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"editar_moneda_form_0CR3ND\">
                    <input id=\"id_codigo\" name=\"codigo\" type=\"hidden\">
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"diametro\" class=\"control-label mb-1\">Diámetro<span>*</span></label>
                                <input id=\"id_diametro\" name=\"diametro\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"espesor\" class=\"control-label mb-1\">Espesor<span>*</span></label>
                                <input id=\"id_espesor\" name=\"espesor\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"composicion\" class=\"control-label mb-1\">Composición<span>*</span></label>
                                <select class=\"form-control selector_compo\" id=\"id_composicion\" name=\"composicion\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                    <option selected disabled value></option> 
                                                                     
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"peso\" class=\"control-label mb-1\">Peso<span>*</span></label>
                                <input id=\"id_peso\" name=\"peso\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"origen\" class=\"control-label mb-1\">Origen<span>*</span></label>      
                                <select class=\"form-control selector_origenes\" name=\"id_origen\"  aria-required=\"true\" aria-invalid=\"false\">
                                    <option selected disabled value></option>                                  
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button id=\"editar_moneda_0CR3ND\" type=\"button\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "monedas/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"editarMoneda\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Monedas</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"editar_moneda_form_0CR3ND\">
                    <input id=\"id_codigo\" name=\"codigo\" type=\"hidden\">
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"diametro\" class=\"control-label mb-1\">Diámetro<span>*</span></label>
                                <input id=\"id_diametro\" name=\"diametro\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"espesor\" class=\"control-label mb-1\">Espesor<span>*</span></label>
                                <input id=\"id_espesor\" name=\"espesor\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"composicion\" class=\"control-label mb-1\">Composición<span>*</span></label>
                                <select class=\"form-control selector_compo\" id=\"id_composicion\" name=\"composicion\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                    <option selected disabled value></option> 
                                                                     
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"peso\" class=\"control-label mb-1\">Peso<span>*</span></label>
                                <input id=\"id_peso\" name=\"peso\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"origen\" class=\"control-label mb-1\">Origen<span>*</span></label>      
                                <select class=\"form-control selector_origenes\" name=\"id_origen\"  aria-required=\"true\" aria-invalid=\"false\">
                                    <option selected disabled value></option>                                  
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button id=\"editar_moneda_0CR3ND\" type=\"button\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>", "monedas/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\monedas\\editar.twig");
    }
}

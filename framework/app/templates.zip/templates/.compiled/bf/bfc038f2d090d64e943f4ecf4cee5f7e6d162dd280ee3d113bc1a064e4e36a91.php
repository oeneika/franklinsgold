<?php

/* overall/layout-landing.twig */
class __TwigTemplate_ada68e5dc9cb5ef270429ef98b30ded97db802a9878754bd14eb23921aa7be5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <!-- Bootstrap core CSS -->
    <link href=\"../views/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- Animation CSS -->
    <link href=\"../views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"../views/font-awesome/css/font-awesome.min.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"../views/css/style.css\" rel=\"stylesheet\">

    <link href=\"../views/propios/css/estilo-landing.css\" rel=\"stylesheet\">

    <style>
    .landing-page .navbar-default .nav li a{
        color: #232323;
    }
    </style>

    ";
        // line 28
        $this->displayBlock('appHeader', $context, $blocks);
        // line 30
        echo "
    <title>";
        // line 31
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body id=\"page-top\" class=\"landing-page no-skin-config\">
    ";
        // line 34
        $this->displayBlock('appBody', $context, $blocks);
        // line 36
        echo "
    <!-- Mainly scripts -->
    <script src=\"https://code.jquery.com/jquery-3.3.1.min.js\"></script>
    <script src=\"../views/js/popper.min.js\"></script>
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>

    <script src=\"../views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"../views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"../views/js/inspinia.js\"></script>
    <script src=\"../views/js/plugins/pace/pace.min.js\"></script>
    <script src=\"../views/js/plugins/wow/wow.min.js\"></script>

    <script>

    \$(document).ready(function () {

        \$('body').scrollspy({
            target: '#navbar',
            offset: 80
        });

        // Page scrolling feature
        \$('a.page-scroll').bind('click', function(event) {
            var link = \$(this);
            \$('html, body').stop().animate({
                scrollTop: \$(link.attr('href')).offset().top - 50
            }, 500);
            event.preventDefault();
            \$(\"#navbar\").collapse('hide');
        });
    });

    var cbpAnimatedHeader = (function() {
        var docElem = document.documentElement,
                header = document.querySelector( '.navbar-default' ),
                didScroll = false,
                changeHeaderOn = 200;
        function init() {
            window.addEventListener( 'scroll', function( event ) {
                if( !didScroll ) {
                    didScroll = true;
                    setTimeout( scrollPage, 250 );
                }
            }, false );
        }
        function scrollPage() {
            var sy = scrollY();
            if ( sy >= changeHeaderOn ) {
                \$(header).addClass('navbar-scroll')
            }
            else {
                \$(header).removeClass('navbar-scroll')
            }
            didScroll = false;
        }
        function scrollY() {
            return window.pageYOffset || docElem.scrollTop;
        }
        init();

    })();

    // Activate WOW.js plugin for animation on scrol
    new WOW().init();

</script>

    ";
        // line 105
        $this->displayBlock('appFooter', $context, $blocks);
        // line 107
        echo "
</body>
</html>";
    }

    // line 28
    public function block_appHeader($context, array $blocks = array())
    {
        // line 29
        echo "    ";
    }

    // line 34
    public function block_appBody($context, array $blocks = array())
    {
        // line 35
        echo "    ";
    }

    // line 105
    public function block_appFooter($context, array $blocks = array())
    {
        // line 106
        echo "    ";
    }

    public function getTemplateName()
    {
        return "overall/layout-landing.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 106,  157 => 105,  153 => 35,  150 => 34,  146 => 29,  143 => 28,  137 => 107,  135 => 105,  64 => 36,  62 => 34,  56 => 31,  53 => 30,  51 => 28,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <!-- Bootstrap core CSS -->
    <link href=\"../views/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- Animation CSS -->
    <link href=\"../views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"../views/font-awesome/css/font-awesome.min.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"../views/css/style.css\" rel=\"stylesheet\">

    <link href=\"../views/propios/css/estilo-landing.css\" rel=\"stylesheet\">

    <style>
    .landing-page .navbar-default .nav li a{
        color: #232323;
    }
    </style>

    {% block appHeader %}
    {% endblock %}

    <title>{{ config.build.name }}</title>
</head>
<body id=\"page-top\" class=\"landing-page no-skin-config\">
    {% block appBody %}
    {% endblock %}

    <!-- Mainly scripts -->
    <script src=\"https://code.jquery.com/jquery-3.3.1.min.js\"></script>
    <script src=\"../views/js/popper.min.js\"></script>
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>

    <script src=\"../views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"../views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"../views/js/inspinia.js\"></script>
    <script src=\"../views/js/plugins/pace/pace.min.js\"></script>
    <script src=\"../views/js/plugins/wow/wow.min.js\"></script>

    <script>

    \$(document).ready(function () {

        \$('body').scrollspy({
            target: '#navbar',
            offset: 80
        });

        // Page scrolling feature
        \$('a.page-scroll').bind('click', function(event) {
            var link = \$(this);
            \$('html, body').stop().animate({
                scrollTop: \$(link.attr('href')).offset().top - 50
            }, 500);
            event.preventDefault();
            \$(\"#navbar\").collapse('hide');
        });
    });

    var cbpAnimatedHeader = (function() {
        var docElem = document.documentElement,
                header = document.querySelector( '.navbar-default' ),
                didScroll = false,
                changeHeaderOn = 200;
        function init() {
            window.addEventListener( 'scroll', function( event ) {
                if( !didScroll ) {
                    didScroll = true;
                    setTimeout( scrollPage, 250 );
                }
            }, false );
        }
        function scrollPage() {
            var sy = scrollY();
            if ( sy >= changeHeaderOn ) {
                \$(header).addClass('navbar-scroll')
            }
            else {
                \$(header).removeClass('navbar-scroll')
            }
            didScroll = false;
        }
        function scrollY() {
            return window.pageYOffset || docElem.scrollTop;
        }
        init();

    })();

    // Activate WOW.js plugin for animation on scrol
    new WOW().init();

</script>

    {% block appFooter %}
    {% endblock %}

</body>
</html>", "overall/layout-landing.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layout-landing.twig");
    }
}

<?php

/* rango/crear.twig */
class __TwigTemplate_896770d3c324be32c88169fbd2219facc80c37f89eab6ee8f032388156053479 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearRango\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Rango</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form role=\"form\" id=\"crear_rango_form\">
                    <div class=\"row\">

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"nombre\" class=\"control-label mb-1\">Nombre</label>
                                <input name=\"nombre_rango\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                            </div>
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"monto_diario\" class=\"control-label mb-1\">Monto diario(Dólares)</label>
                                <input name=\"monto_diario\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                            </div>
                        </div>

                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearrangobtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "rango/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "rango/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\rango\\crear.twig");
    }
}

<?php

/* usuarios/documentos.twig */
class __TwigTemplate_65d39fef6424a08f73a033fdd319adf8c4be55e5f4cc7d6ca0dbe3a0279655ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"verDocumentosModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Documentos del Usuario</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover\" >
                        <thead>
                        <tr>
                            <th>Documento de identidad</th>
                            <th>Pasaporte</th>
                            <th>Rif</th>
                            <th>Referencia bancaria 1</th>
                            <th>Referencia bancaria 2</th>
                        </tr>
                        </thead>
                        <tbody id=\"bodyDocumentos\">                                           
                                                                    
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Documento de identidad</th>
                            <th>Pasaporte</th>
                            <th>Rif</th>
                            <th>Referencia bancaria 1</th>
                            <th>Referencia bancaria 2</th>
                        </tr>
                        </tfoot>
                    </table>
            </div>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/documentos.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "usuarios/documentos.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\documentos.twig");
    }
}

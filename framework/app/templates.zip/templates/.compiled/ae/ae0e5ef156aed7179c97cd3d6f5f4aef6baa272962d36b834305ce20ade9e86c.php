<?php

/* overall/header.twig */
class __TwigTemplate_a2e2472682ea841d4c051185bec7b0933470fddae0d7b763536b6219b410de9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header\">
           <a class=\"navbar-minimalize minimalize-styl-2 btn btn-primary\" href=\"javascript:void(0)\"><i class=\"fa fa-bars\"></i></a>
        </div>
        <ul class=\"nav navbar-top-links navbar-right\" style=\"margin-top:5px;\">
            <li>
                <span class=\"\"><a href=\"";
        // line 7
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "es\" title=\"Idioma: Español\" class=\"betiviris\">ES</a>/<a href=\"";
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "en\" title=\"Idioma: Ingles\" class=\"betiviris\">EN</a></span>
            </li>  
            ";
        // line 9
        if ((($context["owner_user"] ?? null) != null)) {
            echo "          
            <li>
                
                <a href=\"logout/\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesi&oacute;n
                </a>
                 
            </li>
            ";
        }
        // line 18
        echo "        </ul>
</nav>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 18,  34 => 9,  27 => 7,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/header.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\header.twig");
    }
}

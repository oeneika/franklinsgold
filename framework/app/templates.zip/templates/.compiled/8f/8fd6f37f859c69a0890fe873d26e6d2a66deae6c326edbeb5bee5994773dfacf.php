<?php

/* registro/registro.twig */
class __TwigTemplate_8d25d7577069221fe745bd37ac5c786b256963001e5ec63eeaf5e493c26fa243 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-404", "registro/registro.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-404";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "\t<div class=\"middle-box text-center loginscreen   animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:170px;\" /></h1>

            </div>
            <h3>Registro</h3>
            <form class=\"m-t\" role=\"form\" id=\"registro_form\">
            \t<div class=\"row\">
            \t\t<div class=\"col-md-6\">
            \t\t\t <div class=\"form-group\">
\t\t                    <input type=\"text\" name='primer_nombre' id='id_primer_nombre' class=\"form-control\" placeholder=\"Primer Nombre (*)\">
\t\t                </div>
\t\t                <div class=\"form-group\">
\t\t                    <input type=\"text\" name='segundo_nombre' id='id_segundo_nombre' class=\"form-control\" placeholder=\"Segundo Nombre\">
\t\t                </div>
            \t\t</div>
            \t\t<div class=\"col-md-6\">
\t\t                <div class=\"form-group\">
\t\t                    <input type=\"text\" name='primer_apellido' id='id_primer_apellido' class=\"form-control\" placeholder=\"Primer Apellido (*)\">
\t\t                </div>
\t\t                <div class=\"form-group\">
\t\t                    <input type=\"text\" name='segundo_apellido' id='id_segundo_apellido' class=\"form-control\" placeholder=\"Segundo Apellido\">
\t\t                </div>
                        
            \t\t</div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <label class=\"float-left\"><input type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\" id='id_sexo' type=\"radio\">Masculino</label>
                    </div>
                    <div class=\"col-md-6\">
                        <label class=\"float-left\"><input type=\"radio\" value=\"f\" name=\"sexo\" id='id_sexo' type=\"radio\">Femenino</label>
                    </div>
                </div>

                <hr>

                <div class=\"form-group\">
                    <label for=\"foto_documento_identidad\" class=\"float-left\">Subir fotografía de documento de identidad <span style=\"color:#e44545\"> (*) </span></label>
                    <input type=\"file\" class=\"form-control-file\" name=\"foto_documento_identidad\" id=\"id_foto_documento_identidad\">
                </div>

                <div class=\"form-group\">
                    <label for=\"foto_pasaporte\" class=\"float-left\">Subir fotografía del pasaporte <span style=\"color:#e44545\"> (*) </span></label>
                    <input type=\"file\" class=\"form-control-file\" name=\"foto_pasaporte\" id=\"id_foto_pasaporte\">
                </div>

                <hr>

                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <div class=\"form-group\">
                            <input type=\"text\" name='usuario' id=\"id_usuario\" class=\"form-control\" placeholder=\"Usuario (*)\">
                        </div>
                    </div>
                    <div class=\"col-md-6\">
                        <div class=\"form-group\">
                            <input type=\"text\" name='email' id=\"id_email\" class=\"form-control\" placeholder=\"Correo electrónico (*)\">
                        </div>
                    </div>
                </div>

                <div class=\"form-group\">
                    <input type=\"text\" name='telefono' id=\"id_telefono\" class=\"form-control\" placeholder=\"Teléfono (*)\">
                </div>

                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <div class=\"form-group\">
                            <input type=\"password\" name='pass' id=\"id_pass\" class=\"form-control\" placeholder=\"Contraseña (*)\">
                        </div>
                    </div>
                    <div class=\"col-md-6\">
                        <div class=\"form-group\">
                            <input type=\"password\" name='pass_repeat' id=\"id_pass_repeat\" class=\"form-control\" placeholder=\"Repetir Contraseña (*)\">
                        </div>
                    </div>
                </div>

                <div class=\"form-group\">
                    <input type=\"number\" name='numero_cuenta' id=\"id_numero_cuenta\" class=\"form-control\" placeholder=\"Número de cuenta (*)\">
                </div>

                <input type=\"hidden\" id=\"terminos_ocultos\" value=\"'";
        // line 88
        echo twig_escape_filter($this->env, ($context["terminos"] ?? null), "html", null, true);
        echo "'\">

                <p class=\"text-muted text-center\"><small><a href=\"javascript:void(0)\" style=\"color:#d4c83d\" data-toggle=\"modal\" data-target=\"#modal_terminos\">Haga click aqui para leer los términos y condiciones.</a></small></p>
                <div class=\"form-check\">
                  <label class=\"form-check-label\">
                    <input class=\"form-check-input\" type=\"checkbox\" id=\"id_terminos\"> 
                    <a id=\"buttonTerminos\" style=\"color:white\">Acepto los términos y condiciones</a>
                  </label>
                </div>
                               
                <button type=\"button\" id=\"registro\" class=\"btn btn-primary block full-width m-b\">REGISTRO</button>

                <p class=\"text-muted text-center\"><small>¿Ya estás registrado en el sistema?</small><a href=\"login/\" style=\"color:#d4c83d\"> Inicia Sesión</a></p>
            </form>
        </div>
    </div>

    ";
        // line 105
        $this->loadTemplate("registro/terminos", "registro/registro.twig", 105)->display($context);
        echo " 

";
    }

    // line 108
    public function block_appFooter($context, array $blocks = array())
    {
        // line 109
        echo "    <script src=\"./assets/jscontrollers/registro/registro.js\"></script>
    <!-- iCheck -->
    <script src=\"views/js/plugins/iCheck/icheck.min.js\"></script>
    <script>
        \$(document).ready(function(){
            \$('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>

";
    }

    public function getTemplateName()
    {
        return "registro/registro.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 109,  146 => 108,  139 => 105,  119 => 88,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "registro/registro.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\registro\\registro.twig");
    }
}

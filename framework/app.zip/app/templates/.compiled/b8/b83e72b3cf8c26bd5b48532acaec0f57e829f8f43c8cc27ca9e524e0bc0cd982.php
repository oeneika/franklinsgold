<?php

/* ordenes/ventaoro.twig */
class __TwigTemplate_c3612143a4423b1c22f1646d46aa34bb8584b23f4161e4bd10d2573b6ef7956d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "ordenes/ventaoro.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "ordenes/ventaoro.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-money\"></i> Vender oro</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Vender oro</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Vender oro</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <form id=\"crearOrdenCompra_form\">
                                <div class=\"row\">
                                    <div class=\"col-md-2 col-xs-12\">
                                        <div class=\"form-group\">
                                            <label for=\"cantidad_bolivar_soberano\" class=\"control-label mb-1\" >Cantidad BsS</label>
                                            <input name=\"cantidad_bolivar_soberano\" id=\"id_cantidad_bolivar_soberano\" type=\"number\" onchange=\"resetQuantity('id_cantidad_bolivar_soberano','id_tipo','id_cantidad','id_monto_dolares')\" class=\"form-control\" >
                                        </div>
                                    </div>  

                                    <div class=\"col-md-2 col-xs-12\">
                                        <div class=\"form-group\">
                                            <label for=\"id_tipo\" class=\"control-label mb-1\" >Tipo metal</label>
                                            <input name=\"tipo_gramo\" id=\"id_tipo\" readonly=\"readonly\" class=\"form-control\" value=\"oro\">
                                        </div>                         
                                    </div>

                                    <div class=\"col-md-2 col-xs-12\">
                                        <div class=\"form-group\">
                                            <label for=\"cantidad\" class=\"control-label mb-1\">Cantidad gramos</label>
                                            <input name=\"cantidad\" id=\"id_cantidad\" type=\"number\" readonly=\"readonly\" class=\"form-control\" >
                                        </div>                           
                                    </div>
                                    
                                    <div class=\"col-md-2 col-xs-12\">
                                        <div class=\"form-group\">
                                            <label for=\"monto_dolares\" class=\"control-label mb-1\">Monto(Dólares)</label>
                                            <input name=\"monto_dolares\" id=\"id_monto_dolares\" type=\"text\" readonly=\"readonly\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                                        </div>                           
                                    </div>

                                    <div class=\"col-md-4 col-xs-12\">
                                        <div class=\"fileinput fileinput-new\" data-provides=\"fileinput\">
                                            <br>
                                            <span class=\"btn btn-default btn-file\" style=\"margin-top:5px;\"><span class=\"fileinput-new\">Seleccionar archivo para la transferencia</span>
                                            <span class=\"fileinput-exists\">Cambiar</span>
                                            <input type=\"file\" name=\"foto_transferencia\" id=\"id_foto_transferencia\" style=\"width:100%\" /></span>
                                            <span class=\"fileinput-filename\"></span>
                                            <a href=\"#\" class=\"close fileinput-exists\" data-dismiss=\"fileinput\" style=\"float: none\">×</a>
                                        </div> 
                                    </div>

                                </div>  
                               
                                <input name=\"tipo_orden\" id=\"id_tipo_orden\" value=\"2\" type=\"hidden\"> 
                                
                                <div class=\"row\">
                                    <div class=\"col-md-3\">
                                        <button type=\"button\" id=\"crearOrdenCompra\" class=\"btn btn-primary\" style=\"width:100%\">Realizar Venta</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                </div>
            </div>
    </div>
</div>
</div>
";
    }

    // line 97
    public function block_appFooter($context, array $blocks = array())
    {
        // line 98
        echo "<script src=\"./assets/jscontrollers/ordenes/crear.js\"></script>
<script>
    \$(document).ready(function(){
        showModal( ";
        // line 101
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo " , 0, ";
        echo twig_escape_filter($this->env, ($context["precio_bolivar"] ?? null), "html", null, true);
        echo " );
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "ordenes/ventaoro.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 101,  134 => 98,  131 => 97,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/ventaoro.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\ventaoro.twig");
    }
}

<?php

/* overall/footer.twig */
class __TwigTemplate_0450ac9defa047dc3289d6ff89f495806606cba0f79688afd49b6f6c6dfc6e92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"footer\">
  \t<div class=\"pull-right\">
    \tDesarrollado por: Corporación JSK [ www.corporacionjsk.com ]
  \t</div>
  \t<div>
    \t<strong>Caracas, Venezuela</strong> Franklins Gold &copy; 2018 / <strong>Fecha:</strong>
    \t<script type=\"text/javascript\">
\t\t//<![CDATA[
\t\tvar date = new Date();
\t\tvar d  = date.getDate();
\t\tvar day = (d < 10) ? '0' + d : d;
\t\tvar m = date.getMonth() + 1;
\t\tvar month = (m < 10) ? '0' + m : m;
\t\tvar yy = date.getYear();
\t\tvar year = (yy < 1000) ? yy + 1900 : yy;
\t\tdocument.write(day + \"/\" + month + \"/\" + year);
\t\t//]]>
\t\t</script>
\t\t<strong>Hora:</strong>
\t\t<script type=\"text/javascript\">
\t\tvar d = new Date();
\t\tdocument.write(+d.getHours(),':'+d.getMinutes(),':'+d.getSeconds());
\t\t</script>
  \t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "overall/footer.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"footer\">
  \t<div class=\"pull-right\">
    \tDesarrollado por: Corporación JSK [ www.corporacionjsk.com ]
  \t</div>
  \t<div>
    \t<strong>Caracas, Venezuela</strong> Franklins Gold &copy; 2018 / <strong>Fecha:</strong>
    \t<script type=\"text/javascript\">
\t\t//<![CDATA[
\t\tvar date = new Date();
\t\tvar d  = date.getDate();
\t\tvar day = (d < 10) ? '0' + d : d;
\t\tvar m = date.getMonth() + 1;
\t\tvar month = (m < 10) ? '0' + m : m;
\t\tvar yy = date.getYear();
\t\tvar year = (yy < 1000) ? yy + 1900 : yy;
\t\tdocument.write(day + \"/\" + month + \"/\" + year);
\t\t//]]>
\t\t</script>
\t\t<strong>Hora:</strong>
\t\t<script type=\"text/javascript\">
\t\tvar d = new Date();
\t\tdocument.write(+d.getHours(),':'+d.getMinutes(),':'+d.getSeconds());
\t\t</script>
  \t</div>
</div>", "overall/footer.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\footer.twig");
    }
}

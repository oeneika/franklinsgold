<?php

/* transaccion/confirmar.twig */
class __TwigTemplate_9885aa054de585ad0b399707dc4dfc29f91f829d9242c906d394baa0968a844f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"confirmarTransacciones\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Confirmar transacción</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"confirmar_transacciones_form\">
                    <input type=\"hidden\" id=\"id_usuario_con\" name=\"id_usuario\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "email", array()), "html", null, true);
        echo "\">
                    <input type=\"hidden\" name=\"tipo\" value=\"1\">
                    <input type=\"hidden\" id=\"id_codigo_con\" name=\"codigo\" value=\"importa?\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\" >Código de confirmación<span>*</span></label>
                                <input type=\"text\" class=\"form-control\" name=\"codigo_confirmacion\" id=\"codigo_confirmacion\">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"confirmartransaccionesbtn\" class=\"btn btn-primary\">Confirmar</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "transaccion/confirmar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 14,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "transaccion/confirmar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\confirmar.twig");
    }
}

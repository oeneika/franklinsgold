<?php

/* overall/header.twig */
class __TwigTemplate_a2e2472682ea841d4c051185bec7b0933470fddae0d7b763536b6219b410de9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header\">
           <a class=\"navbar-minimalize minimalize-styl-2 btn btn-primary\" href=\"javascript:void(0)\"><i class=\"fa fa-bars\"></i></a>
        </div>
        <ul class=\"nav navbar-top-links navbar-right\" style=\"margin-top:5px;\">
            <li class=\"bajandole\">
                <span class=\"\"><a href=\"";
        // line 7
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "es\" title=\"Idioma: Español\" class=\"betiviris\">ES</a>/<a href=\"";
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "en\" title=\"Idioma: Ingles\" class=\"betiviris\">EN</a></span>
            </li>  


            ";
        // line 11
        if ((($context["owner_user"] ?? null) != null)) {
            echo "     
            <li class=\"dropdown menucito\">
                <button type=\"button\" class=\"btn btn-primary btn-responsiv\" data-toggle=\"modal\" data-target=\"#notificaciones\">
                  <i class=\"fa fa-bell\"></i> Notificaciones del sistema <strong>( ";
            // line 14
            echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["notifications"] ?? null)), "html", null, true);
            echo " )</strong>
                </button>
                ";
            // line 16
            $this->loadTemplate("overall/notificaciones", "overall/header.twig", 16)->display($context);
            // line 17
            echo "            </li> 
            <li>
                <a href=\"logout/\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesi&oacute;n
                </a>
                 
            </li>
            ";
        }
        // line 25
        echo "        </ul>
</nav>
<div class=\"container\">
    <div class=\"row margintop-60 fonditola\">
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colororo font-18\">Precio del ORO</h4>
                        <div class=\"col-sm-6 font-18\">
                            <span style=\"font-weight:bold;\">VENTA:</span> \$";
        // line 33
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo "
                            <br>
                            <a type=\"button\" href=\"ordencliente/ventaoro/\" class=\"btn btn-primary btn-responsive\">Vender Oro</a>
                        </div>
                        <div class=\"col-sm-6 font-18\">
                            <span style=\"font-weight:bold;\">COMPRA:</span> \$";
        // line 38
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares", array()), "html", null, true);
        echo "
                            <br>
                            <a type=\"button\" href=\"ordencliente/compraoro/\" class=\"btn btn-primary btn-responsive\">Comprar Oro</a>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colorplata font-18\">Precio de la PLATA</h4>
                        <div class=\"col-sm-6 font-18\">
                            <span style=\"font-weight:bold;\">VENTA:</span> \$";
        // line 48
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_plata_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo "
                            <br>
                            <a type=\"button\" href=\"ordencliente/ventaplata/\" class=\"btn btn-primary btn-responsive\">Vender plata</a>
                        </div>
                        <div class=\"col-sm-6 font-18\">
                            <span style=\"font-weight:bold;\">COMPRA:</span> \$";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_plata_global"] ?? null), "precio_dolares", array()), "html", null, true);
        echo "
                            <br>
                            <a type=\"button\" href=\"ordencliente/compraplata/\" class=\"btn btn-primary btn-responsive\">Comprar plata</a>
                        </div>
                    </div>
                </div>              
    </div>
</div>
<br>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 53,  90 => 48,  77 => 38,  69 => 33,  59 => 25,  49 => 17,  47 => 16,  42 => 14,  36 => 11,  27 => 7,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/header.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\header.twig");
    }
}

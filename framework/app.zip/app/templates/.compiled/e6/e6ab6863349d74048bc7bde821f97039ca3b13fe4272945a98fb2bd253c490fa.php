<?php

/* transaccion/crear.twig */
class __TwigTemplate_46c0488b35cd187ac8c3d44dde6ef1344d241e68c2a0fbebaf27a667703f852e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal jiji\" id=\"crearTransacciones\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Creación de transacciones</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"crear_transacciones_form\">
                    <input id=\"tipo_transaccion\" name=\"tipo\" type=\"hidden\">

                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\" >Usuario<span>*</span></label>
                                <select name=\"id_usuario\" id=\"selector_usuario\" class=\"form-control select2\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un usuario</option>
                                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["usuarios"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            echo "       
                                        <option value=\"";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_apellido", array()), "html", null, true);
            echo "</option>                                                                                   
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "                                </select>
                            </div>
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"cc-payment\" class=\"control-label mb-1\">Moneda<span>*</span></label>
                            <select name=\"codigo\" id=\"\" class=\"form-control m-b\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione una moneda</option>
                                    ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["monedas"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 33
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "codigo", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["m"], "codigo", array()), "html", null, true);
            echo "</option>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"creartransaccionesbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "transaccion/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 35,  73 => 33,  69 => 32,  60 => 25,  48 => 23,  42 => 22,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "transaccion/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\crear.twig");
    }
}

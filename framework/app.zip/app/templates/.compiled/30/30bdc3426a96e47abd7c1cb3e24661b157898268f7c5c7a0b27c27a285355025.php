<?php

/* ordenes/compraventatienda.twig */
class __TwigTemplate_faf2be51e794db759ab8840b80ba7443b7448d17e679299bc15944ea580bb885 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal jiji\" id=\"compraventatiendaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Compra ó venta de gramos de Oro ó Plata</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crearOrdenCompraVentaTienda_form\">
                    <div class=\"row\">
                       
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_orden\" class=\"control-label mb-1\" >Tipo transacción</label>
                                <select name=\"tipo_orden\" id=\"id_tipo_orden\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"1\">Compra</option>
                                    <option value=\"2\">Venta</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cliente\" class=\"control-label mb-1\" >Clientes</label>
                                <select name=\"email\" id=\"id_cliente\" class=\"form-control select2\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un cliente</option>
                                     ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["clientes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            echo "       
                                         <option value=\"";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "email", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "email", array()), "html", null, true);
            echo "</option>
                                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "                                </select>
                            </div>
                        </div> 

                    </div>
                    <div class=\"row\">

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_gramo\" class=\"control-label mb-1\" >Tipo metal</label>
                                <select name=\"tipo_gramo\" id=\"id_tipo\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"oro\">Oro</option>
                                    <option value=\"plata\">Plata</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cantidad\" class=\"control-label mb-1\" >Cantidad(gramos)</label>
                                <input name=\"cantidad\" id=\"id_cantidad\" type=\"number\" class=\"form-control\"> 
                            </div>                         
                        </div>

                        <div class=\"col-md-12 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"foto_transferencia\" class=\"float-left\">Subir imagen de la transferencia  </label>
                                <input type=\"file\" class=\"form-control-file\" name=\"foto_transferencia\" id=\"id_foto_transferencia\">
                            </div>
                        </div>

                    </div>

                                          
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrdenCompraVentaTienda\" class=\"btn btn-primary\">Crear</button>
            </div>
            
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "ordenes/compraventatienda.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 34,  57 => 32,  51 => 31,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/compraventatienda.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\compraventatienda.twig");
    }
}

<?php

/* overall/menu.twig */
class __TwigTemplate_bf06cbbe80297a97ccc81d46a703a5fa9455bba9010e6527a4b34a8c1f835658 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
    <div class=\"sidebar-collapse\">
        <ul class=\"nav metismenu\" id=\"side-menu\">
            <li class=\"nav-header\">
                <div class=\"dropdown profile-element\">
                    <span>
                    <a href=\"home/\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"height:100px; margin: 0 40px;\" /></a>
                    </span>
                    <span class=\"clear\"> 
                        <a href=\"home/\" title=\"Ir al inicio del sistema\"><span class=\"block m-t-xs\"><strong class=\"font-bold hover\" style=\"margin: 0 35px;\">Franklin Gold</strong></span></a>
                    </span>
                </div>
                <div class=\"logo-element\">
                    <a href=\"home/\">FG</a>
                </div>
            </li>
            ";
        // line 17
        if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0) || (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 2))) {
            // line 18
            echo "
                <li style=\"background: #38372D\">
                    <a href=\"ordencliente/compraoro/\" style=\"color: #ffc800\"><i class=\"fa fa-coins\"></i><span class=\"nav-label\">Compra de</span> <span class=\"float-right label label-primary\" style=\"margin-left:5px;\"> \"ORO\"</span></a>
                </li>

                <li style=\"background: #38372D\">
                    <a href=\"ordencliente/ventaoro/\" style=\"color: #ffc800\"><i class=\"fa fa-coins\"></i><span class=\"nav-label\">Venta de</span> <span class=\"float-right label label-primary\" style=\"margin-left:5px;\"> \"ORO\"</span></a>
                </li>

                <li style=\"background: #38372D\">
                    <a href=\"ordencliente/compraplata/\" style=\"color: #ffc800\"><i class=\"fa fa-coins\"></i><span class=\"nav-label\">Compra de</span> <span class=\"float-right label label-gris\" style=\"margin-left:5px;\"> \"PLATA\"</span></a>
                </li>
                
                <li style=\"background: #38372D\">
                    <a href=\"ordencliente/ventaplata/\" style=\"color: #ffc800\"><i class=\"fa fa-coins\"></i><span class=\"nav-label\">Venta de</span> <span class=\"float-right label label-gris\" style=\"margin-left:5px;\"> \"PLATA\"</span></a>
                </li>
                
            ";
        }
        // line 36
        echo "            <li class=\"\">
                <a href=\"dashboardpublico/dashboardpublico/\"><i class=\"fa fa-sliders-h\"></i><span class=\"nav-label\">Tablero</span></a>
            </li>
            ";
        // line 39
        if ((($context["owner_user"] ?? null) != null)) {
            // line 40
            echo "            
                ";
            // line 41
            if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 2)) {
                // line 42
                echo "                <li class=\"\">
                    <a href=\"perfilcliente/\"><i class=\"fa fa-user\"></i><span class=\"nav-label\">Perfil</span></a>
                </li>
                ";
            }
            // line 46
            echo "                <li class=\"\">
                    <a href=\"calculadora/\"><i class=\"fa fa-calculator\"></i><span class=\"nav-label\">Calculadora</span></a>
                </li>
                ";
            // line 49
            if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0)) {
                // line 50
                echo "                    <li class=\"\">
                        <a href=\"usuarios/\"><i class=\"fa fa-users\"></i> <span class=\"nav-label\">Usuarios</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"rango/\"><i class=\"fa fa-arrow-circle-up\"></i> <span class=\"nav-label\">Rangos</span></a>
                    </li>       
                    <li class=\"\">
                        <a href=\"monedas/\"><i class=\"fas fa-coins\"></i> <span class=\"nav-label\">Moneda</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"sucursal/\"><i class=\"fa fa-hotel\"></i> <span class=\"nav-label\">Sucursal</span></a>
                    </li>
                    <li class=\"\">
                            <a href=\"afiliados/\"><i class=\"fa fa-hand-holding\"></i> <span class=\"nav-label\">Comercios Afiliados</span></a>
                        </li>
                    </li>
                    <li class=\"\">
                        <a href=\"origen/\"><i class=\"fa fa-home\"></i><span class=\"nav-label\">Origen</span>
                        </a>
                    </li>
                    <li class=\"\">
                        <a href=\"divisa/\"><i class=\"fa fa-money-bill-alt\"></i><span class=\"nav-label\">Dívisas</span></a>
                    </li>
                ";
            }
            // line 74
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) != 2) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_comercio_afiliado", array()) == null))) {
                // line 75
                echo "                <li class=\"\">
                    <a href=\"ordenadmin/\"><i class=\"fa fa-shopping-cart\"></i><span class=\"nav-label\">Ordenes</span></a>
                </li>    
                ";
            }
            // line 79
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0) || ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 3) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_comercio_afiliado", array()) == null)))) {
                // line 80
                echo "                <li class=\"\">
                    <a><i class=\"fa fa-money-check-alt\"></i> <span class=\"nav-label\">Transacciones</span><span class=\"fa arrow\"></span></a>
                    <ul class=\"nav nav-second-level collapse\">
                        <li>
                            <a href=\"transaccion/compra/\">Compra</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/venta/\">Venta</a>
                        </li>-->
                        <li>
                            <a href=\"transaccion/transaccion_en_espera/\">En espera</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/intercambio/\">Intercambio</a>
                        </li>-->
                        <!--<li>
                            <a href=\"transaccion/intercambioafiliado/\">Intercambio con Afiliados</a>
                        </li>-->
                    </ul>
                </li>                   
                ";
            }
            // line 101
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0) || (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 2))) {
                // line 102
                echo "                <li class=\"\">
                            <a href=\"\"><i class=\"fa fa-tasks\"></i><span class=\"nav-label\">Compra y Venta</span><span class=\"fa arrow\"></span></a>
                            <ul class=\"nav nav-second-level collapse\">
                                <li>
                                    <a href=\"ordencliente/\">Tablero</a>
                                </li>

                                <li>
                                    <a href=\"ordencliente/intercambiomoneda/\">Intercambio moneda</a>
                                </li>
                            </ul>
                </li>
                <li class=\"\">
                    <a href=\"factura/factura-tabla\"><i class=\"fa fa-copy\"></i><span class=\"nav-label\">Facturas</span></a>
                </li>
                <li class=\"\">
                    <a href=\"ayuda/ayuda\"><i class=\"fa fa-lightbulb\"></i><span class=\"nav-label\">Ayuda</span></a>
                </li>
                ";
            }
            // line 121
            echo "            ";
        }
        echo "   
        </ul>
    </div>
</nav>";
    }

    public function getTemplateName()
    {
        return "overall/menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 121,  148 => 102,  145 => 101,  122 => 80,  119 => 79,  113 => 75,  110 => 74,  84 => 50,  82 => 49,  77 => 46,  71 => 42,  69 => 41,  66 => 40,  64 => 39,  59 => 36,  39 => 18,  37 => 17,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/menu.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\menu.twig");
    }
}

<?php

/* usuarios/crear.twig */
class __TwigTemplate_984fe5168d80397fc5c8790eb5ca902e6f3e1c4e8331f616dfc6b65dba7ecab4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Usuarios</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_usuario_form\">
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input  name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input  name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input  name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido </label>
                                <input  name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"usuario\" class=\"control-label mb-1\">Usuario <span>*</span></label>
                                <input  name=\"usuario\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input class=\"tipo_crear\" type=\"radio\" value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input class=\"tipo_crear\" type=\"radio\" value=\"1\" name=\"tipo\"> Vendedor
                                    </br>
                                    <input class=\"tipo_crear\" type=\"radio\" value=\"2\" name=\"tipo\" checked=\"\" > Cliente
                                    </br>
                                    <input class=\"tipo_crear\" type=\"radio\" value=\"3\" name=\"tipo\"> Supervisor    
                                </div>
                            </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Teléfono <span>*</span></label>
                                <input name=\"telefono\" type=\"tel\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <br>
                    <div class=\"panel panel-warning selects_body\" style=\"display: none;\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">Seleccione una sucursal o un comercio</h3>
                        </div>
                        <div class=\"panel-body\">
                                <div class=\"row\">
                                    <div class=\"col-md-6\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Sucursal<span>*</span></label>
                                        <select name=\"id_sucursal\" id=\"\" class=\"form-control m-b\" style=\"width: 100%\">
                                                 <option selected value>Seleccione una sucursal</option>
                                                ";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["sucursales"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            // line 87
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "id_sucursal", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "nombre", array()), "html", null, true);
            echo "</option>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        echo "                                        </select>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Comercio Afiliado<span>*</span></label>
                                        <select name=\"id_comercio\" class=\"form-control m-b\" style=\"width: 100%\">
                                                <option selected value>Seleccione un comercio</option>
                                                ";
        // line 95
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["afiliados"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 96
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "nombre", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "sucursal", array()), "html", null, true);
            echo "</option>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "                                        </select>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"email\" class=\"control-label mb-1\">Correo <span>*</span></label>
                                <input name=\"email\" type=\"email\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"nombre_banco\" class=\"control-label mb-1\">Entidad bancaria <span>*</span></label>
                                <input name=\"nombre_banco\"  type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"numero_cuenta\" class=\"control-label mb-1\">No. de cuenta <span>*</span></label>
                                <input name=\"numero_cuenta\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearUsuariobtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 98,  133 => 96,  129 => 95,  121 => 89,  110 => 87,  106 => 86,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "usuarios/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\crear.twig");
    }
}

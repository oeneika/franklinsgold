<?php

/* afiliados/telefonos.twig */
class __TwigTemplate_578af6762cb7378c6a16dc178e66479c2b0ba374b0680139afe796d69ed61d77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"modaltelefonos\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                                    <div class=\"modal-header\">
                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar ";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</span></button>
                                        <h4 class=\"modal-title\">Teléfonos del Comercio Afiliado ";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "telefonoscomercio", array()), "html", null, true);
        echo "</h4>
                                        <small class=\"font-bold\">Franklin Gold</small>
                                    </div>
                                    <div class=\"modal-body\">
                                        <ul id=\"listado_telefonos\">
                                        </ul>
                                    </div>
                                    <div class=\"modal-footer\">
                                        <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</button>
                                    </div>
            </div>
        </div>
</div>
    ";
    }

    public function getTemplateName()
    {
        return "afiliados/telefonos.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 14,  29 => 6,  25 => 5,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "afiliados/telefonos.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\afiliados\\telefonos.twig");
    }
}

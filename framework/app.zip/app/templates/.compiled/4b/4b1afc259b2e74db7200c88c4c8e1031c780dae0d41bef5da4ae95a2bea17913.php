<?php

/* overall/layoutinicio.twig */
class __TwigTemplate_58754f99358f82ca415fce2134a297e557003c05111e31f13f93cab0f86d223a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <!-- Bootstrap core CSS -->
    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- Animation CSS -->
    <link href=\"views/css/animate.css\" rel=\"stylesheet\">

    <!-- Font-awesome -->
    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.3.1/css/all.css\" integrity=\"sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU\" crossorigin=\"anonymous\">

    <!-- Custom styles for this template -->
    <link href=\"views/css/style.css\" rel=\"stylesheet\">

    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    ";
        // line 24
        $this->displayBlock('appHeader', $context, $blocks);
        // line 26
        echo "
    <title>";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body id=\"page-top\" class=\"landing-page no-skin-config\">

";
        // line 31
        $this->displayBlock('appBody', $context, $blocks);
        // line 33
        echo "
    <!-- Mainly scripts -->
    <script src=\"views/propios/js/jquery.min.js\"></script>
    <script src=\"views/js/popper.min.js\"></script>
    <script src=\"views/js/bootstrap.js\"></script>
    <script src=\"views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"views/js/inspinia.js\"></script>
    <script src=\"views/js/plugins/pace/pace.min.js\"></script>
    <script src=\"views/js/plugins/wow/wow.min.js\"></script>


    <script>

        \$(document).ready(function () {

            \$('body').scrollspy({
                target: '#navbar',
                offset: 80
            });

            // Page scrolling feature
            \$('a.page-scroll').bind('click', function(event) {
                var link = \$(this);
                \$('html, body').stop().animate({
                    scrollTop: \$(link.attr('href')).offset().top - 50
                }, 500);
                event.preventDefault();
                \$(\"#navbar\").collapse('hide');
            });
        });

        var cbpAnimatedHeader = (function() {
            var docElem = document.documentElement,
                    header = document.querySelector( '.navbar-default' ),
                    didScroll = false,
                    changeHeaderOn = 200;
            function init() {
                window.addEventListener( 'scroll', function( event ) {
                    if( !didScroll ) {
                        didScroll = true;
                        setTimeout( scrollPage, 250 );
                    }
                }, false );
            }
            function scrollPage() {
                var sy = scrollY();
                if ( sy >= changeHeaderOn ) {
                    \$(header).addClass('navbar-scroll')
                }
                else {
                    \$(header).removeClass('navbar-scroll')
                }
                didScroll = false;
            }
            function scrollY() {
                return window.pageYOffset || docElem.scrollTop;
            }
            init();

        })();

        // Activate WOW.js plugin for animation on scrol
        new WOW().init();
    </script>

    ";
        // line 101
        $this->displayBlock('appFooter', $context, $blocks);
        // line 103
        echo "
</body>
</html>
";
    }

    // line 24
    public function block_appHeader($context, array $blocks = array())
    {
        // line 25
        echo "    ";
    }

    // line 31
    public function block_appBody($context, array $blocks = array())
    {
    }

    // line 101
    public function block_appFooter($context, array $blocks = array())
    {
        // line 102
        echo "    ";
    }

    public function getTemplateName()
    {
        return "overall/layoutinicio.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 102,  152 => 101,  147 => 31,  143 => 25,  140 => 24,  133 => 103,  131 => 101,  61 => 33,  59 => 31,  52 => 27,  49 => 26,  47 => 24,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/layoutinicio.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layoutinicio.twig");
    }
}

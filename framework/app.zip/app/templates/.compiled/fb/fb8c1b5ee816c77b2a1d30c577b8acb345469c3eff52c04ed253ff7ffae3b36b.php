<?php

/* ayuda/ayuda.twig */
class __TwigTemplate_b969630fb667ce62d0db31cd299a2ac0ccd7faf2491d13ffed445aa75b4bde65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "ayuda/ayuda.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "ayuda/ayuda.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-coins\"></i> Ayuda</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Ayuda</strong>
                        </li>
                    </ol>
    </div>
</div>
<div class=\"row\">
                <div class=\"col-lg-12\">
                    <div class=\"wrapper wrapper-content animated fadeInRight\">

                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <a data-toggle=\"collapse\" href=\"#faq1\" class=\"faq-question\">What It a long established fact that a reader ?</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq1\" class=\"panel-collapse collapse \">
                                        <div class=\"faq-answer\">
                                            <p>
                                                It is a long established fact that a reader will be distracted by the
                                                readable content of a page when looking at its layout. The point of
                                                using Lorem Ipsum is that it has a more-or-less normal distribution of
                                                letters, as opposed to using 'Content here, content here', making it
                                                look like readable English.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq2\" class=\"faq-question\">Many desktop publishing packages ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq2\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Many desktop publishing packages and web page editors now use Lorem
                                                Ipsum as their default model text, and a search for 'lorem ipsum' will
                                                uncover many web sites still in their infancy. Various versions have
                                                evolved over the years, sometimes by accident, sometimes on purpose
                                                (injected humour and the like).
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq3\" class=\"faq-question\">Ipsum generators on the Internet tend ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq3\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Ipsum generators on the Internet tend to repeat predefined chunks as
                                                necessary, making this the first true generator on the Internet. It uses
                                                a dictionary of over 200 Latin words, combined with a handful of model
                                                sentence structures, to generate Lorem Ipsum which looks reasonable. The
                                                generated Lorem Ipsum is therefore always free from repetition, injected
                                                humour, or non-characteristic words etc.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq4\" class=\"faq-question\">What Finibus Bonorum et Malorum mean ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq4\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus
                                                Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written
                                                in 45 BC. This book is a treatise on the theory of ethics, very popular
                                                during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum
                                                dolor sit amet..\", comes from a line in section 1.10.32.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

</div>
";
    }

    // line 126
    public function block_appFooter($context, array $blocks = array())
    {
        // line 127
        echo "
";
    }

    public function getTemplateName()
    {
        return "ayuda/ayuda.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 127,  160 => 126,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    {% include 'overall/header' %}
</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-coins\"></i> Ayuda</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Ayuda</strong>
                        </li>
                    </ol>
    </div>
</div>
<div class=\"row\">
                <div class=\"col-lg-12\">
                    <div class=\"wrapper wrapper-content animated fadeInRight\">

                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <a data-toggle=\"collapse\" href=\"#faq1\" class=\"faq-question\">What It a long established fact that a reader ?</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq1\" class=\"panel-collapse collapse \">
                                        <div class=\"faq-answer\">
                                            <p>
                                                It is a long established fact that a reader will be distracted by the
                                                readable content of a page when looking at its layout. The point of
                                                using Lorem Ipsum is that it has a more-or-less normal distribution of
                                                letters, as opposed to using 'Content here, content here', making it
                                                look like readable English.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq2\" class=\"faq-question\">Many desktop publishing packages ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq2\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Many desktop publishing packages and web page editors now use Lorem
                                                Ipsum as their default model text, and a search for 'lorem ipsum' will
                                                uncover many web sites still in their infancy. Various versions have
                                                evolved over the years, sometimes by accident, sometimes on purpose
                                                (injected humour and the like).
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq3\" class=\"faq-question\">Ipsum generators on the Internet tend ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq3\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Ipsum generators on the Internet tend to repeat predefined chunks as
                                                necessary, making this the first true generator on the Internet. It uses
                                                a dictionary of over 200 Latin words, combined with a handful of model
                                                sentence structures, to generate Lorem Ipsum which looks reasonable. The
                                                generated Lorem Ipsum is therefore always free from repetition, injected
                                                humour, or non-characteristic words etc.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"faq-item\">
                            <div class=\"row\">
                                <div class=\"col-md-7\">
                                    <a data-toggle=\"collapse\" href=\"#faq4\" class=\"faq-question\">What Finibus Bonorum et Malorum mean ?</a>
                                    
                                </div>
                                
                            </div>
                            <div class=\"row\">
                                <div class=\"col-lg-12\">
                                    <div id=\"faq4\" class=\"panel-collapse collapse\">
                                        <div class=\"faq-answer\">
                                            <p>
                                                Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus
                                                Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written
                                                in 45 BC. This book is a treatise on the theory of ethics, very popular
                                                during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum
                                                dolor sit amet..\", comes from a line in section 1.10.32.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

</div>
{% endblock %}

{% block appFooter %}

{% endblock %}", "ayuda/ayuda.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ayuda\\ayuda.twig");
    }
}

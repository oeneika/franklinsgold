<?php

/* afiliados/crear.twig */
class __TwigTemplate_cc44d175bd009e93be954183a6c3f357fe377dd000b885d2066cb1fb0139339a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearAfiliado\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
                            <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</span></button>
                                    <h4 class=\"modal-title\">Creación de Comercio Afiliado";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "crearcomercioafil", array()), "html", null, true);
        echo "</h4>
                                    <small class=\"font-bold\">Franklin Gold</small>
                                </div>
                                <div class=\"modal-body\">
                                    <form role=\"form\" id=\"crear_afiliado_form\">
                                        <div class=\"row\">
                                            <div class=\"col-md-6 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"nombre\" class=\"control-label mb-1\">Nombre";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "nombre", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                    <h5>*Todas las sucursales de un mismo comercio deben poseer el mismo nombre</h5>
                                                </div>
                                            </div>
                                            <div class=\"col-md-6 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"nombre\" class=\"control-label mb-1\">Sucursal";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "sucursal", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"sucursal\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"col-md-12 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"direccion\" class=\"control-label mb-1\">Dirección";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "direccion", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"direccion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                </div>
                                            </div>
                                        </div>
                                        <label class=\"control-label mb-1\">Télefonos";
        // line 34
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "telefono", array()), "html", null, true);
        echo "</label>
                                        <div class=\"row\">
                                            <div class=\"col-md-10 col-xs-10\">
                                                <div class=\"form-group\">
                                                    <input type=\"tel\" class=\"form-control\" name=\"telefono[0]\">
                                                  
                                                </div>
                                            </div>
                                            <div class=\"col-md-2 col-xs-2\">
                                                <a style=\"font-size:22px;\" title=\"Agregar Telefono\" onclick=\"addTel()\"><i class=\"fa fa-plus naranja\"></i></a>
                                            </div>
                                        </div>
                                        <div id=\"telefonos\">
                                            
                                        </div>
                                    </form>
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar";
        // line 52
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</button>
                                    <button type=\"button\" id=\"crearafiliadobtn\" class=\"btn btn-primary\">Crear";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "crear", array()), "html", null, true);
        echo "</button>
                                </div>
                            </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "afiliados/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 53,  90 => 52,  69 => 34,  61 => 29,  50 => 21,  40 => 14,  29 => 6,  25 => 5,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "afiliados/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\afiliados\\crear.twig");
    }
}

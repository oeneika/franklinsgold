<?php

/* ordenes/intercambiomoneda.twig */
class __TwigTemplate_ec498ce8ee5ea5f8cfc7f7b3f4044a798a6c2a9ab5b49ac82e8a03004b8d2ac6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "ordenes/intercambiomoneda.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "ordenes/intercambiomoneda.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-money\"></i> Intercambio</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Intercambiar gramos de oro o plata por monedas</strong>
                </li>
            </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Intercambiar</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                    <div class=\"ibox-content\">
                        <form id=\"crearOrdenIntercambio_form\">
                            <div class=\"row\">
                                
                                <div class=\"col-md-3 col-xs-12\">
                                    <div class=\"form-group\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\" >Oro o Plata</label>
                                        <select name=\"tipo_gramo\" id=\"id_tipo\" class=\"form-control\" style=\"width: 100%\">
                                            <option disabled selected value>Seleccione un tipo</option>
                                            <option value=\"oro\">Oro</option>
                                            <option value=\"plata\">Plata</option>
                                        </select>
                                    </div>                                   
                                </div>

                                <div class=\"col-md-3 col-xs-12\">
                                    <div class=\"form-group\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Gramos</label>
                                        <input name=\"cantidad\" id=\"id_cantidad\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                                    </div>                           
                                </div>

                                <div class=\"col-md-3 col-xs-12\">
                                    <div class=\"form-group\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\" >Sucursal</label>
                                        <select name=\"id_sucursal\" id=\"id_id_sucursal\" onchange=\"getMonedas()\" class=\"form-control\" style=\"width: 100%\">
                                            <option disabled selected value>Seleccione un sucursal</option>
                                            ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["sucursales"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            // line 64
            echo "                                                <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "id_sucursal", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "nombre", array()), "html", null, true);
            echo "</option>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                                        </select>
                                    </div>
                                </div>

                                <div class=\"col-md-3 col-xs-12\">
                                    <div class=\"form-group\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\" >Moneda</label>
                                        <select name=\"id_moneda\" id=\"id_id_moneda\" class=\"form-control selector_moneda\" style=\"width: 100%\">
                                            <option disabled selected value>Seleccione una moneda</option>                                              
                                        </select>
                                    </div>
                                </div>

                            </div>  
                            
                            <input name=\"tipo_orden\" id=\"id_tipo_orden\" value=\"3\" type=\"hidden\"> 
                            
                            <div class=\"row\">
                                <div class=\"col-md-3\">
                                    <button type=\"button\" id=\"crearOrdenIntercambio\" class=\"btn btn-primary\" style=\"width:100%\">Crear</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </div>
</div>
</div>
";
    }

    // line 97
    public function block_appFooter($context, array $blocks = array())
    {
        // line 98
        echo "<script src=\"./assets/jscontrollers/ordenes/crear.js\"></script>
<script>
    \$(document).ready(function(){
        showModal( ";
        // line 101
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo " , 0, ";
        echo twig_escape_filter($this->env, ($context["precio_bolivar"] ?? null), "html", null, true);
        echo " );
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "ordenes/intercambiomoneda.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 101,  148 => 98,  145 => 97,  112 => 66,  101 => 64,  97 => 63,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/intercambiomoneda.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\intercambiomoneda.twig");
    }
}

<?php

/* divisa/editar.twig */
class __TwigTemplate_5211b2664408ebd5898a39fbd308161e7799d1fc7503426bc09a2804c55a3efb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editardivisa\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span aria-hidden=\"true\">&times;</span>
                        <span class=\"sr-only\">Cerrar</span>
                    </button>
                    <h4 class=\"modal-title\">Edición de divisas</h4>
                    <small class=\"font-bold\">Franklin Gold</small>
                </div>
    
                <div class=\"modal-body\">
    
                    <form id=\"editar_divisa_form\">
                        <input name=\"id_divisa\" id=\"id_id_divisa\" type=\"hidden\">
    
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                <div class=\"form-group\">
                                    <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre</label>
                                    <input name=\"nombre\" id=\"id_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                </div>
                            </div>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"cc-payment\" class=\"control-label mb-1\">Precio Dólares
                                <span>*</span>
                            </label>
                            <input name=\"precio_dolares\" id=\"id_precio_dolares\" type=\"number\" class=\"form-control\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"cc-payment\" class=\"control-label mb-1\">Precio Dólares(venta)
                                <span>*</span>
                            </label>
                            <input name=\"precio_dolares_venta\" id=\"id_precio_dolares_venta\" type=\"number\" class=\"form-control\" >
                        </div>
                    </form>
    
                </div>
    
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                    <button type=\"button\" id=\"editardivisabtn\" class=\"btn btn-primary\">Guardar</button>
                </div>
            </div>
        </div>
    </div>";
    }

    public function getTemplateName()
    {
        return "divisa/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "divisa/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\divisa\\editar.twig");
    }
}

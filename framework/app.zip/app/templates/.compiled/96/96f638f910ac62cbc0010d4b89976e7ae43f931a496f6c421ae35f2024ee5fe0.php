<?php

/* divisa/divisa.twig */
class __TwigTemplate_17771656a32965f33953a252701a52634164b5ba9cdcf42dcbbd0d3c06a92f99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "divisa/divisa.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "divisa/divisa.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money-bill-alt\"></i> Divisa</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Divisa</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">

                <a onclick=\"crearDivisa()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-money-bill-alt\"></i> Crear divisa</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Divisa</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover tablita\">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nombre</th>
                                        <th>Precio en dólares(compra)</th>
                                        <th>Precio en dólares(venta)</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["divisas"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
            // line 54
            echo "                                    <tr>
                                        <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "id_divisa", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "nombre_divisa", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 57
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                        <td>";
            // line 58
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares_venta", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                        <td>
                                            <a onclick=\"editar_una_divisa(";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "id_divisa", array()), "html", null, true);
            echo ",'";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "nombre_divisa", array()), "html", null, true);
            echo "',";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares", array()), "html", null, true);
            echo ",";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares_venta", array()), "html", null, true);
            echo ")\" style=\"font-size:22px;\" title=\"Editar\">
                                                <i class=\"fa fa-sliders-h naranja\"></i>
                                            </a>
                                            <a onclick=\"delete_item(";
            // line 63
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "id_divisa", array()), "html", null, true);
            echo ",'divisa')\" style=\"font-size:22px;\" title=\"Eliminar\">
                                                <i class=\"fa fa-trash naranja\"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 69
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nombre</th>
                                        <th>Precio en dólares(compra)</th>
                                        <th>Precio en dólares(venta)</th>
                                        <th>Acciones</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
        // line 90
        $this->loadTemplate("divisa/crear", "divisa/divisa.twig", 90)->display($context);
        echo " 
    ";
        // line 91
        $this->loadTemplate("divisa/editar", "divisa/divisa.twig", 91)->display($context);
        // line 92
        echo "    ";
        $this->loadTemplate("overall/footer", "divisa/divisa.twig", 92)->display($context);
        // line 93
        echo "</div>
";
    }

    // line 95
    public function block_appFooter($context, array $blocks = array())
    {
        // line 96
        echo "    <script src=\"./assets/jscontrollers/divisa/crear.js\"></script>
    <script src=\"./assets/jscontrollers/divisa/editar.js\"></script>
    <script src=\"views/propios/js/delete_item.js\"></script>   
";
    }

    public function getTemplateName()
    {
        return "divisa/divisa.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 96,  177 => 95,  172 => 93,  169 => 92,  167 => 91,  163 => 90,  144 => 73,  135 => 69,  124 => 63,  112 => 60,  107 => 58,  103 => 57,  99 => 56,  95 => 55,  92 => 54,  87 => 53,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "divisa/divisa.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\divisa\\divisa.twig");
    }
}

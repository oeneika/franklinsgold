<?php

/* usuarios/usuarios.twig */
class __TwigTemplate_e3ea7a2a38e810c1e997ec775d6d1340b7c10344169b463eecaa334ffe929722 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "usuarios/usuarios.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "usuarios/usuarios.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-users\"></i> Usuarios</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Usuarios</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">

                <a onclick=\"crearUsuario()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-users\"></i> Crear Usuario</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Usuarios registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Tipo</th>
                                            <th>Nombre</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Teléfono</th>
                                            <th>Correo</th>
                                            <th>Entidad Bancaria</th>
                                            <th>Número de cuenta</th>
                                            <th width=\"30%\">Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["usuarios"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            echo "  
                                            <tr>
                                                <td>";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 59
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "es_sucursal", array()) == 1)) ? ("Sucursal") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "es_comercio_afiliado", array()) == 1)) ? ("Comercio afiliado") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()) == 0)) ? ("Administrador") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()) == 1)) ? ("Vendedor") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()) == 2)) ? ("Cliente") : ("Supervisor"))))))))));
            echo "</td>
                                                <td>";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_nombre", array()) == null)) ? ("") : (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_nombre", array()))), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_apellido", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_apellido", array()) == null)) ? ("") : (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_apellido", array()))), "html", null, true);
            echo "</td>                                       
                                                <td>";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "usuario", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 62
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "sexo", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 63
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "telefono", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 64
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "email", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 65
            echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "nombre_banco", array()) == null)) ? ("Las sucursales y comercios afiliados no poseen entidad bancaria") : (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "nombre_banco", array()))), "html", null, true);
            echo "</td>
                                                <td>";
            // line 66
            echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "numero_cuenta", array()) == null)) ? ("Las sucursales y comercios afiliados no poseen número de cuenta") : (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "numero_cuenta", array()))), "html", null, true);
            echo "</td>
                                                <td>
                                                
                                                ";
            // line 69
            if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_user", array()) != twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()))) {
                echo " 
                                                 
                                                    ";
                // line 72
                echo "                                                    ";
                if (((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "es_sucursal", array()) != 1) && (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "es_comercio_afiliado", array()) != 1))) {
                    echo "  
                                                    <a onclick=\"editar_un_usuario(";
                    // line 73
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()), "html", null, true);
                    echo ",";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()), "html", null, true);
                    echo ",'";
                    echo twig_escape_filter($this->env, (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo_cliente", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo_cliente", array())) : ("-1")), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_nombre", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_nombre", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "primer_apellido", array()), "html", null, true);
                    echo "',
                                                    '";
                    // line 74
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "segundo_apellido", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "sexo", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "telefono", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "nombre_banco", array()), "html", null, true);
                    echo "',";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "numero_cuenta", array()), "html", null, true);
                    echo ",";
                    echo twig_escape_filter($this->env, (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_sucursal", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_sucursal", array())) : ("-1")), "html", null, true);
                    echo ",";
                    echo twig_escape_filter($this->env, (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_comercio_afiliado", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_comercio_afiliado", array())) : ("-1")), "html", null, true);
                    echo ")\" style=\"font-size:20px;\" title=\"Editar\"  ><i class=\"fa fa-sliders-h naranja\"></i></a>

                                                    <a onclick=\"delete_item(";
                    // line 76
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()), "html", null, true);
                    echo ",'usuarios')\"style=\"font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                    ";
                }
                // line 78
                echo "
                                                    ";
                // line 79
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()) != 0)) {
                    echo "  
                                                        <a onclick=\"historialUsuario(";
                    // line 80
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "id_user", array()), "html", null, true);
                    echo ")\" style=\"font-size:20px;\" title=\"Historial\" >
                                                            <i class=\"fa fa-user naranja\"></i>
                                                        </a>
                                                    ";
                }
                // line 84
                echo "
                                                    ";
                // line 85
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "tipo", array()) == 2)) {
                    echo "  
                                                    <a onclick=\"documentosUsuario('";
                    // line 86
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "documento_identidad", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "pasaporte", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "rif", array()), "html", null, true);
                    echo "',
                                                                                    '";
                    // line 87
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "referencia_bancaria_1", array()), "html", null, true);
                    echo "','";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["u"], "referencia_bancaria_2", array()), "html", null, true);
                    echo "')\" style=\"font-size:20px;\" title=\"Documentos\" >
                                                        <i class=\"fa fa-folder-open naranja\"></i>
                                                    </a>
                                                    ";
                }
                // line 91
                echo "
                                                ";
            }
            // line 93
            echo "
                                                </td>
                                            </tr>
                                            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 97
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Tipo</th>
                                            <th>Nombre</th>
                                            <th>Usuario</th>
                                            <th>Sexo</th>
                                            <th>Teléfono</th>
                                            <th>Correo</th>
                                            <th>Número de cuenta</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
";
        // line 120
        $this->loadTemplate("usuarios/crear", "usuarios/usuarios.twig", 120)->display($context);
        // line 121
        $this->loadTemplate("usuarios/editar", "usuarios/usuarios.twig", 121)->display($context);
        // line 122
        $this->loadTemplate("usuarios/historial", "usuarios/usuarios.twig", 122)->display($context);
        // line 123
        $this->loadTemplate("usuarios/documentos", "usuarios/usuarios.twig", 123)->display($context);
        // line 124
        $this->loadTemplate("overall/footer", "usuarios/usuarios.twig", 124)->display($context);
        // line 125
        echo "</div>
";
    }

    // line 128
    public function block_appFooter($context, array $blocks = array())
    {
        // line 129
        echo "    <script src=\"./assets/jscontrollers/usuarios/showMinimenu.js\"></script>
    <script src=\"./assets/jscontrollers/usuarios/crear.js\"></script>
    <script src=\"./assets/jscontrollers/usuarios/editar.js\"></script>
    <script src=\"./assets/jscontrollers/usuarios/historial.js\"></script>   
    <script src=\"./assets/jscontrollers/usuarios/documentos.js\"></script>   
    <script src=\"views/propios/js/delete_item.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "usuarios/usuarios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  286 => 129,  283 => 128,  278 => 125,  276 => 124,  274 => 123,  272 => 122,  270 => 121,  268 => 120,  245 => 99,  238 => 97,  230 => 93,  226 => 91,  217 => 87,  209 => 86,  205 => 85,  202 => 84,  195 => 80,  191 => 79,  188 => 78,  183 => 76,  166 => 74,  152 => 73,  147 => 72,  142 => 69,  136 => 66,  132 => 65,  128 => 64,  124 => 63,  120 => 62,  116 => 61,  106 => 60,  102 => 59,  98 => 58,  90 => 56,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "usuarios/usuarios.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\usuarios.twig");
    }
}

<?php

/* overall/layout.twig */
class __TwigTemplate_b1e8058f75be4483ae10bff593ef64b0a054db44b87180d1638412da8c0172c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb18030\">
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"views/propios/img/favicon/favicon (1).ico\">
    <link rel=\"apple-touch-icon-precomposed\" href=\"views/propios/img/favicon/favicon (3).png\">
    <meta name=\"msapplication-TileColor\" content=\"#ffffff\" />
    <meta name=\"msapplication-TileImage\" content=\"views/propios/img/favicon/favicon (2).png\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.3.1/css/all.css\" integrity=\"sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU\" crossorigin=\"anonymous\">

    <!-- Select2 -->
    <link href=\"views/css/plugins/select2/select2.min.css\" rel=\"stylesheet\">

    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    <!-- DataTables -->
    <link href=\"views/css/plugins/dataTables/datatables.min.css\" rel=\"stylesheet\">

    <!-- SweetAlert -->
    <link href=\"views/css/plugins/sweetalert/sweetalert.css\" rel=\"stylesheet\">

    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"views/intl-tel-input-master/build/css/intlTelInput.css\" rel=\"stylesheet\">
    <link href=\"views/css/plugins/jasny/jasny-bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/css/style.css\" rel=\"stylesheet\">
    
    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    <style>
    strong.font-bold.hover:hover{
        color: #FFCF3D!important;
    }

    table thead tr th{
        font-size: 13px;
    }
    </style>

    ";
        // line 48
        $this->displayBlock('appHeader', $context, $blocks);
        // line 50
        echo "
    <title>";
        // line 51
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
</head>
<body class=\"pace-done\">
    <div id=\"wrapper\">
    ";
        // line 55
        $this->loadTemplate("overall/menu", "overall/layout.twig", 55)->display($context);
        // line 56
        echo "   
    ";
        // line 57
        $this->displayBlock('appBody', $context, $blocks);
        // line 60
        echo "    </div>


    ";
        // line 64
        echo "    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->
    <script src=\"assets/jscontrollers/overall/php.js\"></script>

    <!-- BOOTSTRAP-->
    <script src=\"views/js/bootstrap.js\"></script>

    <script src=\"views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Select2 -->
    <script src=\"views/js/plugins/select2/select2.full.min.js\"></script>

    <!-- SweetAlert-->
    <script src=\"https://unpkg.com/sweetalert/dist/sweetalert.min.js\"></script>

    <!-- Flot -->
    <script src=\"views/js/plugins/flot/jquery.flot.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.tooltip.min.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.spline.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.resize.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.pie.js\"></script>

    <!-- Peity -->
    <script src=\"views/js/plugins/peity/jquery.peity.min.js\"></script>
    <script src=\"views/js/demo/peity-demo.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"views/js/inspinia.js\"></script>
    <script src=\"views/js/plugins/pace/pace.min.js\"></script>

    <!-- jQuery UI -->
    <script src=\"views/js/plugins/jquery-ui/jquery-ui.min.js\"></script>

    <!-- GITTER -->
    <script src=\"views/js/plugins/gritter/jquery.gritter.min.js\"></script>

    <!-- Sweetalert -->
    <script src=\"views/js/plugins/sweetalert/sweetalert.min.js\"></script>

    <!-- Jvectormap -->
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js\"></script>
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>

    <!-- Sparkline -->
    <script src=\"views/js/plugins/sparkline/jquery.sparkline.min.js\"></script>

    <!-- Sparkline demo data  -->
    <script src=\"views/js/demo/sparkline-demo.js\"></script>

    <!-- ChartJS-->
    <script src=\"views/js/plugins/chartJs/Chart.min.js\"></script>
    
    <script src=\"views/js/plugins/jasny/jasny-bootstrap.min.js\"></script>



    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    <script src=\"views/js/plugins/dataTables/datatables.min.js\"></script>
    <script src=\"views/propios/js/datatable.js\"></script>

    <script src=\"views/intl-tel-input-master/build/js/intlTelInput.js\"></script>

    <script>
    \$( document ).ready(function() {
        \$(\".select2\").select2({
            language: {

            noResults: function() {

              return \"No hay resultado\";        
            },
            searching: function() {

              return \"Buscando..\";
            }
          },
            dropdownCssClass:'increasezindex',
            width: 'resolve',
            closeOnSelect: false,
            dropdownParent: \$('.jiji')
        });
    });
    </script>

    <script>
                function direccionamiento(lugar) {
                    switch (lugar) {
                        case \"home\":
                            location.href = \"home/\";
                            break;
                        default:
                            console.log(\"No existe \");
                    }
                }
    </script>

    
";
        // line 165
        $this->displayBlock('appFooter', $context, $blocks);
        // line 167
        echo "

</body>
</html>";
    }

    // line 48
    public function block_appHeader($context, array $blocks = array())
    {
        // line 49
        echo "    ";
    }

    // line 57
    public function block_appBody($context, array $blocks = array())
    {
        // line 58
        echo "    
    ";
    }

    // line 165
    public function block_appFooter($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  225 => 165,  220 => 58,  217 => 57,  213 => 49,  210 => 48,  203 => 167,  201 => 165,  98 => 64,  93 => 60,  91 => 57,  88 => 56,  86 => 55,  79 => 51,  76 => 50,  74 => 48,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb18030\">
    {# Formato #}
    {{ base_assets()|raw }}
    
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">

    <link rel=\"icon\" type=\"image/x-icon\" href=\"views/propios/img/favicon/favicon (1).ico\">
    <link rel=\"apple-touch-icon-precomposed\" href=\"views/propios/img/favicon/favicon (3).png\">
    <meta name=\"msapplication-TileColor\" content=\"#ffffff\" />
    <meta name=\"msapplication-TileImage\" content=\"views/propios/img/favicon/favicon (2).png\">


    <link href=\"views/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.3.1/css/all.css\" integrity=\"sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU\" crossorigin=\"anonymous\">

    <!-- Select2 -->
    <link href=\"views/css/plugins/select2/select2.min.css\" rel=\"stylesheet\">

    <!-- Toastr style -->
    <link href=\"views/css/plugins/toastr/toastr.min.css\" rel=\"stylesheet\">

    <!-- DataTables -->
    <link href=\"views/css/plugins/dataTables/datatables.min.css\" rel=\"stylesheet\">

    <!-- SweetAlert -->
    <link href=\"views/css/plugins/sweetalert/sweetalert.css\" rel=\"stylesheet\">

    <link href=\"views/css/animate.css\" rel=\"stylesheet\">
    <link href=\"views/intl-tel-input-master/build/css/intlTelInput.css\" rel=\"stylesheet\">
    <link href=\"views/css/plugins/jasny/jasny-bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"views/css/style.css\" rel=\"stylesheet\">
    
    <link href=\"views/propios/css/estilo.css\" rel=\"stylesheet\">

    <style>
    strong.font-bold.hover:hover{
        color: #FFCF3D!important;
    }

    table thead tr th{
        font-size: 13px;
    }
    </style>

    {% block appHeader %}
    {% endblock %}

    <title>{{ config.build.name }}</title>
</head>
<body class=\"pace-done\">
    <div id=\"wrapper\">
    {% include 'overall/menu' %}
   
    {% block appBody %}
    
    {% endblock %}
    </div>


    {# Sólamente necesario para facilitar las peticiones AJAX del generador, puede eliminarse #}
    <script src=\"views/propios/js/jquery.min.js\"></script>

    <!-- Mainly scripts -->
    <script src=\"assets/jscontrollers/overall/php.js\"></script>

    <!-- BOOTSTRAP-->
    <script src=\"views/js/bootstrap.js\"></script>

    <script src=\"views/js/plugins/metisMenu/jquery.metisMenu.js\"></script>
    <script src=\"views/js/plugins/slimscroll/jquery.slimscroll.min.js\"></script>

    <!-- Select2 -->
    <script src=\"views/js/plugins/select2/select2.full.min.js\"></script>

    <!-- SweetAlert-->
    <script src=\"https://unpkg.com/sweetalert/dist/sweetalert.min.js\"></script>

    <!-- Flot -->
    <script src=\"views/js/plugins/flot/jquery.flot.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.tooltip.min.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.spline.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.resize.js\"></script>
    <script src=\"views/js/plugins/flot/jquery.flot.pie.js\"></script>

    <!-- Peity -->
    <script src=\"views/js/plugins/peity/jquery.peity.min.js\"></script>
    <script src=\"views/js/demo/peity-demo.js\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"views/js/inspinia.js\"></script>
    <script src=\"views/js/plugins/pace/pace.min.js\"></script>

    <!-- jQuery UI -->
    <script src=\"views/js/plugins/jquery-ui/jquery-ui.min.js\"></script>

    <!-- GITTER -->
    <script src=\"views/js/plugins/gritter/jquery.gritter.min.js\"></script>

    <!-- Sweetalert -->
    <script src=\"views/js/plugins/sweetalert/sweetalert.min.js\"></script>

    <!-- Jvectormap -->
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js\"></script>
    <script src=\"views/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>

    <!-- Sparkline -->
    <script src=\"views/js/plugins/sparkline/jquery.sparkline.min.js\"></script>

    <!-- Sparkline demo data  -->
    <script src=\"views/js/demo/sparkline-demo.js\"></script>

    <!-- ChartJS-->
    <script src=\"views/js/plugins/chartJs/Chart.min.js\"></script>
    
    <script src=\"views/js/plugins/jasny/jasny-bootstrap.min.js\"></script>



    <!-- Toastr -->
    <script src=\"views/js/plugins/toastr/toastr.min.js\"></script>

    <script src=\"views/js/plugins/dataTables/datatables.min.js\"></script>
    <script src=\"views/propios/js/datatable.js\"></script>

    <script src=\"views/intl-tel-input-master/build/js/intlTelInput.js\"></script>

    <script>
    \$( document ).ready(function() {
        \$(\".select2\").select2({
            language: {

            noResults: function() {

              return \"No hay resultado\";        
            },
            searching: function() {

              return \"Buscando..\";
            }
          },
            dropdownCssClass:'increasezindex',
            width: 'resolve',
            closeOnSelect: false,
            dropdownParent: \$('.jiji')
        });
    });
    </script>

    <script>
                function direccionamiento(lugar) {
                    switch (lugar) {
                        case \"home\":
                            location.href = \"home/\";
                            break;
                        default:
                            console.log(\"No existe \");
                    }
                }
    </script>

    
{% block appFooter %}
{% endblock %}


</body>
</html>", "overall/layout.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\layout.twig");
    }
}

<?php

/* calculadora/calculadora.twig */
class __TwigTemplate_f7d2f85cf1f6b4283f1530b4280476201a6cc033a426cbb2d6c80c62299b49a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "calculadora/calculadora.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
\t<div class=\"row border-bottom\">
\t    ";
        // line 5
        $this->loadTemplate("overall/header", "calculadora/calculadora.twig", 5)->display($context);
        // line 6
        echo "\t</div>
\t<div class=\"row wrapper border-bottom white-bg page-heading\">
\t    <div class=\"col-lg-10\">
\t        <h2><i class=\"fa fa-calculator\"></i> Conversor de dívisas ";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "conversordiv", array()), "html", null, true);
        echo "</h2>
\t\t\t\t<ol class=\"breadcrumb\">
\t\t\t\t\t<li>
\t\t\t\t\t\t<a href=\"home/\">Home</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t<strong>Conversor ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "conversor", array()), "html", null, true);
        echo "</strong>
\t\t\t\t\t</li>
\t\t\t\t</ol>
\t    </div>
\t</div>

\t<div class=\"wrapper wrapper-content animated fadeInRight\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<div class=\"ibox float-e-margins\">
                    <div class=\"ibox-content\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"divisa_inicial\" class=\"control-label mb-1\" >De la dívisa ";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "divisa", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<select name=\"divisa_inicial\" id=\"id_divisa_inicial\" onchange=\"changePrice()\" class=\"form-control\" style=\"width: 100%\">
\t\t\t\t\t\t\t\t\t\t<option disabled selected value>Seleccione una dívisa ";
        // line 32
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "selecdivisa", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 33
        echo twig_escape_filter($this->env, ($context["ultimo_precio_oro"] ?? null), "html", null, true);
        echo "\">Oro(Onza) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "oroonza", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 34
        echo twig_escape_filter($this->env, (($context["ultimo_precio_oro"] ?? null) / 28.3495), "html", null, true);
        echo "\">Oro(Gramo) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "orogramo", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 35
        echo twig_escape_filter($this->env, ($context["ultimo_precio_plata"] ?? null), "html", null, true);
        echo "\">Plata(Onza) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "plataonza", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 36
        echo twig_escape_filter($this->env, (($context["ultimo_precio_plata"] ?? null) / 28.3495), "html", null, true);
        echo "\">Plata(Gramo) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "platagramo", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["divisas"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
            // line 38
            echo "\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "nombre_divisa", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"precio_divisa_inicial\">Precio(Dólares por unidad) ";
        // line 46
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "preciodol", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<input name=\"precio_divisa_inicial\" id=\"id_precio_divisa_inicial\" type=\"number\" onchange=\"changeMontoInicial()\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"cantidad_divisa_inicial\">Cantidad dívisa inicial ";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "cantidaddiv", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<input name=\"cantidad_divisa_inicial\" id=\"id_cantidad_divisa_inicial\" type=\"number\" onchange=\"changeMontoInicial()\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"monto_inicial\">Monto(Dólares) ";
        // line 60
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "montodol", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<input name=\"monto_inicial\" id=\"id_monto_inicial\" type=\"text\" readonly=\"readonly\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"divisa_final\" class=\"control-label mb-1\" >A la dívisa ";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "aladivisa", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<select name=\"divisa_final\" id=\"id_divisa_final\" class=\"form-control\" style=\"width: 100%\">
\t\t\t\t\t\t\t\t\t\t\t<option disabled selected value>Seleccione una dívisa ";
        // line 69
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "selecdivisa", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 70
        echo twig_escape_filter($this->env, ($context["ultimo_precio_oro"] ?? null), "html", null, true);
        echo "\">Oro(Onza)  ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "oroonza", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 71
        echo twig_escape_filter($this->env, (($context["ultimo_precio_oro"] ?? null) / 28.3495), "html", null, true);
        echo "\">Oro(Gramo) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "orogramo", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 72
        echo twig_escape_filter($this->env, ($context["ultimo_precio_plata"] ?? null), "html", null, true);
        echo "\">Plata(Onza) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "plataonza", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
        // line 73
        echo twig_escape_filter($this->env, (($context["ultimo_precio_plata"] ?? null) / 28.3495), "html", null, true);
        echo "\">Plata(Gramo) ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "platagramo", array()), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["divisas"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
            // line 75
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio_dolares", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "nombre_divisa", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" id=\"convertirDivisabtn\" class=\"btn btn-primary\">Convertir ";
        // line 83
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "convertir", array()), "html", null, true);
        echo "</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"monto_final\">Equivalente ";
        // line 89
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappercal", array()), "equivalente", array()), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<input name=\"monto_final\" id=\"id_monto_final\" type=\"text\" readonly=\"readonly\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
                    </div>
                </div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
    }

    // line 103
    public function block_appFooter($context, array $blocks = array())
    {
        // line 104
        echo "<script src=\"./assets/jscontrollers/calculadora/calculadora.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "calculadora/calculadora.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  241 => 104,  238 => 103,  221 => 89,  212 => 83,  204 => 77,  193 => 75,  189 => 74,  183 => 73,  177 => 72,  171 => 71,  165 => 70,  161 => 69,  156 => 67,  146 => 60,  136 => 53,  126 => 46,  118 => 40,  107 => 38,  103 => 37,  97 => 36,  91 => 35,  85 => 34,  79 => 33,  75 => 32,  70 => 30,  52 => 15,  43 => 9,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
\t<div class=\"row border-bottom\">
\t    {% include 'overall/header' %}
\t</div>
\t<div class=\"row wrapper border-bottom white-bg page-heading\">
\t    <div class=\"col-lg-10\">
\t        <h2><i class=\"fa fa-calculator\"></i> Conversor de dívisas {{lang.wrappercal.conversordiv}}</h2>
\t\t\t\t<ol class=\"breadcrumb\">
\t\t\t\t\t<li>
\t\t\t\t\t\t<a href=\"home/\">Home</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t<strong>Conversor {{lang.wrappercal.conversor}}</strong>
\t\t\t\t\t</li>
\t\t\t\t</ol>
\t    </div>
\t</div>

\t<div class=\"wrapper wrapper-content animated fadeInRight\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<div class=\"ibox float-e-margins\">
                    <div class=\"ibox-content\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"divisa_inicial\" class=\"control-label mb-1\" >De la dívisa {{lang.wrappercal.divisa}}</label>
\t\t\t\t\t\t\t\t\t<select name=\"divisa_inicial\" id=\"id_divisa_inicial\" onchange=\"changePrice()\" class=\"form-control\" style=\"width: 100%\">
\t\t\t\t\t\t\t\t\t\t<option disabled selected value>Seleccione una dívisa {{lang.wrappercal.selecdivisa}}</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_oro}}\">Oro(Onza) {{lang.wrappercal.oroonza}}</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_oro / 28.3495}}\">Oro(Gramo) {{lang.wrappercal.orogramo}}</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_plata}}\">Plata(Onza) {{lang.wrappercal.plataonza}}</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_plata / 28.3495}}\">Plata(Gramo) {{lang.wrappercal.platagramo}}</option>
\t\t\t\t\t\t\t\t\t\t{% for d in divisas %}
\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{d.precio_dolares}}\">{{d.nombre_divisa}}</option>
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"precio_divisa_inicial\">Precio(Dólares por unidad) {{lang.wrappercal.preciodol}}</label>
\t\t\t\t\t\t\t\t\t<input name=\"precio_divisa_inicial\" id=\"id_precio_divisa_inicial\" type=\"number\" onchange=\"changeMontoInicial()\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"cantidad_divisa_inicial\">Cantidad dívisa inicial {{lang.wrappercal.cantidaddiv}}</label>
\t\t\t\t\t\t\t\t\t<input name=\"cantidad_divisa_inicial\" id=\"id_cantidad_divisa_inicial\" type=\"number\" onchange=\"changeMontoInicial()\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<div class=\"col-md-3 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"monto_inicial\">Monto(Dólares) {{lang.wrappercal.montodol}}</label>
\t\t\t\t\t\t\t\t\t<input name=\"monto_inicial\" id=\"id_monto_inicial\" type=\"text\" readonly=\"readonly\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"divisa_final\" class=\"control-label mb-1\" >A la dívisa {{lang.wrappercal.aladivisa}}</label>
\t\t\t\t\t\t\t\t\t<select name=\"divisa_final\" id=\"id_divisa_final\" class=\"form-control\" style=\"width: 100%\">
\t\t\t\t\t\t\t\t\t\t\t<option disabled selected value>Seleccione una dívisa {{lang.wrappercal.selecdivisa}}</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_oro}}\">Oro(Onza)  {{lang.wrappercal.oroonza}}</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_oro / 28.3495}}\">Oro(Gramo) {{lang.wrappercal.orogramo}}</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_plata}}\">Plata(Onza) {{lang.wrappercal.plataonza}}</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{ultimo_precio_plata / 28.3495}}\">Plata(Gramo) {{lang.wrappercal.platagramo}}</option>
\t\t\t\t\t\t\t\t\t\t\t{% for d in divisas %}
\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"{{d.precio_dolares}}\">{{d.nombre_divisa}}</option>
\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" id=\"convertirDivisabtn\" class=\"btn btn-primary\">Convertir {{lang.wrappercal.convertir}}</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-md-12 col-xs-12\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label for=\"monto_final\">Equivalente {{lang.wrappercal.equivalente}}</label>
\t\t\t\t\t\t\t\t\t<input name=\"monto_final\" id=\"id_monto_final\" type=\"text\" readonly=\"readonly\" class=\"form-control\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
                    </div>
                </div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
{% endblock %}

{% block appFooter %}
<script src=\"./assets/jscontrollers/calculadora/calculadora.js\"></script>
{% endblock %}", "calculadora/calculadora.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\calculadora\\calculadora.twig");
    }
}

<?php

/* ordenes/intercambio.twig */
class __TwigTemplate_6f8d362ef8bf62a80b5fd0b5ea162fd5992870f046bd6805206e9bc3a6228789 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"intercambioModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Intercambio de gramos de Oro o Plata</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crearOrdenIntercambio_form\">
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\" >Oro o Plata</label>
                                <select name=\"tipo_gramo\" id=\"id_tipo_intercambio\" onchange=\"resetMonto('id_cantidad_intercambio','id_monto_intercambio','id_tipo_intercambio')\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un tipo</option>
                                    <option value=\"oro\">Oro</option>
                                    <option value=\"plata\">Plata</option>
                                </select>
                            </div>
                            
                        </div>
                        <div class=\"col-md-2 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Gramos</label>
                                <input name=\"cantidad\" id=\"id_cantidad_intercambio\" type=\"number\" onchange=\"resetMonto('id_cantidad_intercambio','id_monto_intercambio','id_tipo_intercambio')\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                            </div>                           
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Monto \$</label>
                                <input id=\"id_monto_intercambio\" type=\"text\" readonly=\"readonly\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                            </div>                           
                        </div>
                        ";
        // line 48
        echo "                        <div class=\"col-md-6 col-xs-12\">
                        <div class=\"form-group\">
                            <label for=\"cc-payment\" class=\"control-label mb-1\" >Moneda</label>
                            <select name=\"id_moneda\" id=\"id_id_moneda\" class=\"form-control selector_moneda\" style=\"width: 100%\">
                                <option disabled selected value>Seleccione una moneda</option>
                                
                            </select>
                        </div>
                        </div>
                    </div>  

                    <input name=\"id_usuario\" value=\"";
        // line 59
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_user", array()), "html", null, true);
        echo "\" type=\"hidden\">
                    <input name=\"tipo_orden\" value=\"3\" type=\"hidden\"> 
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrdenIntercambio\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "ordenes/intercambio.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 59,  57 => 48,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/intercambio.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\intercambio.twig");
    }
}

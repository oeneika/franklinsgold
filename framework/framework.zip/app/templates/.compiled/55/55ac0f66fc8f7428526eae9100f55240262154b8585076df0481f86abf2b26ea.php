<?php

/* monedas/crear.twig */
class __TwigTemplate_afe672941e16f47f61c3cb463729b0c4481ab8483150cb99a88ac615907a06eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearMoneda\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Monedas</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"crear_moneda_form\">
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"diametro\" class=\"control-label mb-1\">Diámetro <span>*</span></label>
                                <input name=\"diametro\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"espesor\" class=\"control-label mb-1\">Espesor<span>*</span></label>
                                <input name=\"espesor\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"composicion\" class=\"control-label mb-1\">Composición<span>*</span></label>
                                <select class=\"form-control\" name=\"composicion\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                        <option selected disabled value></option> 
                                        <option value=\"oro\">Oro</option> 
                                        <option value=\"plata\">Plata</option>                                  
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"peso\" class=\"control-label mb-1\">Peso<span>*</span></label>
                                <input name=\"peso\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"origen\" class=\"control-label mb-1\">Origen<span>*</span></label>                               
                                <select class=\"form-control\" name=\"id_origen\"  aria-required=\"true\" aria-invalid=\"false\">
                                    <option selected disabled value></option>
                                    ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["origenes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["ori"]) {
            // line 48
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["ori"], "id_origen", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["ori"], "nombre", array()), "html", null, true);
            echo "</option>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ori'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                                </select>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <label for=\"cc-payment\" class=\"control-label mb-1\">Sucursal<span>*</span></label>
                            <select name=\"id_sucursal\" id=\"\" class=\"form-control m-b\" style=\"width: 100%\">
                                <option selected value>Seleccione una sucursal</option>
                                    ";
        // line 59
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["sucursales"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "id_user", array()))) {
                // line 60
                echo "                                        <option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "id_sucursal", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "nombre", array()), "html", null, true);
                echo "</option>
                                    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearMonedabtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "monedas/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 62,  98 => 60,  93 => 59,  82 => 50,  71 => 48,  67 => 47,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "monedas/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\monedas\\crear.twig");
    }
}

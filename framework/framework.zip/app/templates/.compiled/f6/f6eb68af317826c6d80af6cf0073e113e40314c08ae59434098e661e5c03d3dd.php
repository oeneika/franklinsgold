<?php

/* sucursal/editar.twig */
class __TwigTemplate_cb8f563c2a6438c28c10c925a606ef7c3b616393bab77026f0e62ee02f4937eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarSucursal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Sucursal</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                                            <form role=\"form\" id=\"editar_sucursal_form\">
                                                <input type=\"hidden\" id=\"id_edit_sucursal\" name=\"id_sucursal\">
                                                <input type=\"hidden\" id=\"id_edit_user\" name=\"id_user\">
                                                <div class=\"row\">
                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"nombre\" class=\"control-label mb-1\">Nombre</label>
                                                            <input id=\"id_edit_nombre\" name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>

                                                    <div class=\"col-md-6 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"telefono\" class=\"control-label mb-1\">Teléfono</label>
                                                            <input name=\"telefono\" id=\"id_edit_telefono\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>

                                                    <div class=\"col-md-12 col-xs-12\">
                                                        <div class=\"form-group\">
                                                            <label for=\"direccion\" class=\"control-label mb-1\">Dirección</label>
                                                            <input id=\"id_edit_direccion\" name=\"direccion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editarsucursalbtn\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "sucursal/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "sucursal/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\sucursal\\editar.twig");
    }
}

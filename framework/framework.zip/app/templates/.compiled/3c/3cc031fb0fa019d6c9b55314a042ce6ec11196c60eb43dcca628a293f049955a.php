<?php

/* login/login.twig */
class __TwigTemplate_c405b48c4b195a8b2735b0a766822e48e8b528fd0030a18dcbdcf0b9b7b518a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-404", "login/login.twig", 1);
        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-404";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_appHeader($context, array $blocks = array())
    {
        // line 4
        echo "<link rel=\"stylesheet\" href=\"views/propios/css/estiloLogin.css\">
";
    }

    // line 8
    public function block_appBody($context, array $blocks = array())
    {
        // line 9
        echo "
<div class=\"middle-box text-center loginscreen animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:200px;\" /></h1>

            </div>
            <h3 class=\"login-text\">Bienvenido a Franklin Gold</h3>
            <form class=\"m-t\" role=\"form\" id=\"login_form\">
                <div class=\"form-group\">
                    <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"E-mail\">
                </div>
                <div class=\"form-group\">
                    <input type=\"password\" name=\"pass\" class=\"form-control\" placeholder=\"Clave\">
                </div>
                <button type=\"button\" id='login' class=\"btn btn-primary block full-width m-b\">INICIAR SESIÓN</button>

                <a data-toggle=\"modal\" data-target=\"#lostpassModal\" style=\"color:#fec401\"><small>¿Olvidaste tu clave?</small></a>
                </br>
                </br>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <p class=\"text-muted text-center\"><small style=\"color:wheat;\">¿Aún no estás registrado en el sistema?</small></p>
                        <a class=\"btn btn-sm btn-white btn-block\" href=\"registro/\">¡REGISTRATE!</a>
                    </div>
                    <div class=\"col-md-6\">
                        <p class=\"text-muted text-center\"><small style=\"color:wheat;\">¿Deseas volver a la pagina principal?</small></p>
                        <a class=\"btn btn-sm btn-white btn-block\" href=\"inicio\">Inicio</a>
                    </div>
                </div>
                
                
            </form>
        </div>
</div>

";
        // line 46
        $this->loadTemplate("login/lostpass", "login/login.twig", 46)->display($context);
        // line 47
        echo "
";
    }

    // line 49
    public function block_appFooter($context, array $blocks = array())
    {
        // line 50
        echo "    <script src=\"./assets/jscontrollers/login/login.js\"></script>
    <script src=\"./assets/jscontrollers/login/lostpass.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "login/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 50,  87 => 49,  82 => 47,  80 => 46,  41 => 9,  38 => 8,  33 => 4,  30 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "login/login.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\login\\login.twig");
    }
}

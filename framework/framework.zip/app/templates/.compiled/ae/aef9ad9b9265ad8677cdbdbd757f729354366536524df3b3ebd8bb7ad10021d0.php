<?php

/* transaccion/compra.twig */
class __TwigTemplate_61059a89d345169b9c2094f24f84f599681477eb86f2702cccc010d4898d13b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "transaccion/compra.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "transaccion/compra.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money-check-alt\"></i> Compras</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Compras</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <a onclick=\"crearTransaccion(1)\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-tags\"></i> Crear Compra</a>

                <a onclick=\"confirmarTransaccion()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-check\"></i> Confirmar Transacción</a>

                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Compras registradas en el sistema</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover tablita\">
                                <thead>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        ";
        // line 54
        echo "                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 58
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transacciones"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 59
            echo "                                    <tr>
                                        <td>";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id_transaccion", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_apellido", array()), "html", null, true);
            echo " </td>
                                        <td>";
            // line 62
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "codigo", array()), "html", null, true);
            echo "</td>
                                        <td>\$";
            // line 63
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "precio_moneda", array()), 2, ".", ","), "html", null, true);
            echo "</td>
                                        ";
            // line 66
            echo "                                        <td>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "fecha", array())), "html", null, true);
            echo "</td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 69
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        ";
        // line 82
        echo "                                        <th>Fecha</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
        // line 93
        $this->loadTemplate("transaccion/crear", "transaccion/compra.twig", 93)->display($context);
        echo " 
    ";
        // line 94
        $this->loadTemplate("transaccion/confirmar", "transaccion/compra.twig", 94)->display($context);
        echo " 
    ";
        // line 95
        $this->loadTemplate("overall/footer", "transaccion/compra.twig", 95)->display($context);
        // line 96
        echo "</div>
";
    }

    // line 98
    public function block_appFooter($context, array $blocks = array())
    {
        // line 99
        echo "    <script>var usuarios = ";
        echo json_encode(($context["usuarios"] ?? null));
        echo "</script>
    <script src=\"./assets/jscontrollers/transaccion/crear.js\"></script> 
    <script src=\"./assets/jscontrollers/transaccion/confirmar.js\"></script> 
    
";
    }

    public function getTemplateName()
    {
        return "transaccion/compra.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 99,  173 => 98,  168 => 96,  166 => 95,  162 => 94,  158 => 93,  145 => 82,  136 => 73,  127 => 69,  118 => 66,  114 => 63,  110 => 62,  104 => 61,  100 => 60,  97 => 59,  92 => 58,  86 => 54,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "transaccion/compra.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\compra.twig");
    }
}

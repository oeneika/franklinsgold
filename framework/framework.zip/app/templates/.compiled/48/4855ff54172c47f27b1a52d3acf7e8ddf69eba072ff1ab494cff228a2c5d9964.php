<?php

/* ordenes/compraventatienda.twig */
class __TwigTemplate_f6009960547540ab5834579c0d771951d49cca9f0bee9bfd6e44cb758c35445e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal jiji\" id=\"compraventatiendaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Compra ó venta de gramos de Oro ó Plata</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crearOrdenCompraVentaTienda_form\">
                    <div class=\"row\">
                       
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_orden_transaccion\" class=\"control-label mb-1\" >Tipo transacción</label>
                                <select name=\"tipo_orden\" id=\"id_tipo_orden_transaccion\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"1\">Compra</option>
                                    <option value=\"2\">Venta</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cliente\" class=\"control-label mb-1\" >Clientes</label>
                                <select name=\"email\" id=\"id_cliente\" class=\"form-control select2\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un cliente</option>
                                    ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["clientes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            echo "       
                                         <option value=\"";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "email", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "email", array()), "html", null, true);
            echo "</option>
                                     ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "                                </select>
                            </div>
                        </div> 

                    </div>
                    <div class=\"row\">

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_gramo\" class=\"control-label mb-1\" >Tipo metal</label>
                                <select name=\"tipo_gramo\" id=\"id_tipo_gramo\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"oro\">Oro</option>
                                    <option value=\"plata\">Plata</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cantidad\" class=\"control-label mb-1\" >Cantidad(gramos)</label>
                                <input name=\"cantidad\" id=\"cantidad\" type=\"number\" class=\"form-control\"> 
                            </div>                         
                        </div>

                    </div>

                    <input name=\"compra_tienda\" type=\"hidden\" value=\"50000\"> 
                                          
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrdenCompraVentaTienda\" class=\"btn btn-primary\">Crear</button>
            </div>
            
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "ordenes/compraventatienda.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 34,  57 => 32,  51 => 31,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal jiji\" id=\"compraventatiendaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Compra ó venta de gramos de Oro ó Plata</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crearOrdenCompraVentaTienda_form\">
                    <div class=\"row\">
                       
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_orden_transaccion\" class=\"control-label mb-1\" >Tipo transacción</label>
                                <select name=\"tipo_orden\" id=\"id_tipo_orden_transaccion\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"1\">Compra</option>
                                    <option value=\"2\">Venta</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cliente\" class=\"control-label mb-1\" >Clientes</label>
                                <select name=\"email\" id=\"id_cliente\" class=\"form-control select2\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un cliente</option>
                                    {% for c in clientes %}       
                                         <option value=\"{{c.email}}\">{{c.email}}</option>
                                     {% endfor %}
                                </select>
                            </div>
                        </div> 

                    </div>
                    <div class=\"row\">

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_gramo\" class=\"control-label mb-1\" >Tipo metal</label>
                                <select name=\"tipo_gramo\" id=\"id_tipo_gramo\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"oro\">Oro</option>
                                    <option value=\"plata\">Plata</option>
                                </select>
                            </div>                         
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cantidad\" class=\"control-label mb-1\" >Cantidad(gramos)</label>
                                <input name=\"cantidad\" id=\"cantidad\" type=\"number\" class=\"form-control\"> 
                            </div>                         
                        </div>

                    </div>

                    <input name=\"compra_tienda\" type=\"hidden\" value=\"50000\"> 
                                          
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrdenCompraVentaTienda\" class=\"btn btn-primary\">Crear</button>
            </div>
            
        </div>
    </div>
</div>
", "ordenes/compraventatienda.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\compraventatienda.twig");
    }
}

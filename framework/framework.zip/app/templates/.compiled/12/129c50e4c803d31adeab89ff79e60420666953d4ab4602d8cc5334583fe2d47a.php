<?php

/* ordenes/ordenes.twig */
class __TwigTemplate_f07eaf991c8a0c04b7350473fc7b2221128baf0f802c7c0b392e08af5152a2d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "ordenes/ordenes.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "ordenes/ordenes.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-shopping-cart\"></i> Ordenes</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Ordenes</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
        <div class=\"col-md-12\">
        <a onclick=\"showModal(0,0,0,'compraventatiendaModal')\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;margin-left:5px;\"><i class=\"fa fa-check\"></i> Compra o venta</a>
        </div>
    </div>
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Ordenes registradas en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Usuario</th>
                                            <th>Número de cuenta</th>
                                            <!--<th>Sucursal</th>-->
                                            <th>Composición</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Monto(USD)</th>
                                            <th>Tipo Orden</th>
                                            <th>Estado</th>
                                            <th>Fecha Creación</th>
                                            <th>Moneda</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ordenes"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["o"]) {
            echo "  
                                            <tr>
                                                <td>";
            // line 64
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_orden", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 65
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "primer_apellido", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 66
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "numero_cuenta", array()), "html", null, true);
            echo "</td>
                                                ";
            // line 68
            echo "                                                <td>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "tipo_gramo", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 69
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 70
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td>";
            // line 71
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td style=\"";
            // line 72
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "tipo_orden", array()) == 1)) ? ("color: green;") : ("color: red;"));
            echo "\">";
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "tipo_orden", array()) == 1)) ? ("Compra") : ("Venta"));
            echo "</td>
                                                <td>";
            // line 73
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 1)) ? ("Sin confirmaciones") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 2)) ? ("Confirmada por vendedor") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 3)) ? ("Confirmada por supervisor") : ("Confirmada totalmente"))))));
            echo "</td>
                                                <td>";
            // line 74
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "fecha", array())), "html", null, true);
            echo "</td>
                                                <td>";
            // line 75
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "codigo_moneda", array()), "html", null, true);
            echo "</td>
                                                <td>
                                                 ";
            // line 77
            if (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 1) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 1))) {
                echo " 
                                                 <a style=\"font-size:22px;\" title=\"Confirmación 1\" data-toggle=\"modal\" onclick=\"confirm_orden(";
                // line 78
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_orden", array()), "html", null, true);
                echo ",'vendedor')\"><i class=\"fa fa-sliders-h naranja\"></i></a>                
                                                 ";
            }
            // line 79
            echo " 

                                                 ";
            // line 81
            if (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 2) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 3))) {
                echo " 
                                                 <a style=\"font-size:22px;\" title=\"Confirmación 2\" data-toggle=\"modal\" onclick=\"confirm_orden(";
                // line 82
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_orden", array()), "html", null, true);
                echo ",'supervisor')\"><i class=\"fa fa-sliders-h naranja\"></i></a>                
                                                 ";
            }
            // line 83
            echo " 

                                                 ";
            // line 85
            if (((twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "estado", array()) == 3) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0))) {
                echo " 
                                                 <a style=\"font-size:22px;\" title=\"Concretar\" data-toggle=\"modal\" onclick=\"specify_orden(";
                // line 86
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_orden", array()), "html", null, true);
                echo ")\"><i class=\"fa fa-sliders-h naranja\"></i></a>                
                                                 ";
            }
            // line 87
            echo " 
                                                 <a style=\"margin-left: 20px;font-size:22px;\" onclick=\"delete_item(";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_orden", array()), "html", null, true);
            echo ",'ordenadmin')\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>                                      
                                                </td>
                                            </tr>
                                            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 92
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['o'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Usuario</th>
                                            <th>Número de cuenta</th>
                                            <!--<th>Sucursal</th>-->
                                            <th>Composición</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Monto(USD)</th>
                                            <th>Tipo Orden</th>
                                            <th>Estado</th>
                                            <th>Fecha Creación</th>
                                            <th>Moneda</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
";
        // line 119
        $this->loadTemplate("ordenes/compraventatienda", "ordenes/ordenes.twig", 119)->display($context);
        // line 120
        echo "
</div>
";
    }

    // line 124
    public function block_appFooter($context, array $blocks = array())
    {
        // line 125
        echo "    <script src=\"./assets/jscontrollers/ordenes/crear.js\"></script> 
    <script src=\"./assets/jscontrollers/ordenes/concretar.js\"></script> 
    <script src=\"views/propios/js/delete_item.js\"></script>   
";
    }

    public function getTemplateName()
    {
        return "ordenes/ordenes.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 125,  243 => 124,  237 => 120,  235 => 119,  208 => 94,  201 => 92,  192 => 88,  189 => 87,  184 => 86,  180 => 85,  176 => 83,  171 => 82,  167 => 81,  163 => 79,  158 => 78,  154 => 77,  149 => 75,  145 => 74,  141 => 73,  135 => 72,  131 => 71,  127 => 70,  123 => 69,  118 => 68,  114 => 66,  108 => 65,  104 => 64,  96 => 62,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/ordenes.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\ordenes.twig");
    }
}

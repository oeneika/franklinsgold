<?php

/* overall/menu.twig */
class __TwigTemplate_e138cd9ab9e7b5935129f791b9ecc54c21728208ff6f4f4b564c8beb312ea14a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
    <div class=\"sidebar-collapse\">
        <ul class=\"nav metismenu\" id=\"side-menu\">
            <li class=\"nav-header\">
                <div class=\"dropdown profile-element\">
                    <span>
                    <a href=\"home/\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"height:100px; margin: 0 40px;\" /></a>
                    </span>
                    <span class=\"clear\"> 
                        <a href=\"home/\" title=\"Ir al inicio del sistema\"><span class=\"block m-t-xs\"><strong class=\"font-bold hover\" style=\"margin: 0 35px;\">Franklin Gold</strong></span></a>
                    </span>
                </div>
                <div class=\"logo-element\">
                    <a href=\"home/\">FG</a>
                </div>
            </li>
            <li class=\"\">
                <a href=\"dashboardpublico/dashboardpublico/\"><i class=\"fa fa-sliders-h\"></i><span class=\"nav-label\">Dashboard</span></a>
            </li>
            ";
        // line 20
        if ((($context["owner_user"] ?? null) != null)) {
            // line 21
            echo "            
                ";
            // line 22
            if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 2)) {
                // line 23
                echo "                <li class=\"\">
                    <a href=\"perfilcliente/\"><i class=\"fa fa-user\"></i><span class=\"nav-label\">Perfil</span></a>
                </li>
                ";
            }
            // line 27
            echo "                <li class=\"\">
                    <a href=\"calculadora/\"><i class=\"fa fa-calculator\"></i><span class=\"nav-label\">Calculadora</span></a>
                </li>
                ";
            // line 30
            if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0)) {
                // line 31
                echo "                    <li class=\"\">
                        <a href=\"usuarios/\"><i class=\"fa fa-users\"></i> <span class=\"nav-label\">Usuarios</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"rango/\"><i class=\"fa fa-arrow-circle-up\"></i> <span class=\"nav-label\">Rangos</span></a>
                    </li>       
                    <li class=\"\">
                        <a href=\"monedas/\"><i class=\"fas fa-coins\"></i> <span class=\"nav-label\">Moneda</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"sucursal/\"><i class=\"fa fa-hotel\"></i> <span class=\"nav-label\">Sucursal</span></a>
                    </li>
                    <li class=\"\">
                            <a href=\"afiliados/\"><i class=\"fa fa-hand-holding\"></i> <span class=\"nav-label\">Comercios Afiliados</span></a>
                        </li>
                    </li>
                    <li class=\"\">
                        <a href=\"origen/\"><i class=\"fa fa-home\"></i><span class=\"nav-label\">Origen</span>
                        </a>
                    </li>
                    <li class=\"\">
                        <a href=\"divisa/\"><i class=\"fa fa-money-bill-alt\"></i><span class=\"nav-label\">Dívisas</span></a>
                    </li>
                ";
            }
            // line 55
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) != 2) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_comercio_afiliado", array()) == null))) {
                // line 56
                echo "                <li class=\"\">
                    <a href=\"ordenadmin/\"><i class=\"fa fa-shopping-cart\"></i><span class=\"nav-label\">Ordenes</span></a>
                </li>    
                ";
            }
            // line 60
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0) || ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 3) && (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_comercio_afiliado", array()) == null)))) {
                // line 61
                echo "                <li class=\"\">
                    <a><i class=\"fa fa-money-check-alt\"></i> <span class=\"nav-label\">Transacciones</span><span class=\"fa arrow\"></span></a>
                    <ul class=\"nav nav-second-level collapse\">
                        <li>
                            <a href=\"transaccion/compra/\">Compra</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/venta/\">Venta</a>
                        </li>-->
                        <li>
                            <a href=\"transaccion/transaccion_en_espera/\">En espera</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/intercambio/\">Intercambio</a>
                        </li>-->
                        <!--<li>
                            <a href=\"transaccion/intercambioafiliado/\">Intercambio con Afiliados</a>
                        </li>-->
                    </ul>
                </li>                   
                ";
            }
            // line 82
            echo "                ";
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 0) || (twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) == 2))) {
                // line 83
                echo "                <li class=\"\">
                            <a href=\"\"><i class=\"fa fa-tasks\"></i><span class=\"nav-label\">Compra y Venta</span><span class=\"fa arrow\"></span></a>
                            <ul class=\"nav nav-second-level collapse\">
                                <li>
                                    <a href=\"ordencliente/\">Dashboard</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/compraoro/\">Compra de oro</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/compraplata/\">Compra de plata</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/ventaoro/\">Venta de oro</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/ventaplata/\">Venta de plata</a>
                                </li>
                            </ul>
                </li>
                <li class=\"\">
                    <a href=\"factura/factura-tabla\"><i class=\"fa fa-copy\"></i><span class=\"nav-label\">Facturas</span></a>
                </li>
                ";
            }
            // line 107
            echo "            ";
        }
        echo "   
        </ul>
    </div>
</nav>";
    }

    public function getTemplateName()
    {
        return "overall/menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 107,  124 => 83,  121 => 82,  98 => 61,  95 => 60,  89 => 56,  86 => 55,  60 => 31,  58 => 30,  53 => 27,  47 => 23,  45 => 22,  42 => 21,  40 => 20,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
    <div class=\"sidebar-collapse\">
        <ul class=\"nav metismenu\" id=\"side-menu\">
            <li class=\"nav-header\">
                <div class=\"dropdown profile-element\">
                    <span>
                    <a href=\"home/\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"height:100px; margin: 0 40px;\" /></a>
                    </span>
                    <span class=\"clear\"> 
                        <a href=\"home/\" title=\"Ir al inicio del sistema\"><span class=\"block m-t-xs\"><strong class=\"font-bold hover\" style=\"margin: 0 35px;\">Franklin Gold</strong></span></a>
                    </span>
                </div>
                <div class=\"logo-element\">
                    <a href=\"home/\">FG</a>
                </div>
            </li>
            <li class=\"\">
                <a href=\"dashboardpublico/dashboardpublico/\"><i class=\"fa fa-sliders-h\"></i><span class=\"nav-label\">Dashboard</span></a>
            </li>
            {% if owner_user != null  %}
            
                {% if owner_user.tipo == 2 %}
                <li class=\"\">
                    <a href=\"perfilcliente/\"><i class=\"fa fa-user\"></i><span class=\"nav-label\">Perfil</span></a>
                </li>
                {% endif %}
                <li class=\"\">
                    <a href=\"calculadora/\"><i class=\"fa fa-calculator\"></i><span class=\"nav-label\">Calculadora</span></a>
                </li>
                {% if owner_user.tipo == 0 %}
                    <li class=\"\">
                        <a href=\"usuarios/\"><i class=\"fa fa-users\"></i> <span class=\"nav-label\">Usuarios</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"rango/\"><i class=\"fa fa-arrow-circle-up\"></i> <span class=\"nav-label\">Rangos</span></a>
                    </li>       
                    <li class=\"\">
                        <a href=\"monedas/\"><i class=\"fas fa-coins\"></i> <span class=\"nav-label\">Moneda</span></a>
                    </li>
                    <li class=\"\">
                        <a href=\"sucursal/\"><i class=\"fa fa-hotel\"></i> <span class=\"nav-label\">Sucursal</span></a>
                    </li>
                    <li class=\"\">
                            <a href=\"afiliados/\"><i class=\"fa fa-hand-holding\"></i> <span class=\"nav-label\">Comercios Afiliados</span></a>
                        </li>
                    </li>
                    <li class=\"\">
                        <a href=\"origen/\"><i class=\"fa fa-home\"></i><span class=\"nav-label\">Origen</span>
                        </a>
                    </li>
                    <li class=\"\">
                        <a href=\"divisa/\"><i class=\"fa fa-money-bill-alt\"></i><span class=\"nav-label\">Dívisas</span></a>
                    </li>
                {% endif %}
                {% if owner_user.tipo != 2 and owner_user.id_comercio_afiliado == null %}
                <li class=\"\">
                    <a href=\"ordenadmin/\"><i class=\"fa fa-shopping-cart\"></i><span class=\"nav-label\">Ordenes</span></a>
                </li>    
                {% endif %}
                {% if owner_user.tipo == 0 or (owner_user.tipo == 3 and owner_user.id_comercio_afiliado == null)  %}
                <li class=\"\">
                    <a><i class=\"fa fa-money-check-alt\"></i> <span class=\"nav-label\">Transacciones</span><span class=\"fa arrow\"></span></a>
                    <ul class=\"nav nav-second-level collapse\">
                        <li>
                            <a href=\"transaccion/compra/\">Compra</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/venta/\">Venta</a>
                        </li>-->
                        <li>
                            <a href=\"transaccion/transaccion_en_espera/\">En espera</a>
                        </li>
                        <!--<li>
                            <a href=\"transaccion/intercambio/\">Intercambio</a>
                        </li>-->
                        <!--<li>
                            <a href=\"transaccion/intercambioafiliado/\">Intercambio con Afiliados</a>
                        </li>-->
                    </ul>
                </li>                   
                {% endif %}
                {%  if owner_user.tipo == 0 or owner_user.tipo == 2 %}
                <li class=\"\">
                            <a href=\"\"><i class=\"fa fa-tasks\"></i><span class=\"nav-label\">Compra y Venta</span><span class=\"fa arrow\"></span></a>
                            <ul class=\"nav nav-second-level collapse\">
                                <li>
                                    <a href=\"ordencliente/\">Dashboard</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/compraoro/\">Compra de oro</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/compraplata/\">Compra de plata</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/ventaoro/\">Venta de oro</a>
                                </li>
                                <li>
                                    <a href=\"ordencliente/ventaplata/\">Venta de plata</a>
                                </li>
                            </ul>
                </li>
                <li class=\"\">
                    <a href=\"factura/factura-tabla\"><i class=\"fa fa-copy\"></i><span class=\"nav-label\">Facturas</span></a>
                </li>
                {% endif %}
            {% endif %}   
        </ul>
    </div>
</nav>", "overall/menu.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\menu.twig");
    }
}

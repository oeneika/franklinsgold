<?php

/* transaccion/transaccion_en_espera.twig */
class __TwigTemplate_7b76139e757978f7a994b88e2fb584f6b6d2c8ae274ddc0d774745396e0a65e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "transaccion/transaccion_en_espera.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "transaccion/transaccion_en_espera.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money-check-alt\"></i> Transacciones en espera</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Transacciones en espera</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Transacciones en espera en el sistema</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover tablita\">
                                <thead>
                                    <tr>
                                        <th>Usuario inicializador</th>
                                        <th>Qr Moneda</th>  
                                        <th>Acciones</th>                              
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transacciones_en_espera"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 42
            echo "                                    <tr>
                                        <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "apellido", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "qr", array()), "html", null, true);
            echo "</td>
                                        <td><a onclick=\"delete_item(";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id", array()), "html", null, true);
            echo ",'transaccion_en_espera')\"style=\"font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a></td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 48
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Usuario inicializador</th>
                                        <th>Qr Moneda</th>
                                        <th>Acciones</th>  
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
 
    ";
        // line 69
        $this->loadTemplate("overall/footer", "transaccion/transaccion_en_espera.twig", 69)->display($context);
        // line 70
        echo "</div>
";
    }

    // line 72
    public function block_appFooter($context, array $blocks = array())
    {
        // line 73
        echo "    <script src=\"views/propios/js/delete_item.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "transaccion/transaccion_en_espera.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 73,  136 => 72,  131 => 70,  129 => 69,  110 => 52,  101 => 48,  93 => 45,  89 => 44,  83 => 43,  80 => 42,  75 => 41,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %} 
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        {% include 'overall/header' %}
    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money-check-alt\"></i> Transacciones en espera</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Transacciones en espera</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Transacciones en espera en el sistema</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover tablita\">
                                <thead>
                                    <tr>
                                        <th>Usuario inicializador</th>
                                        <th>Qr Moneda</th>  
                                        <th>Acciones</th>                              
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for t in transacciones_en_espera %}
                                    <tr>
                                        <td>{{t.nombre}} {{t.apellido}}</td>
                                        <td>{{t.qr}}</td>
                                        <td><a onclick=\"delete_item({{t.id}},'transaccion_en_espera')\"style=\"font-size:22px;\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a></td>
                                    </tr>
                                    {% else %}
                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Usuario inicializador</th>
                                        <th>Qr Moneda</th>
                                        <th>Acciones</th>  
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
 
    {% include 'overall/footer' %}
</div>
{% endblock %}
{% block appFooter %}
    <script src=\"views/propios/js/delete_item.js\"></script>
{% endblock %}", "transaccion/transaccion_en_espera.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\transaccion_en_espera.twig");
    }
}

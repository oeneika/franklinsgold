<?php

/* afiliados/editar.twig */
class __TwigTemplate_be8b34bfe0156f4050250fd194def5e771667db49fcf834f453b3003a467d1ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarAfiliado\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
                            <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar ";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</span></button>
                                    <h4 class=\"modal-title\">Edición de Comercio Afiliado ";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "edicioncomercioafil", array()), "html", null, true);
        echo "</h4>
                                    <small class=\"font-bold\">Franklin Gold</small>
                                </div>
                                <div class=\"modal-body\">
                                    <form role=\"form\" id=\"editar_afiliado_form\">
                                        <input type=\"hidden\" name=\"id_comercio_afiliado\" id='id_afiliados_edit'>
                                        <input type=\"hidden\" name=\"id_user\" id=\"id_edit_user\" >
                                        <div class=\"row\">
                                            <div class=\"col-md-6 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"nombre\" class=\"control-label mb-1\">Nombre ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "nombre", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"nombre\" id=\"id_nombre_edit\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                </div>
                                            </div>
                                            <div class=\"col-md-6 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"nombre\" class=\"control-label mb-1\">Sucursal ";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "sucursal", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"sucursal\" id=\"id_sucursal_edit\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"col-md-12 col-xs-12\">
                                                <div class=\"form-group\">
                                                    <label for=\"direccion\" class=\"control-label mb-1\">Dirección ";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "direccion", array()), "html", null, true);
        echo "</label>
                                                    <input name=\"direccion\" id=\"id_direccion_edit\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                                                </div>
                                            </div>
                                        </div>
                                        <div id=\"telefonos_edit\">
                                            
                                        </div>
                                    </form>
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar ";
        // line 41
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</button>
                                    <button type=\"button\" id=\"editarafiliadobtn\" class=\"btn btn-primary\">Guardar ";
        // line 42
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "save", array()), "html", null, true);
        echo "</button>
                                </div>
                            </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "afiliados/editar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 42,  76 => 41,  62 => 30,  51 => 22,  42 => 16,  29 => 6,  25 => 5,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "afiliados/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\afiliados\\editar.twig");
    }
}

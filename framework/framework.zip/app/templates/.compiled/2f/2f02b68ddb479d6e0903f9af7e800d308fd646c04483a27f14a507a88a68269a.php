<?php

/* dashboardpublico/dashboardpublico.twig */
class __TwigTemplate_43f882cefdd820606926f8fae4f515d34a4c6017da5cb93f82df4aa42609a753 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "dashboardpublico/dashboardpublico.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "dashboardpublico/dashboardpublico.twig", 5)->display($context);
        // line 6
        echo "    </div>

            <div class=\"wrapper wrapper-content\">
            \t<div class=\"row\">
                
            \t</div>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio del oro ";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "titulooro", array()), "html", null, true);
        echo "</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio del oro (USD)";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "preciooro", array()), "html", null, true);
        echo "
                                        </h3>
                                </div>

                                <div>
                                    <canvas id=\"lineChart\" height=\"46\" width=\"100%\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        <i id=\"fecha_oro\"> </i>
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio de la plata ";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "tituloplata", array()), "html", null, true);
        echo "</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio de la plata (USD)";
        // line 47
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "precioplata", array()), "html", null, true);
        echo "
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"plataChart\" height=\"46\" width=\"100%\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">  
                                        <i class=\"fa fa-clock-o\"> </i>                                     
                                        <i id=\"fecha_plata\"></i>
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>                
                
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Transacciones realizadas en oro";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "titulotransoro", array()), "html", null, true);
        echo "</h5>
                            </div>
                        </br>
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"ibox-title\">
                                        <h5>Compra ";
        // line 77
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "compra", array()), "html", null, true);
        echo "</h5>
                                    </div>
                                    <div class=\"ibox-content\">
                                        <div class=\"table-responsive\">
                                            <table class=\"table table-striped table-bordered table-hover tablita\" >
                                                <thead>
                                                <tr>
                                                    <th>Fecha ";
        // line 84
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                                    <!--<th>Sucursal</th>-->                                                 
                                                    <th>Cantidad ";
        // line 86
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "cantidad", array()), "html", null, true);
        echo "</th>
                                                    <th>Precio ";
        // line 87
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "precio", array()), "html", null, true);
        echo "</th>
                                                    <th>Monto(USD) ";
        // line 88
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "monto", array()), "html", null, true);
        echo "</th>
                                                </tr>
                                                </thead>
                                                <tbody> 
                                                ";
        // line 92
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["compras_oro"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["co"]) {
            echo " 
                                                    <tr>
                                                        <td>";
            // line 94
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["co"], "fecha", array())), "html", null, true);
            echo "</td>
                                                        ";
            // line 95
            echo "                                                   
                                                        <td>";
            // line 96
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["co"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 97
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["co"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 98
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["co"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["co"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['co'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"ibox-title\">
                                        <h5>Venta ";
        // line 108
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "venta", array()), "html", null, true);
        echo "</h5>
                                    </div>
                                    <div class=\"ibox-content\">
                                        <div class=\"table-responsive\">
                                            <table class=\"table table-striped table-bordered table-hover tablita\" >
                                                <thead>
                                                <tr>
                                                    <th>Fecha ";
        // line 115
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                                    <!--<th>Sucursal</th>--> 
                                                    <th>Cantidad ";
        // line 117
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "cantidad", array()), "html", null, true);
        echo "</th>
                                                    <th>Precio ";
        // line 118
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "precio", array()), "html", null, true);
        echo "</th>
                                                    <th>Monto(USD) ";
        // line 119
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "monto", array()), "html", null, true);
        echo "</th>
                                                </tr>
                                                </thead>
                                                <tbody> 
                                                ";
        // line 123
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ventas_oro"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["vo"]) {
            echo " 
                                                    <tr>
                                                        <td>";
            // line 125
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["vo"], "fecha", array())), "html", null, true);
            echo "</td>
                                                        ";
            // line 126
            echo "                                                     
                                                        <td>";
            // line 127
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["vo"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 128
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["vo"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 129
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["vo"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["vo"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['vo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 132
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Transacciones realizadas en plata ";
        // line 147
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "titulotransplata", array()), "html", null, true);
        echo "</h5>
                            </div>
                        </br>
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"ibox-title\">
                                        <h5>Compra</h5>
                                    </div>
                                    <div class=\"ibox-content\">
                                        <div class=\"table-responsive\">
                                            <table class=\"table table-striped table-bordered table-hover tablita\" >
                                                <thead>
                                                <tr>
                                                    <th>Fecha ";
        // line 160
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                                    <!--<th>Sucursal</th>--> 
                                                    <th>Cantidad ";
        // line 162
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "cantidad", array()), "html", null, true);
        echo "</th>
                                                    <th>Precio ";
        // line 163
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "precio", array()), "html", null, true);
        echo "</th>
                                                    <th>Monto(USD) ";
        // line 164
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "monto", array()), "html", null, true);
        echo "</th>
                                                </tr>
                                                </thead>
                                                <tbody> 
                                                ";
        // line 168
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["compras_plata"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["cp"]) {
            echo " 
                                                    <tr>
                                                        <td>";
            // line 170
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["cp"], "fecha", array())), "html", null, true);
            echo "</td>
                                                        ";
            // line 171
            echo "                                                        
                                                        <td>";
            // line 172
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["cp"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 173
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["cp"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 174
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["cp"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["cp"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 177
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"ibox-title\">
                                        <h5>Venta</h5>
                                    </div>
                                    <div class=\"ibox-content\">
                                        <div class=\"table-responsive\">
                                            <table class=\"table table-striped table-bordered table-hover tablita\" >
                                                <thead>
                                                <tr>
                                                    <th>Fecha ";
        // line 191
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                                    <!--<th>Sucursal</th>--> 
                                                    <th>Cantidad ";
        // line 193
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "cantidad", array()), "html", null, true);
        echo "</th>
                                                    <th>Precio ";
        // line 194
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "precio", array()), "html", null, true);
        echo "</th>
                                                    <th>Monto(USD) ";
        // line 195
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "monto", array()), "html", null, true);
        echo "</th>
                                                </tr>
                                                </thead>
                                                <tbody> 
                                                ";
        // line 199
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ventas_plata"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["vp"]) {
            echo " 
                                                    <tr>
                                                        <td>";
            // line 201
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["vp"], "fecha", array())), "html", null, true);
            echo "</td>
                                                        ";
            // line 202
            echo "                                                     
                                                        <td>";
            // line 203
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["vp"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 204
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["vp"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 205
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["vp"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["vp"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['vp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 208
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <div class=\"row\">
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5 Class=\"font\">Gramos de oro comprados el último día ";
        // line 223
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grcompradosoro", array()), "html", null, true);
        echo "</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h3 class=\"no-margins\">";
        // line 226
        echo twig_escape_filter($this->env, (((($context["compras_oro_1dia"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["compras_oro_1dia"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5 Class=\"font\">Gramos de oro vendidos el último día ";
        // line 233
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grvendidosoro", array()), "html", null, true);
        echo "</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h3 class=\"no-margins\">";
        // line 236
        echo twig_escape_filter($this->env, (((($context["ventas_oro_1dia"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["ventas_oro_1dia"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5 Class=\"font\">Gramos de oro comprados el último mes ";
        // line 243
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grcompradosooromes", array()), "html", null, true);
        echo "</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h3 class=\"no-margins\">";
        // line 246
        echo twig_escape_filter($this->env, (((($context["compras_oro_1mes"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["compras_oro_1mes"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5 Class=\"font\">Gramos de oro vendidos el último mes ";
        // line 253
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grvendidosoromes", array()), "html", null, true);
        echo "</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h3 class=\"no-margins\">";
        // line 256
        echo twig_escape_filter($this->env, (((($context["ventas_oro_1mes"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["ventas_oro_1mes"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                            </div>
                        </div>
                    </div>
                </div>



                <div class=\"row\">
                        <div class=\"col-md-3\">
                            <div class=\"ibox float-e-margins\">
                                <div class=\"ibox-title\">
                                    <h5 Class=\"font\">Gramos de plata comprados el último día ";
        // line 268
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grcompradosplata", array()), "html", null, true);
        echo "</h5>
                                </div>
                                <div class=\"ibox-content\">
                                    <h3 class=\"no-margins\">";
        // line 271
        echo twig_escape_filter($this->env, (((($context["compras_plata_1dia"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["compras_plata_1dia"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                                </div>
                            </div>
                        </div>
                        <div class=\"col-md-3\">
                            <div class=\"ibox float-e-margins\">
                                <div class=\"ibox-title\">
                                    <h5 Class=\"font\">Gramos de plata vendidos el último día ";
        // line 278
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grvendidosplata", array()), "html", null, true);
        echo "</h5>
                                </div>
                                <div class=\"ibox-content\">
                                    <h3 class=\"no-margins\">";
        // line 281
        echo twig_escape_filter($this->env, (((($context["ventas_plata_1dia"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["ventas_plata_1dia"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                                </div>
                            </div>
                        </div>
                        <div class=\"col-md-3\">
                            <div class=\"ibox float-e-margins\">
                                <div class=\"ibox-title\">
                                    <h5 Class=\"font\">Gramos de plata comprados el último mes ";
        // line 288
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grcompradosplatames", array()), "html", null, true);
        echo "</h5>
                                </div>
                                <div class=\"ibox-content\">
                                    <h3 class=\"no-margins\">";
        // line 291
        echo twig_escape_filter($this->env, (((($context["compras_plata_1mes"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["compras_plata_1mes"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                                </div>
                            </div>
                        </div>
                        <div class=\"col-md-3\">
                            <div class=\"ibox float-e-margins\">
                                <div class=\"ibox-title\">
                                    <h5 Class=\"font\">Gramos de plata vendidos el último mes ";
        // line 298
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapperdash", array()), "grvendidosplatames", array()), "html", null, true);
        echo "</h5>
                                </div>
                                <div class=\"ibox-content\">
                                    <h3 class=\"no-margins\">";
        // line 301
        echo twig_escape_filter($this->env, (((($context["ventas_plata_1mes"] ?? null) == null)) ? (0) : (twig_number_format_filter($this->env, ($context["ventas_plata_1mes"] ?? null), 2, ",", "."))), "html", null, true);
        echo "</h3>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>

";
        // line 309
        $this->loadTemplate("overall/footer", "dashboardpublico/dashboardpublico.twig", 309)->display($context);
        // line 310
        echo "</div>
";
    }

    // line 313
    public function block_appFooter($context, array $blocks = array())
    {
        // line 314
        echo "    <script src=\"./assets/jscontrollers/ordenes/crear.js\"></script>
    <script src=\"./assets/jscontrollers/home/dashboard.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "dashboardpublico/dashboardpublico.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  569 => 314,  566 => 313,  561 => 310,  559 => 309,  548 => 301,  542 => 298,  532 => 291,  526 => 288,  516 => 281,  510 => 278,  500 => 271,  494 => 268,  479 => 256,  473 => 253,  463 => 246,  457 => 243,  447 => 236,  441 => 233,  431 => 226,  425 => 223,  408 => 208,  399 => 205,  395 => 204,  391 => 203,  388 => 202,  384 => 201,  377 => 199,  370 => 195,  366 => 194,  362 => 193,  357 => 191,  341 => 177,  332 => 174,  328 => 173,  324 => 172,  321 => 171,  317 => 170,  310 => 168,  303 => 164,  299 => 163,  295 => 162,  290 => 160,  274 => 147,  257 => 132,  248 => 129,  244 => 128,  240 => 127,  237 => 126,  233 => 125,  226 => 123,  219 => 119,  215 => 118,  211 => 117,  206 => 115,  196 => 108,  187 => 101,  178 => 98,  174 => 97,  170 => 96,  167 => 95,  163 => 94,  156 => 92,  149 => 88,  145 => 87,  141 => 86,  136 => 84,  126 => 77,  117 => 71,  90 => 47,  84 => 44,  58 => 21,  52 => 18,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "dashboardpublico/dashboardpublico.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\dashboardpublico\\dashboardpublico.twig");
    }
}

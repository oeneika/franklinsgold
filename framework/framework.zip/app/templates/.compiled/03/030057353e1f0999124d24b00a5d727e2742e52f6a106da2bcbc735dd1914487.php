<?php

/* usuarios/editar.twig */
class __TwigTemplate_d0f85f313725445735a5251641a95dd40c3c55665be3294f937426011fd63cb0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Usuarios</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"editar_usuario_form\">
                    <input type=\"hidden\" name=\"id_user\" id=\"id_id_user\" value=\"\" />

                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input id=\"id_primer_nombre\" name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input id=\"id_segundo_nombre\" name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input id=\"id_primer_apellido\" name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido <span>*</span></label>
                                <input id=\"id_segundo_apellido\" name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input id=\"id_sexom\" type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input id=\"id_sexof\" type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input id=\"id_tipoa\" class=\"tipo_editar\" type=\"radio\"  value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input id=\"id_tipov\" class=\"tipo_editar\" type=\"radio\"  value=\"1\" name=\"tipo\"> Vendedor
                                    </br>
                                    <input id=\"id_tipoc\" class=\"tipo_editar\" type=\"radio\"  value=\"2\" name=\"tipo\"> Cliente
                                    </br>
                                    <input id=\"id_tipos\" class=\"tipo_editar\" type=\"radio\"  value=\"3\" name=\"tipo\"> Supervisor                                  
                                </div>
                            </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Teléfono <span>*</span></label>
                                <input id=\"id_telefono\" name=\"telefono\" type=\"tel\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <div class=\"panel panel-warning selects_body\" style=\"display: none;\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">Seleccione una sucursal o un comercio</h3>
                        </div>
                        <div class=\"panel-body\">
                                <div class=\"row\">
                                    <div class=\"col-md-6\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Sucursal<span>*</span></label>
                                        <select id=\"id_sucursal\" name=\"id_sucursal\" class=\"form-control m-b\" style=\"width: 100%\">
                                            <option selected value>Seleccione una sucursal</option>
                                                ";
        // line 79
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["sucursales"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
            // line 80
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "id_sucursal", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["s"], "nombre", array()), "html", null, true);
            echo "</option>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['s'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "                                        </select>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Comercio Afiliado<span>*</span></label>
                                        <select id=\"id_comercio\" name=\"id_comercio\" class=\"form-control m-b\" style=\"width: 100%\">
                                            <option selected value>Seleccione un comercio</option>
                                                ";
        // line 88
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["afiliados"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 89
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "nombre", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "sucursal", array()), "html", null, true);
            echo "</option>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 91
        echo "                                        </select>
                                    </div>
                                </div>
                        </div>
                    </div>

                    <div class=\"panel panel-warning selects_body2\" style=\"display: none;\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">Seleccione un rango para el cliente</h3>
                        </div>
                        <div class=\"panel-body\">
                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <label for=\"cc-payment\" class=\"control-label mb-1\">Rango<span>*</span></label>
                                        <select id=\"id_tipo_cliente\" name=\"tipo_cliente\" class=\"form-control m-b\" style=\"width: 100%\">
                                            <option selected value>Seleccione un rango para el cliente</option> 
                                            ";
        // line 107
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rangos"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 108
            echo "                                                <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "nombre_rango", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "nombre_rango", array()), "html", null, true);
            echo "</option>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "                                        </select>
                                    </div>
                                </div>
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"numero_cuenta\" class=\"control-label mb-1\">No. de cuenta <span>*</span></label>
                                <input name=\"numero_cuenta\" id=\"id_numero_cuenta\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editar_usuario_0CR3ND\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/editar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 110,  161 => 108,  157 => 107,  139 => 91,  126 => 89,  122 => 88,  114 => 82,  103 => 80,  99 => 79,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "usuarios/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\editar.twig");
    }
}

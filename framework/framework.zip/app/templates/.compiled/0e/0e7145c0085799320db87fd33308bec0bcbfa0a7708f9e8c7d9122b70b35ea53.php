<?php

/* afiliados/intercambios.twig */
class __TwigTemplate_ee873ef7b987ae582107119eae66f39f1aa71e26dd03bd4c6c68978cc0be1b44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"intercambioAfiliados\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-lg\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar ";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</span></button>
                <h4 class=\"modal-title\">Monedas en este comercio ";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "monedascomercio", array()), "html", null, true);
        echo "</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>
            <div class=\"modal-body\">
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th>Moneda ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "moneda", array()), "html", null, true);
        echo "</th>
                                <th>Fecha ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                <th>Monto ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "monto", array()), "html", null, true);
        echo "</th>
                            </tr>
                        </thead>
                        <tbody id=\"body_intercambios\">
                           
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Moneda ";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "moneda", array()), "html", null, true);
        echo "</th>
                                <th>Fecha ";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "fecha", array()), "html", null, true);
        echo "</th>
                                <th>Monto ";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "monto", array()), "html", null, true);
        echo "</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class=\"table-responsicve\">
                    <table class=\"table table-striped table-bordered\">
                        <tr>
                            <th>TOTAL</th>
                            <td id='total_intercambio'></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar ";
        // line 41
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "cerrar", array()), "html", null, true);
        echo "</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "afiliados/intercambios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 41,  67 => 26,  63 => 25,  59 => 24,  48 => 16,  44 => 15,  40 => 14,  29 => 6,  25 => 5,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "afiliados/intercambios.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\afiliados\\intercambios.twig");
    }
}

<?php

/* home/home.twig */
class __TwigTemplate_18b3941582ddea5dc805e5cab9f22e8ac57b3c936f54918d3dbfc5ea8a757f51 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "home/home.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "home/home.twig", 5)->display($context);
        // line 6
        echo "</div>

    <div class=\"wrapper wrapper-content\">
        <div class=\"row\">
            ";
        // line 10
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "id_comercio_afiliado", array()) != null)) {
            // line 11
            echo "            <div class=\"col-md-12\">
                <a onclick=\"showModal(0,0,0,'confirmarintercambioencomercioModal')\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;margin-left:5px;\"><i class=\"fa fa-check\"></i> Confirmar</a>
                <a onclick=\"showModal(";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
            echo ",";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_plata_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
            echo ",";
            echo twig_escape_filter($this->env, ($context["precio_bolivar"] ?? null), "html", null, true);
            echo ",'intercambioencomercioModal')\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;margin-left:5px;\"><i class=\"fa fa-check\"></i> Intercambio</a>
            </div>
            ";
        }
        // line 16
        echo "        </div>

        ";
        // line 18
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) != 1)) {
            // line 19
            echo "        <div class=\"row\">
            <div class=\"col-md-6\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-content\">
                            <div>
                                <span class=\"pull-right text-right\">
                                <small>Cotización en tiempo real del precio del oro en el mercado al contado</small>
                                </span>
                                <h3 class=\"font-bold no-margins\">
                                    Precio del oro (En dólares)
                                </h3>
                            </div>

                        <div>
                            <canvas id=\"lineChart\" height=\"40\" width=\"100%\"></canvas>
                        </div>

                        <div class=\"m-t-md\">
                            <small class=\"pull-right\">
                                <i class=\"fa fa-clock-o\"> </i>
                                <i id=\"fecha_oro\"> </i>
                            </small>
                        </div>

                    </div>
                </div>
            </div>
            <div class=\"col-md-6\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-content\">
                            <div>
                                <span class=\"pull-right text-right\">
                                <small>Cotización en tiempo real del precio de la plata en el mercado al contado</small>
                                </span>
                                <h3 class=\"font-bold no-margins\">
                                    Precio de la plata (USD)
                                </h3>
                            </div>

                        <div>
                            <canvas id=\"plataChart\" height=\"40\" width=\"100%\"></canvas>
                        </div>

                        <div class=\"m-t-md\">
                            <small class=\"pull-right\">  
                                <i class=\"fa fa-clock-o\"> </i>                                     
                                <i id=\"fecha_plata\"></i>
                            </small>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        ";
        }
        // line 74
        echo "

        <div class=\"row\">
                <div class=\"row\">
                   <div class=\"col-lg-12\">
                       <div class=\"ibox float-e-margins\">
                           <div class=\"ibox-title\">
                               <h5>Transacciones realizadas por los comercios afiliados</h5>
                           </div>
                           <div class=\"ibox-content\">
                                <div class=\"table-responsive\">
                                   <table class=\"table table-striped table-bordered table-hover tablita\" >
                                       <thead>
                                       <tr>
                                            <th>Usuario</th>
                                            <th>Comercio afiliado</th>
                                            <th>Sucursal</th>
                                            <th>Composición</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Monto(USD)</th>
                                            <th>Fecha</th>
                                       </tr>
                                       </thead>
                                       <tbody>  
                                           ";
        // line 99
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ordenes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["o"]) {
            // line 100
            echo "                                           <tr>
                                                <td>";
            // line 101
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "primer_apellido", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 102
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "nombre_afiliado", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 103
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "sucursal", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 104
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "tipo_gramo", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 105
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 106
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>   
                                                <td>";
            // line 107
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td>";
            // line 108
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "fecha", array())), "html", null, true);
            echo "</td> 
                                           </tr>
                                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['o'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "                                           
                                       </tbody>
                                   </table>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>


        ";
        // line 122
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) != 1)) {
            // line 123
            echo "        <div class=\"row\">

            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <span class=\"label label-primary pull-right\">Hoy</span>
                        <h5>Ventas Diarias</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">";
            // line 132
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "diarias", array()), "total", array()), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <span class=\"label label-info pull-right\">Mensual</span>
                        <h5>Ventas Mensuales</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">";
            // line 143
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "mensuales", array()), "total", array()), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <span class=\"label label-warning pull-right\">Anual</span>
                        <h5>Ventas del año</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">";
            // line 154
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "anuales", array()), "total", array()), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class=\"row\">

            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Usuarios registrados en el sistema</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">";
            // line 168
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "usuarios", array()), "total", array()), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Dólares de monedas vendidas en oro</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">\$";
            // line 178
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ventas_oro", array()), "total", array()), 2, ".", ","), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Dólares de monedas vendidas en plata</h5>
                    </div>
                    <div class=\"ibox-content\">
                        <h1 class=\"no-margins\">\$";
            // line 188
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ventas_plata", array()), "total", array()), 2, ".", ","), "html", null, true);
            echo "</h1>
                    </div>
                </div>
            </div>
        </div>
        ";
        }
        // line 194
        echo "
    </div>

";
        // line 197
        $this->loadTemplate("home/confirmarintercambioencomercio", "home/home.twig", 197)->display($context);
        // line 198
        $this->loadTemplate("home/intercambioencomercio", "home/home.twig", 198)->display($context);
        echo "   
";
        // line 199
        $this->loadTemplate("overall/footer", "home/home.twig", 199)->display($context);
        // line 200
        echo "</div>
";
    }

    // line 203
    public function block_appFooter($context, array $blocks = array())
    {
        // line 204
        echo "    ";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["owner_user"] ?? null), "tipo", array()) != 1)) {
            // line 205
            echo "    <script src=\"./assets/jscontrollers/home/intercambioencomercio.js\"></script>
    ";
        }
        // line 207
        echo "
    <script src=\"./assets/jscontrollers/home/dashboard.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "home/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  330 => 207,  326 => 205,  323 => 204,  320 => 203,  315 => 200,  313 => 199,  309 => 198,  307 => 197,  302 => 194,  293 => 188,  280 => 178,  267 => 168,  250 => 154,  236 => 143,  222 => 132,  211 => 123,  209 => 122,  196 => 111,  187 => 108,  183 => 107,  179 => 106,  175 => 105,  171 => 104,  167 => 103,  163 => 102,  157 => 101,  154 => 100,  150 => 99,  123 => 74,  66 => 19,  64 => 18,  60 => 16,  50 => 13,  46 => 11,  44 => 10,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "home/home.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\home\\home.twig");
    }
}

<?php

/* afiliados/afiliados.twig */
class __TwigTemplate_5fbc0d03d5436422619a90157bc29ee4114df6c56001daa7c3a9dda6cf112ff5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "afiliados/afiliados.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "afiliados/afiliados.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-hand-holding\"></i> Comercios Afiliados ";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "comercioafil", array()), "html", null, true);
        echo "</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Comercios Afiliados ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "comercioafil", array()), "html", null, true);
        echo "</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <a onclick=\"crearafiliado()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-hand-holding\"></i> Crear Comercio ";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "crearcomercio", array()), "html", null, true);
        echo "</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Comercios afiliados registrados en el sistema ";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "titleuno", array()), "html", null, true);
        echo "</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Id ";
        // line 42
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "id", array()), "html", null, true);
        echo "</th>
                                            <th>Nombre";
        // line 43
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "nombre", array()), "html", null, true);
        echo "</th>
                                            <th>Sucursal";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "sucursal", array()), "html", null, true);
        echo "</th>
                                            <th>Dirección";
        // line 45
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "direccion", array()), "html", null, true);
        echo "</th>
                                            <th>Teléfonos";
        // line 46
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "telefono", array()), "html", null, true);
        echo "</th>
                                            <th>Acciones";
        // line 47
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "acciones", array()), "html", null, true);
        echo "</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["afiliados"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            echo "  
                                            <tr>
                                                <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "nombre", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "sucursal", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "direccion", array()), "html", null, true);
            echo "</td>
                                                <td><a onclick=\"getTel(";
            // line 57
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo ")\">Teléfonos";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "telefono", array()), "html", null, true);
            echo "</a></td>
                                                <td>
                                                ";
            // line 60
            echo "                                                <a style=\"margin-left: 20px;font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" onclick=\"editarAfiliado(";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo ",";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_user", array()), "html", null, true);
            echo ",'";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "nombre", array()), "html", null, true);
            echo "','";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "direccion", array()), "html", null, true);
            echo "','";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "sucursal", array()), "html", null, true);
            echo "')\"><i class=\"fa fa-sliders-h naranja\"></i></a>
                                                <a style=\"margin-left: 20px;font-size:22px;\" onclick=\"delete_item(";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "id_comercio_afiliado", array()), "html", null, true);
            echo ",'afiliados')\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>
                                                </td>
                                            </tr>
                                            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 65
            echo "                                                 <tr><td>No hay resultados";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "noresultado", array()), "html", null, true);
            echo "</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id ";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "id", array()), "html", null, true);
        echo "</th>
                                            <th>Nombre";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "nombre", array()), "html", null, true);
        echo "</th>
                                            <th>Sucursal";
        // line 72
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "sucursal", array()), "html", null, true);
        echo "</th>
                                            <th>Dirección";
        // line 73
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "direccion", array()), "html", null, true);
        echo "</th>
                                            <th>Teléfonos";
        // line 74
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "telefono", array()), "html", null, true);
        echo "</th>
                                            <th>Acciones";
        // line 75
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrapper", array()), "acciones", array()), "html", null, true);
        echo "</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
";
        // line 85
        $this->loadTemplate("afiliados/crear", "afiliados/afiliados.twig", 85)->display($context);
        // line 86
        $this->loadTemplate("afiliados/intercambios", "afiliados/afiliados.twig", 86)->display($context);
        // line 87
        $this->loadTemplate("afiliados/editar", "afiliados/afiliados.twig", 87)->display($context);
        // line 88
        $this->loadTemplate("afiliados/telefonos", "afiliados/afiliados.twig", 88)->display($context);
        // line 89
        $this->loadTemplate("overall/footer", "afiliados/afiliados.twig", 89)->display($context);
        // line 90
        echo "</div>
";
    }

    // line 93
    public function block_appFooter($context, array $blocks = array())
    {
        // line 94
        echo "    <script src=\"assets/jscontrollers/afiliados/afiliados.js\"></script>
    <script src=\"assets/jscontrollers/afiliados/crear.js\"></script>
    <script src=\"assets/jscontrollers/afiliados/editar.js\"></script>
    <script src=\"views/propios/js/delete_item.js\"></script>   
";
    }

    public function getTemplateName()
    {
        return "afiliados/afiliados.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  233 => 94,  230 => 93,  225 => 90,  223 => 89,  221 => 88,  219 => 87,  217 => 86,  215 => 85,  202 => 75,  198 => 74,  194 => 73,  190 => 72,  186 => 71,  182 => 70,  177 => 67,  168 => 65,  159 => 61,  146 => 60,  139 => 57,  135 => 56,  131 => 55,  127 => 54,  123 => 53,  115 => 51,  108 => 47,  104 => 46,  100 => 45,  96 => 44,  92 => 43,  88 => 42,  70 => 27,  64 => 24,  52 => 15,  43 => 9,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "afiliados/afiliados.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\afiliados\\afiliados.twig");
    }
}

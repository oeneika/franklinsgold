<?php

/* overall/header.twig */
class __TwigTemplate_c589ab33cf8be1cc7fbe6573e7dfc764b8ef2c837f1de5fea2b279fb59b3fe2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header\">
           <a class=\"navbar-minimalize minimalize-styl-2 btn btn-primary\" href=\"javascript:void(0)\"><i class=\"fa fa-bars\"></i></a>
        </div>
        <ul class=\"nav navbar-top-links navbar-right\" style=\"margin-top:5px;\">
            <li>
                <span class=\"\"><a href=\"";
        // line 7
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "es\" title=\"Idioma: Español\" class=\"betiviris\">ES</a>/<a href=\"";
        echo twig_escape_filter($this->env, ($context["lang_url"] ?? null), "html", null, true);
        echo "en\" title=\"Idioma: Ingles\" class=\"betiviris\">EN</a></span>
            </li>  
            ";
        // line 9
        if ((($context["owner_user"] ?? null) != null)) {
            echo "          
            <li>
                
                <a href=\"logout/\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesi&oacute;n
                </a>
                 
            </li>
            ";
        }
        // line 18
        echo "        </ul>
</nav>
<div class=\"container\">
    <div class=\"row margintop-60\">
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colororo\">Precio del ORO</h4>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Venta:</span> \$";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo "</div>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Compra:</span> \$";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_oro_global"] ?? null), "precio_dolares", array()), "html", null, true);
        echo "</div>
                    </div>
                </div>
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colorplata\">Precio de la PLATA</h4>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Venta:</span> \$";
        // line 32
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_plata_global"] ?? null), "precio_dolares_venta", array()), "html", null, true);
        echo "</div>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Compra:</span> \$";
        // line 33
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["precio_plata_global"] ?? null), "precio_dolares", array()), "html", null, true);
        echo "</div>
                    </div>
                </div>              
    </div>
</div>
<br>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 33,  68 => 32,  59 => 26,  55 => 25,  46 => 18,  34 => 9,  27 => 7,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
        <div class=\"navbar-header\">
           <a class=\"navbar-minimalize minimalize-styl-2 btn btn-primary\" href=\"javascript:void(0)\"><i class=\"fa fa-bars\"></i></a>
        </div>
        <ul class=\"nav navbar-top-links navbar-right\" style=\"margin-top:5px;\">
            <li>
                <span class=\"\"><a href=\"{{ lang_url }}es\" title=\"Idioma: Español\" class=\"betiviris\">ES</a>/<a href=\"{{ lang_url }}en\" title=\"Idioma: Ingles\" class=\"betiviris\">EN</a></span>
            </li>  
            {% if owner_user != null  %}          
            <li>
                
                <a href=\"logout/\">
                    <i class=\"fa fa-sign-out\"></i> Cerrar Sesi&oacute;n
                </a>
                 
            </li>
            {% endif %}
        </ul>
</nav>
<div class=\"container\">
    <div class=\"row margintop-60\">
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colororo\">Precio del ORO</h4>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Venta:</span> \${{precio_oro_global.precio_dolares_venta}}</div>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Compra:</span> \${{precio_oro_global.precio_dolares}}</div>
                    </div>
                </div>
                <div class=\"col-sm-6\">
                    <div class=\"row\">
                        <h4 style=\"padding-left:15px\" class=\"colorplata\">Precio de la PLATA</h4>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Venta:</span> \${{precio_plata_global.precio_dolares_venta}}</div>
                        <div class=\"col-sm-4 sizepequeño\"><span style=\"font-weight:bold;\">Compra:</span> \${{precio_plata_global.precio_dolares}}</div>
                    </div>
                </div>              
    </div>
</div>
<br>", "overall/header.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\overall\\header.twig");
    }
}

<?php

/* rango/rango.twig */
class __TwigTemplate_27caf593bbc30dbc52a02c371a282a700d06396702228a01c0e92e264dbb992a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "rango/rango.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "rango/rango.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-arrow-circle-up\"></i> Rangos</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Rangos</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
                <!--<a onclick=\"crearRango()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\"><i class=\"fa fa-star\"></i> Crear Rango</a>-->
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Rangos registrados en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Nombre</th>
                                            <th>Monto diario(Dólares)</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 48
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rangos"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            echo "  
                                            <tr>
                                                <td>";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "nombre_rango", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 51
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "monto_diario", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td>
                                                <a style=\"font-size:22px;\" title=\"Editar\" data-toggle=\"modal\" onclick=\"editarRango(";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "id_rango", array()), "html", null, true);
            echo ",'";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "nombre_rango", array()), "html", null, true);
            echo "',";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "monto_diario", array()), "html", null, true);
            echo ")\"><i class=\"fa fa-sliders-h naranja\"></i></a>
                                                <!--<a style=\"margin-left: 20px;font-size:22px;\" onclick=\"delete_item(";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["r"], "id_rango", array()), "html", null, true);
            echo ",'rango')\" title=\"Eliminar\"><i class=\"fa fa-trash naranja\"></i></a>-->
                                                </td>
                                            </tr>
                                            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 58
            echo "                                                 <tr><td>No hay resultados</td></tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Nombre</th>
                                            <th>Monto diario</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>

";
        // line 76
        $this->loadTemplate("rango/crear", "rango/rango.twig", 76)->display($context);
        // line 77
        $this->loadTemplate("rango/editar", "rango/rango.twig", 77)->display($context);
        // line 78
        $this->loadTemplate("overall/footer", "rango/rango.twig", 78)->display($context);
        // line 79
        echo "</div>
";
    }

    // line 82
    public function block_appFooter($context, array $blocks = array())
    {
        // line 83
        echo "    <script src=\"assets/jscontrollers/rango/crear.js\"></script>
    <script src=\"assets/jscontrollers/rango/editar.js\"></script>
    <script src=\"views/propios/js/delete_item.js\"></script>   
";
    }

    public function getTemplateName()
    {
        return "rango/rango.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 83,  152 => 82,  147 => 79,  145 => 78,  143 => 77,  141 => 76,  123 => 60,  116 => 58,  107 => 54,  99 => 53,  94 => 51,  90 => 50,  82 => 48,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "rango/rango.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\rango\\rango.twig");
    }
}

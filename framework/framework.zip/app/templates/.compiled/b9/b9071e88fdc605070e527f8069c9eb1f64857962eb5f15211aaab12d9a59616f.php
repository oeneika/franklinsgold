<?php

/* error/404.twig */
class __TwigTemplate_4309a0401fb97b3983a5a2d7348e92c8afea69ab8d3a623774dc654c7be0241b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-404", "error/404.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-404";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"middle-box text-center animated fadeInDown\">
        <h1>404</h1>
        <h3 class=\"font-bold\">Pagina no encontrada ";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappererror", array()), "pagina", array()), "html", null, true);
        echo "</h3>

        <div class=\"error-desc\">
            Disculpe, la pagina no fue encontrada. Por favor vuelva a la pagina principal del sistema. ";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["lang"] ?? null), "wrappererror", array()), "pagina", array()), "html", null, true);
        echo "
        </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "error/404.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 8,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout-404' %}
{% block appBody %}
<div class=\"middle-box text-center animated fadeInDown\">
        <h1>404</h1>
        <h3 class=\"font-bold\">Pagina no encontrada {{lang.wrappererror.pagina}}</h3>

        <div class=\"error-desc\">
            Disculpe, la pagina no fue encontrada. Por favor vuelva a la pagina principal del sistema. {{lang.wrappererror.pagina}}
        </div>
</div>
{% endblock %}
", "error/404.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\error\\404.twig");
    }
}

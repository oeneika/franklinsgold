<?php

/* usuarios/historial.twig */
class __TwigTemplate_e82b4a32e9427ca9f482b45467418eb70b7bee5274f37eb1d2bda11074b5abde extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"historialUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-lg\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Historial de Usuario</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover tablita\">
                        <thead>
                            <tr>
                                <th>Transacción</th>
                                <th>Moneda</th>
                                <th>Fecha</th>
                                ";
        // line 19
        echo "                            </tr>
                        </thead>
                        <tbody id=\"body_historial\">
                           
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Transacción</th>
                                <th>Moneda</th>
                                <th>Fecha</th>
                                ";
        // line 30
        echo "                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class=\"modal-body\">
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                        <thead>
                            <tr>
                                <th>Tipo Orden</th>
                                <th>Tipo gramo</th>
                                <th>Cantidad</th>
                                <th>Precio</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody id=\"body_historial2\">
                           
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Tipo Orden</th>
                                <th>Tipo gramo</th>
                                <th>Cantidad</th>
                                <th>Precio</th>
                                <th>Fecha</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>


            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/historial.twig";
    }

    public function getDebugInfo()
    {
        return array (  50 => 30,  38 => 19,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"historialUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-lg\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Historial de Usuario</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover tablita\">
                        <thead>
                            <tr>
                                <th>Transacción</th>
                                <th>Moneda</th>
                                <th>Fecha</th>
                                {#<th>Sucursal</th>#}
                            </tr>
                        </thead>
                        <tbody id=\"body_historial\">
                           
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Transacción</th>
                                <th>Moneda</th>
                                <th>Fecha</th>
                                {#<th>Sucursal</th>#}
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class=\"modal-body\">
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                        <thead>
                            <tr>
                                <th>Tipo Orden</th>
                                <th>Tipo gramo</th>
                                <th>Cantidad</th>
                                <th>Precio</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody id=\"body_historial2\">
                           
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Tipo Orden</th>
                                <th>Tipo gramo</th>
                                <th>Cantidad</th>
                                <th>Precio</th>
                                <th>Fecha</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>


            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
            </div>
        </div>
    </div>
</div>
", "usuarios/historial.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\historial.twig");
    }
}

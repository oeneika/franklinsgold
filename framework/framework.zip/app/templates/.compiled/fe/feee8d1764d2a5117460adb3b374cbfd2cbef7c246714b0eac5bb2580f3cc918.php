<?php

/* factura/factura-tabla.twig */
class __TwigTemplate_c9305ffb51c9e23a8de777e8788a6e5ac6e173597382156a64a2ff7db96b2a6a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "factura/factura-tabla.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "factura/factura-tabla.twig", 5)->display($context);
        // line 6
        echo "</div>
<div class=\"row wrapper border-bottom white-bg page-heading\">
    <div class=\"col-lg-10\">
        <h2><i class=\"fa fa-copy\"></i> Facturas</h2>
                    <ol class=\"breadcrumb\">
                        <li>
                            <a href=\"home/\">Home</a>
                        </li>
                        <li class=\"active\">
                            <strong>Facturas</strong>
                        </li>
                    </ol>
    </div>
</div>

<div class=\"wrapper wrapper-content animated fadeInRight\">
    <div class=\"row\">
             <div class=\"col-lg-12\">
               
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                            <h5>Facturas registradas en el sistema</h5>
                            <div class=\"ibox-tools\">
                                <a class=\"collapse-link\">
                                    <i class=\"fa fa-chevron-up\"></i>
                                </a>
                                <a class=\"close-link\">
                                    <i class=\"fa fa-times\"></i>
                                </a>
                            </div>
                    </div>
                        <div class=\"ibox-content\">
                            <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Fecha</th>
                                            <th>Sede de origen</th>
                                            <th>Acciones</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>192845</td>
                                                <td>10/10/2018</td>
                                                <td>Caracas</td>
                                                <td>
                                                <a style=\"font-size:22px;\" title=\"Mostrar factura\" onclick=\"mostrarFactura(";
        // line 55
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["s"] ?? null), "id_factura", array()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["s"] ?? null), "id_fecha", array()), "html", null, true);
        echo "')\"><i class=\"fa fa-eye naranja\"></i></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>192845</td>
                                                <td>10/10/2018</td>
                                                <td>Caracas</td>
                                                <td>
                                                <a style=\"font-size:22px;\" title=\"Mostrar factura\" onclick=\"mostrarFactura(";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["s"] ?? null), "id_factura", array()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["s"] ?? null), "id_fecha", array()), "html", null, true);
        echo "')\"><i class=\"fa fa-eye naranja\"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Id</th>
                                            <th>Fecha</th>
                                            <th>Sede de origen</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
</div>
";
    }

    // line 85
    public function block_appFooter($context, array $blocks = array())
    {
        echo " 
";
    }

    public function getTemplateName()
    {
        return "factura/factura-tabla.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 85,  102 => 63,  89 => 55,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "factura/factura-tabla.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\factura\\factura-tabla.twig");
    }
}

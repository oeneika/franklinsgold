<?php

/* rango/editar.twig */
class __TwigTemplate_5f7ebacefa31f35c2a296c0343d66066487e0635796ee13140748951118b3f89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarRango\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                    <h4 class=\"modal-title\">Creación de Rango</h4>
                    <small class=\"font-bold\">Franklin Gold</small>
                </div>
                <div class=\"modal-body\">
                    <form role=\"form\" id=\"editar_rango_form\">
                        <div class=\"row\">

                            <input name=\"id_rango\" id=\"id_id_rango\" type=\"hidden\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                            <!--<div class=\"col-md-6 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"nombre\" class=\"control-label mb-1\">Nombre</label>
                                    <input name=\"nombre_rango\" id=\"id_nombre_rango\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                                </div>
                            </div>-->
    
                            <div class=\"col-md-12 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"monto_diario\" class=\"control-label mb-1\">Monto diario(Dólares)</label>
                                    <input name=\"monto_diario\" id=\"id_monto_diario\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" >
                                </div>
                            </div>
    
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                    <button type=\"button\" id=\"editarrangobtn\" class=\"btn btn-primary\">Guardar</button>
                </div>
            </div>
        </div>
    </div>";
    }

    public function getTemplateName()
    {
        return "rango/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "rango/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\rango\\editar.twig");
    }
}

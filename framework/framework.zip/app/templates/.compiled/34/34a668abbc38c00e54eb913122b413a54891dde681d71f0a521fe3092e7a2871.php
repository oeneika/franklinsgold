<?php

/* home/intercambioencomercio.twig */
class __TwigTemplate_a33897165b3befe083f5e32e86c367a77ee1754f0a1f1d9789c63a1af2ba363d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"intercambioencomercioModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                    <h4 class=\"modal-title\">Intercambio en comercio afiliado</h4>
                    <small class=\"font-bold\">Franklin Gold</small>
                </div>
    
                <div class=\"modal-body\">
    
                    <form id=\"crearIntercambioComercio_form\">
                        <div class=\"row\">
    
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cliente\" class=\"control-label mb-1\" >Clientes</label>
                                <select name=\"id_cliente\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Seleccione un cliente</option>
                                    ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["clientes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 21
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "id_user", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["c"], "usuario", array()), "html", null, true);
            echo "</option>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "                                </select>
                            </div>
                        </div> 

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_tipo_int\" class=\"control-label mb-1\" >Tipo metal</label>
                                <select name=\"tipo_gramo\" id=\"id_tipo_int\" class=\"form-control\" style=\"width: 100%\">
                                    <option disabled selected value>Tipo</option>
                                    <option value=\"oro\">Oro</option>
                                    <option value=\"plata\">Plata</option>
                                </select>
                            </div>                         
                        </div>                    

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cantidad_bolivar_soberano_int\" class=\"control-label mb-1\" >Cantidad BsS</label>
                                <input name=\"cantidad_bolivar_soberano\" id=\"id_cantidad_bolivar_soberano_int\" type=\"number\" onchange=\"resetQuantity('id_cantidad_bolivar_soberano_int','id_tipo_int','id_cantidad_int')\" class=\"form-control\" >
                            </div>
                        </div>  

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"id_cantidad_int\" class=\"control-label mb-1\" >Cantidad(gramos)</label>
                                <input name=\"cantidad\" id=\"id_cantidad_int\" readonly=\"readonly\" type=\"number\"> 
                            </div>                         
                        </div>
                         
                         
                    </form>
    
                </div>
    
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                    <button type=\"button\" id=\"crearIntercambioEnComercioBtn\" class=\"btn btn-primary\">Crear</button>
                </div>
            </div>
        </div>
    </div>
    ";
    }

    public function getTemplateName()
    {
        return "home/intercambioencomercio.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 23,  44 => 21,  40 => 20,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "home/intercambioencomercio.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\home\\intercambioencomercio.twig");
    }
}

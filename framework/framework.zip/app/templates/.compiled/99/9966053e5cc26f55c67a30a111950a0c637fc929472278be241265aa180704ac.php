<?php

/* ordenes/dashboard.twig */
class __TwigTemplate_40eca5a012294b452b8e8a86fa7d7fa9cb391c5be3e057eae93c575678081b35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "ordenes/dashboard.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "ordenes/dashboard.twig", 5)->display($context);
        // line 6
        echo "</div>

            <div class=\"wrapper wrapper-content\">
            \t<div class=\"row\">
            \t\t<div class=\"col-md-12\">
                   ";
        // line 12
        echo "            \t\t</div>
            \t</div>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio del oro (USD)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"lineChart\" height=\"40\" width=\"100%\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        <i id=\"fecha_oro\"> </i>
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio de la plata (USD)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"plataChart\" height=\"40\" width=\"100%\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">  
                                        <i class=\"fa fa-clock-o\"> </i>                                     
                                        <i id=\"fecha_plata\"></i>
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Gramos comprados en oro</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 69
        echo twig_escape_filter($this->env, (((($context["total_oro_comprado"] ?? null) == null)) ? (0) : (($context["total_oro_comprado"] ?? null))), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Total de oro en dólares</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 79
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_round((($context["total_oro_comprado"] ?? null) * ($context["ultimo_precio_oro"] ?? null)), 2, "ceil"), 2, ",", "."), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Gramos comprados en plata</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 89
        echo twig_escape_filter($this->env, (((($context["total_plata_comprado"] ?? null) == null)) ? (0) : (($context["total_plata_comprado"] ?? null))), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Total de plata en dólares</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 99
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_round((($context["total_plata_comprado"] ?? null) * ($context["ultimo_precio_plata"] ?? null)), 2, "ceil"), 2, ",", "."), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class=\"row\">
                    <div class=\"col-lg-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Últimas transacciones realizadas de oro</h5>
                            </div>
                            <div class=\"ibox-content\">
                                 <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Fecha</th>
                                            <th>Usuario</th>
                                            <!--<th>Sucursal</th>-->
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Monto(USD)</th>
                                            <th>Tipo</th>
                                        </tr>
                                        </thead>
                                        <tbody>  
                                            ";
        // line 126
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ultimas_cinco_ordenes_oro"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            echo " 
                                            <tr>
                                                <td>";
            // line 128
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "fecha", array())), "html", null, true);
            echo "</td>
                                                <td>";
            // line 129
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "primer_apellido", array()), "html", null, true);
            echo "</td>
                                                ";
            // line 131
            echo "                                                <td>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 132
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td>";
            // line 133
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td style=\"";
            // line 134
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 1)) ? ("color: #DC2929;") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 2)) ? ("color: red;") : ("color: #3CD219;"))));
            echo "\">";
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 1)) ? ("Compra") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 2)) ? ("Venta") : ("Intercambio"))));
            echo "</td>
                                            </tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 136
        echo "  
                                        </tbody>
                                    </table>
                            \t</div>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-6\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Últimas transacciones realizadas de plata</h5>
                            </div>
                            <div class=\"ibox-content\">
                                 <div class=\"table-responsive\">
                                    <table class=\"table table-striped table-bordered table-hover tablita\" >
                                        <thead>
                                        <tr>
                                            <th>Fecha</th>
                                            <th>Usuario</th>
                                            <!--<th>Sucursal</th>-->
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Monto(USD)</th>
                                            <th>Tipo</th>
                                        </tr>
                                        </thead>
                                        <tbody>  
                                           ";
        // line 163
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ultimas_cinco_ordenes_plata"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            echo " 
                                            <tr>
                                                <td>";
            // line 165
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "fecha", array())), "html", null, true);
            echo "</td>
                                                <td>";
            // line 166
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "primer_apellido", array()), "html", null, true);
            echo "</td>
                                                ";
            // line 168
            echo "                                                <td>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "cantidad", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 169
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "precio", array()), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td>";
            // line 170
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "cantidad", array()) * twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "precio", array())), 2, ",", "."), "html", null, true);
            echo "</td>
                                                <td style=\"";
            // line 171
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 1)) ? ("color: #DC2929;;") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 2)) ? ("color: red;") : ("color: #3CD219;"))));
            echo "\">";
            echo (((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 1)) ? ("Compra") : ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["a"], "tipo_orden", array()) == 2)) ? ("Venta") : ("Intercambio"))));
            echo "</td>
                                            </tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 173
        echo "                           
                                        </tbody>
                                    </table>
                            \t</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

";
        // line 183
        $this->loadTemplate("ordenes/compra", "ordenes/dashboard.twig", 183)->display($context);
        // line 184
        $this->loadTemplate("ordenes/venta", "ordenes/dashboard.twig", 184)->display($context);
        // line 185
        $this->loadTemplate("ordenes/intercambio", "ordenes/dashboard.twig", 185)->display($context);
        // line 186
        $this->loadTemplate("overall/footer", "ordenes/dashboard.twig", 186)->display($context);
        // line 187
        echo "</div>
";
    }

    // line 190
    public function block_appFooter($context, array $blocks = array())
    {
        // line 191
        echo "    <script src=\"./assets/jscontrollers/ordenes/crear.js\"></script>
    <script src=\"./assets/jscontrollers/home/dashboard.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "ordenes/dashboard.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  312 => 191,  309 => 190,  304 => 187,  302 => 186,  300 => 185,  298 => 184,  296 => 183,  284 => 173,  273 => 171,  269 => 170,  265 => 169,  260 => 168,  254 => 166,  250 => 165,  243 => 163,  214 => 136,  203 => 134,  199 => 133,  195 => 132,  190 => 131,  184 => 129,  180 => 128,  173 => 126,  143 => 99,  130 => 89,  117 => 79,  104 => 69,  45 => 12,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ordenes/dashboard.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\ordenes\\dashboard.twig");
    }
}

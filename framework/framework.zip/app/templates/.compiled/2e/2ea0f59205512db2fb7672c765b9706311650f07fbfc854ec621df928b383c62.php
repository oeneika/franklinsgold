<?php

/* landing/landing.twig */
class __TwigTemplate_5db19656dd1e8ecc2a505ea7c08810b510418eec6612983b0108b5daf863271f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-landing", "landing/landing.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-landing";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "\t<div class=\"navbar-wrapper\">
\t        <nav class=\"navbar navbar-default navbar-fixed-top navbar-expand-md\" role=\"navigation\">
\t            <div class=\"container\">
\t                <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbar\">
\t                    <ul class=\"nav navbar-nav navbar-right\">
\t                        <li><a class=\"nav-link page-scroll\" href=\"../login/\">Iniciar Sesión</a></li>
\t                        <li><a class=\"nav-link page-scroll\" href=\"../registro/\">Registrarse</a></li>
\t                    </ul>
\t                </div>
\t            </div>
\t        </nav>
\t</div>

\t<section class=\"features\">
\t    <div class=\"container\">
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center\">
\t                <div class=\"navy-line\"></div>
\t                <h1>Franklin's Gold</h1>
\t                <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. </p>
\t            </div>
\t        </div>
\t        <div class=\"row features-block\">
\t            <div class=\"col-lg-3 features-text wow fadeInLeft\">
\t                <h2>Compra y venta de monedas de oro</h2>
\t                <p>INSPINIA Admin Theme is a premium admin dashboard template with flat design concept. It is fully responsive admin dashboard template built with Bootstrap 3+ Framework, HTML5 and CSS3, Media query. It has a huge collection of reusable UI components and integrated with latest jQuery plugins.</p>
\t            </div>
\t            <div class=\"col-lg-6 text-right m-t-n-lg wow zoomIn\">
\t                <img src=\"../views/img/landing/iphone.jpg\" class=\"img-fluid\" alt=\"dashboard\" style=\"max-width:100%; height:auto;\">
\t            </div>
\t            <div class=\"col-lg-3 features-text text-right wow fadeInRight\">
\t                <h2>Compra y venta de monedas de plata</h2>
\t                <p>INSPINIA Admin Theme is a premium admin dashboard template with flat design concept. It is fully responsive admin dashboard template built with Bootstrap 3+ Framework, HTML5 and CSS3, Media query. It has a huge collection of reusable UI components and integrated with latest jQuery plugins.</p>
\t            </div>
\t        </div>
\t    </div>
\t</section>

\t<section id=\"contact\" class=\"gray-section contact\">
\t    <div class=\"container\">
\t        <div class=\"row m-b-lg\">
\t            <div class=\"col-lg-12 text-center\">
\t                <div class=\"navy-line\"></div>
\t                <h1>Contáctanos</h1>
\t                <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.</p>
\t            </div>
\t        </div>
\t        <div class=\"row m-b-lg justify-content-center\">
\t            <div class=\"col-lg-3 \">
\t                <address>
\t                    <strong><span class=\"navy\">Company name, Inc.</span></strong><br/>
\t                    795 Folsom Ave, Suite 600<br/>
\t                    San Francisco, CA 94107<br/>
\t                    <abbr title=\"Phone\">P:</abbr> (123) 456-7890
\t                </address>
\t            </div>
\t            <div class=\"col-lg-4\">
\t                <p class=\"text-color\">
\t                    Consectetur adipisicing elit. Aut eaque, totam corporis laboriosam veritatis quis ad perspiciatis, totam corporis laboriosam veritatis, consectetur adipisicing elit quos non quis ad perspiciatis, totam corporis ea,
\t                </p>
\t            </div>
\t        </div>
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center\">
\t                <a href=\"mailto:test@email.com\" class=\"btn btn-primary\">Enviar E-mail</a>
\t                <p class=\"m-t-sm\">
\t                    Síguenos en nuestras redes sociales
\t                </p>
\t                <ul class=\"list-inline social-icon\">
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-twitter\"></i></a>
\t                    </li>
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-facebook\"></i></a>
\t                    </li>
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>
\t                    </li>
\t                </ul>
\t            </div>
\t        </div>
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center m-t-lg m-b-lg\">
\t                <p><strong>&copy; 2018 Franklin's Gold</strong><br/> consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
\t            </div>
\t        </div>
\t    </div>
\t</section>
";
    }

    public function getTemplateName()
    {
        return "landing/landing.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout-landing' %}
{% block appBody %}
\t<div class=\"navbar-wrapper\">
\t        <nav class=\"navbar navbar-default navbar-fixed-top navbar-expand-md\" role=\"navigation\">
\t            <div class=\"container\">
\t                <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbar\">
\t                    <ul class=\"nav navbar-nav navbar-right\">
\t                        <li><a class=\"nav-link page-scroll\" href=\"../login/\">Iniciar Sesión</a></li>
\t                        <li><a class=\"nav-link page-scroll\" href=\"../registro/\">Registrarse</a></li>
\t                    </ul>
\t                </div>
\t            </div>
\t        </nav>
\t</div>

\t<section class=\"features\">
\t    <div class=\"container\">
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center\">
\t                <div class=\"navy-line\"></div>
\t                <h1>Franklin's Gold</h1>
\t                <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. </p>
\t            </div>
\t        </div>
\t        <div class=\"row features-block\">
\t            <div class=\"col-lg-3 features-text wow fadeInLeft\">
\t                <h2>Compra y venta de monedas de oro</h2>
\t                <p>INSPINIA Admin Theme is a premium admin dashboard template with flat design concept. It is fully responsive admin dashboard template built with Bootstrap 3+ Framework, HTML5 and CSS3, Media query. It has a huge collection of reusable UI components and integrated with latest jQuery plugins.</p>
\t            </div>
\t            <div class=\"col-lg-6 text-right m-t-n-lg wow zoomIn\">
\t                <img src=\"../views/img/landing/iphone.jpg\" class=\"img-fluid\" alt=\"dashboard\" style=\"max-width:100%; height:auto;\">
\t            </div>
\t            <div class=\"col-lg-3 features-text text-right wow fadeInRight\">
\t                <h2>Compra y venta de monedas de plata</h2>
\t                <p>INSPINIA Admin Theme is a premium admin dashboard template with flat design concept. It is fully responsive admin dashboard template built with Bootstrap 3+ Framework, HTML5 and CSS3, Media query. It has a huge collection of reusable UI components and integrated with latest jQuery plugins.</p>
\t            </div>
\t        </div>
\t    </div>
\t</section>

\t<section id=\"contact\" class=\"gray-section contact\">
\t    <div class=\"container\">
\t        <div class=\"row m-b-lg\">
\t            <div class=\"col-lg-12 text-center\">
\t                <div class=\"navy-line\"></div>
\t                <h1>Contáctanos</h1>
\t                <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.</p>
\t            </div>
\t        </div>
\t        <div class=\"row m-b-lg justify-content-center\">
\t            <div class=\"col-lg-3 \">
\t                <address>
\t                    <strong><span class=\"navy\">Company name, Inc.</span></strong><br/>
\t                    795 Folsom Ave, Suite 600<br/>
\t                    San Francisco, CA 94107<br/>
\t                    <abbr title=\"Phone\">P:</abbr> (123) 456-7890
\t                </address>
\t            </div>
\t            <div class=\"col-lg-4\">
\t                <p class=\"text-color\">
\t                    Consectetur adipisicing elit. Aut eaque, totam corporis laboriosam veritatis quis ad perspiciatis, totam corporis laboriosam veritatis, consectetur adipisicing elit quos non quis ad perspiciatis, totam corporis ea,
\t                </p>
\t            </div>
\t        </div>
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center\">
\t                <a href=\"mailto:test@email.com\" class=\"btn btn-primary\">Enviar E-mail</a>
\t                <p class=\"m-t-sm\">
\t                    Síguenos en nuestras redes sociales
\t                </p>
\t                <ul class=\"list-inline social-icon\">
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-twitter\"></i></a>
\t                    </li>
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-facebook\"></i></a>
\t                    </li>
\t                    <li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>
\t                    </li>
\t                </ul>
\t            </div>
\t        </div>
\t        <div class=\"row\">
\t            <div class=\"col-lg-12 text-center m-t-lg m-b-lg\">
\t                <p><strong>&copy; 2018 Franklin's Gold</strong><br/> consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
\t            </div>
\t        </div>
\t    </div>
\t</section>
{% endblock %}", "landing/landing.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\landing\\landing.twig");
    }
}

<?php

/* sucursal/crear.twig */
class __TwigTemplate_6871fe6cc6f03f0752ba2e2fc9c77d49280f95e1e0a61cbe1d77f6864298f395 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearSucursal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Sucursal</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form role=\"form\" id=\"crear_sucursal_form\">
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"nombre\" class=\"control-label mb-1\">Nombre</label>
                                <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Teléfono</label>
                                <input name=\"telefono\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>

                        <div class=\"col-md-12 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"direccion\" class=\"control-label mb-1\">Dirección</label>
                                <input name=\"direccion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearsucursalbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "sucursal/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"crearSucursal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Sucursal</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form role=\"form\" id=\"crear_sucursal_form\">
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"nombre\" class=\"control-label mb-1\">Nombre</label>
                                <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>

                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Teléfono</label>
                                <input name=\"telefono\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>

                        <div class=\"col-md-12 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"direccion\" class=\"control-label mb-1\">Dirección</label>
                                <input name=\"direccion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearsucursalbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
", "sucursal/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\sucursal\\crear.twig");
    }
}

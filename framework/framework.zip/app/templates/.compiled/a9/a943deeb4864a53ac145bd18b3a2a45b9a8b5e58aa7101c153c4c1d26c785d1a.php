<?php

/* origen/crear.twig */
class __TwigTemplate_b6eacf12550399f1109b2ba0aa1e5eb4335cccc2385b0a18723239b253f6425f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearOrigen\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Creación de origen</h4>
                <small class=\"font-bold\">Franklin Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_origen_form\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre
                                    <span>*</span>
                                </label>
                                <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Abreviatura
                                    <span>*</span>
                                </label>
                                <input name=\"abreviatura\" maxlength=\"3\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrigenbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "origen/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "origen/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\origen\\crear.twig");
    }
}

<?php

/* usuarios/crear.twig */
class __TwigTemplate_b2254bd33735cc9df79025d50cf48cc798b5553b1a0335d3b073d13eb5a188e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Usuarios</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_usuario_form\">
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input  name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input  name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input  name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido </label>
                                <input  name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"usuario\" class=\"control-label mb-1\">Usuario <span>*</span></label>
                                <input  name=\"usuario\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input type=\"radio\" checked=\"\" value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input type=\"radio\" checked=\"\" value=\"1\"  name=\"tipo\"> Vendedor
                                </div>
                            </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Télefono <span>*</span></label>
                                <input name=\"telefono\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"email\" class=\"control-label mb-1\">Correo <span>*</span></label>
                                <input name=\"email\" type=\"email\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearUsuariobtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"crearUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Usuarios</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_usuario_form\">
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input  name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input  name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input  name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido </label>
                                <input  name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"usuario\" class=\"control-label mb-1\">Usuario <span>*</span></label>
                                <input  name=\"usuario\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input type=\"radio\" checked=\"\" value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input type=\"radio\" checked=\"\" value=\"1\"  name=\"tipo\"> Vendedor
                                </div>
                            </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Télefono <span>*</span></label>
                                <input name=\"telefono\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"email\" class=\"control-label mb-1\">Correo <span>*</span></label>
                                <input name=\"email\" type=\"email\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"password\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearUsuariobtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>
", "usuarios/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\crear.twig");
    }
}

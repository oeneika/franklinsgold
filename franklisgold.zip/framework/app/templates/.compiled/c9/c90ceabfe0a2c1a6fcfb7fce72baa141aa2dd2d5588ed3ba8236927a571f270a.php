<?php

/* transaccion/compra.twig */
class __TwigTemplate_0c09d3c40fbc7ef8623b28f224b66bdb13187586e5c7df76b1498fc2c91afa19 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "transaccion/compra.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "transaccion/compra.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money\"></i> Compras</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Compras</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">

                <a onclick=\"crearTransaccion(1)\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-tags\"></i> Crear Compra</a>

                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Compras registradas en el sistema</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transacciones"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 56
            echo "                                    <tr>
                                        <td>";
            // line 57
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id_transaccion", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_apellido", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id_user", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 59
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "codigo", array()), "html", null, true);
            echo "</td>
                                        <td>\$";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "precio_moneda1", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "nombre_sucursal", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "fecha", array())), "html", null, true);
            echo "</td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 65
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
        // line 88
        $this->loadTemplate("transaccion/crear", "transaccion/compra.twig", 88)->display($context);
        echo " 
    ";
        // line 89
        $this->loadTemplate("overall/footer", "transaccion/compra.twig", 89)->display($context);
        // line 90
        echo "</div>
";
    }

    // line 92
    public function block_appFooter($context, array $blocks = array())
    {
        // line 93
        echo "    <script src=\"./assets/jscontrollers/transaccion/crear.js\"></script> 
<script>
    \$(document).ready(function () {
        \$('.dataTables-example').DataTable({
            dom: '<\"html5buttons\"B>lTfgitp',
            buttons: [
                { extend: 'excel', title: 'ExampleFile' },
                { extend: 'pdf', title: 'ExampleFile' },

                {
                    extend: 'print',
                    customize: function (win) {
                        \$(win.document.body).addClass('white-bg');
                        \$(win.document.body).css('font-size', '10px');

                        \$(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });


    });
</script> 
";
    }

    public function getTemplateName()
    {
        return "transaccion/compra.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 93,  170 => 92,  165 => 90,  163 => 89,  159 => 88,  138 => 69,  129 => 65,  121 => 62,  117 => 61,  113 => 60,  109 => 59,  101 => 58,  97 => 57,  94 => 56,  89 => 55,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %} 
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        {% include 'overall/header' %}
    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money\"></i> Compras</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Compras</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">

                <a onclick=\"crearTransaccion(1)\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-tags\"></i> Crear Compra</a>

                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Compras registradas en el sistema</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for t in transacciones %}
                                    <tr>
                                        <td>{{t.id_transaccion}}</td>
                                        <td>{{t.primer_nombre}} {{t.primer_apellido}} {{t.id_user}}</td>
                                        <td>{{t.codigo}}</td>
                                        <td>\${{t.precio_moneda1}}</td>
                                        <td>{{t.nombre_sucursal}}</td>
                                        <td>{{ fecha('D, d F, Y h:i a', t.fecha) }}</td>
                                    </tr>
                                    {% else %}
                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    {% include 'transaccion/crear' %} 
    {% include 'overall/footer' %}
</div>
{% endblock %} 
{% block appFooter %}
    <script src=\"./assets/jscontrollers/transaccion/crear.js\"></script> 
<script>
    \$(document).ready(function () {
        \$('.dataTables-example').DataTable({
            dom: '<\"html5buttons\"B>lTfgitp',
            buttons: [
                { extend: 'excel', title: 'ExampleFile' },
                { extend: 'pdf', title: 'ExampleFile' },

                {
                    extend: 'print',
                    customize: function (win) {
                        \$(win.document.body).addClass('white-bg');
                        \$(win.document.body).css('font-size', '10px');

                        \$(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });


    });
</script> 
{% endblock %}", "transaccion/compra.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\compra.twig");
    }
}

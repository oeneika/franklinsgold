<?php

/* home/home.twig */
class __TwigTemplate_79f700e7e36172c07a5fa2732cbdc75fef8ffc4bbc0c8442d8d04f9bb97fdf1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "home/home.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    ";
        // line 5
        $this->loadTemplate("overall/header", "home/home.twig", 5)->display($context);
        // line 6
        echo "</div>

            <div class=\"wrapper wrapper-content\">
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio del oro en el mercado al contado</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio del oro (En dolares)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"lineChart\" height=\"70\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        Actualizado el 07/07/2018
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio de la plata en el mercado al contado</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio de la plata (En dolares)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"plataChart\" height=\"70\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        Actualizado el 07/07/2018
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>


                <div class=\"row\">

                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-primary pull-right\">Hoy</span>
                                <h5>Ventas Diarias</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 77
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "diarias", array()), "total", array()), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-info pull-right\">Mensual</span>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 87
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "mensuales", array()), "total", array()), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-warning pull-right\">Anual</span>
                                <h5>Ventas del año</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 98
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "anuales", array()), "total", array()), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                </div>

                <div class=\"row\">

                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Usuarios registrados en el sistema</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">";
        // line 112
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "usuarios", array()), "total", array()), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Dolares de monedas vendidas en oro</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">\$";
        // line 122
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ventas_oro", array()), "total", array()), 2, ".", ","), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Dolares de monedas vendidas en plata</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">\$";
        // line 132
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ventas_plata", array()), "total", array()), 2, ".", ","), "html", null, true);
        echo "</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

";
        // line 139
        $this->loadTemplate("overall/footer", "home/home.twig", 139)->display($context);
        // line 140
        echo "</div>
";
    }

    // line 143
    public function block_appFooter($context, array $blocks = array())
    {
        // line 144
        echo "    <script src=\"./assets/jscontrollers/home/dashboard.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "home/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 144,  198 => 143,  193 => 140,  191 => 139,  181 => 132,  168 => 122,  155 => 112,  138 => 98,  124 => 87,  111 => 77,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
<div class=\"row border-bottom\">
    {% include 'overall/header' %}
</div>

            <div class=\"wrapper wrapper-content\">
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio del oro en el mercado al contado</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio del oro (En dolares)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"lineChart\" height=\"70\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        Actualizado el 07/07/2018
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-content\">
                                    <div>
                                        <span class=\"pull-right text-right\">
                                        <small>Cotización en tiempo real del precio de la plata en el mercado al contado</small>
                                        </span>
                                        <h3 class=\"font-bold no-margins\">
                                            Precio de la plata (En dolares)
                                        </h3>
                                    </div>

                                <div>
                                    <canvas id=\"plataChart\" height=\"70\"></canvas>
                                </div>

                                <div class=\"m-t-md\">
                                    <small class=\"pull-right\">
                                        <i class=\"fa fa-clock-o\"> </i>
                                        Actualizado el 07/07/2018
                                    </small>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>


                <div class=\"row\">

                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-primary pull-right\">Hoy</span>
                                <h5>Ventas Diarias</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">{{ data.diarias.total }}</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-info pull-right\">Mensual</span>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">{{ data.mensuales.total }}</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <span class=\"label label-warning pull-right\">Anual</span>
                                <h5>Ventas del año</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">{{ data.anuales.total }}</h1>
                            </div>
                        </div>
                    </div>
                </div>

                <div class=\"row\">

                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Usuarios registrados en el sistema</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">{{ data.usuarios.total }}</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Dolares de monedas vendidas en oro</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">\${{ data.ventas_oro.total|number_format(2,'.',',') }}</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-lg-4\">
                        <div class=\"ibox float-e-margins\">
                            <div class=\"ibox-title\">
                                <h5>Dolares de monedas vendidas en plata</h5>
                            </div>
                            <div class=\"ibox-content\">
                                <h1 class=\"no-margins\">\${{ data.ventas_plata.total|number_format(2,'.',',') }}</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

{% include 'overall/footer' %}
</div>
{% endblock %}

{% block appFooter %}
    <script src=\"./assets/jscontrollers/home/dashboard.js\"></script>
{% endblock %}
", "home/home.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\home\\home.twig");
    }
}

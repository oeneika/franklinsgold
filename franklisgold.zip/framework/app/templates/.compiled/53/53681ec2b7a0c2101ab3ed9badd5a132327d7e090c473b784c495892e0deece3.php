<?php

/* origen/origen.twig */
class __TwigTemplate_816e9cd808a59a027ebdf6b22b3ad42718949a9d3dc15044b971caa1628c7864 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "origen/origen.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 5
        $this->loadTemplate("overall/header", "origen/origen.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-user\"></i> Origen</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Origen</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">

                <a onclick=\"crearOrigen()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-user\"></i> Crear origen</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Origen</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Id_origen</th>
                                        <th>Nombre</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["origenes"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["o"]) {
            // line 52
            echo "                                    <tr>
                                        <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_origen", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "nombre", array()), "html", null, true);
            echo "</td>
                                        <td>
                                            <a onclick=\"editar_un_origen(";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_origen", array()), "html", null, true);
            echo ",'";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "nombre", array()), "html", null, true);
            echo "')\" style=\"font-size:22px;\" title=\"Editar\">
                                                <i class=\"fa fa-sliders naranja\"></i>
                                            </a>
                                            <a onclick=\"delete_item(";
            // line 59
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["o"], "id_origen", array()), "html", null, true);
            echo ",'origen')\" style=\"font-size:22px;\" title=\"Eliminar\">
                                                <i class=\"fa fa-trash naranja\"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 65
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['o'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Id_origen</th>
                                        <th>Nombre</th>
                                        <th>Acciones</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
        // line 84
        $this->loadTemplate("origen/crear", "origen/origen.twig", 84)->display($context);
        echo " 
    ";
        // line 85
        $this->loadTemplate("origen/editar", "origen/origen.twig", 85)->display($context);
        // line 86
        echo "    ";
        $this->loadTemplate("overall/footer", "origen/origen.twig", 86)->display($context);
        // line 87
        echo "</div>
";
    }

    // line 89
    public function block_appFooter($context, array $blocks = array())
    {
        // line 90
        echo "    <script src=\"./assets/jscontrollers/origen/crear.js\"></script>
    <script src=\"./assets/jscontrollers/origen/editar.js\"></script>
    <script src=\"views/propios/js/delete_item.js\"></script>   
";
    }

    public function getTemplateName()
    {
        return "origen/origen.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 90,  161 => 89,  156 => 87,  153 => 86,  151 => 85,  147 => 84,  130 => 69,  121 => 65,  110 => 59,  102 => 56,  97 => 54,  93 => 53,  90 => 52,  85 => 51,  38 => 6,  36 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        {% include 'overall/header' %}
    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-user\"></i> Origen</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Origen</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">

                <a onclick=\"crearOrigen()\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-user\"></i> Crear origen</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Origen</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Id_origen</th>
                                        <th>Nombre</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for o in origenes %}
                                    <tr>
                                        <td>{{o.id_origen}}</td>
                                        <td>{{o.nombre}}</td>
                                        <td>
                                            <a onclick=\"editar_un_origen({{o.id_origen}},'{{o.nombre}}')\" style=\"font-size:22px;\" title=\"Editar\">
                                                <i class=\"fa fa-sliders naranja\"></i>
                                            </a>
                                            <a onclick=\"delete_item({{o.id_origen}},'origen')\" style=\"font-size:22px;\" title=\"Eliminar\">
                                                <i class=\"fa fa-trash naranja\"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    {% else %}
                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Id_origen</th>
                                        <th>Nombre</th>
                                        <th>Acciones</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {% include 'origen/crear' %} 
    {% include 'origen/editar' %}
    {% include 'overall/footer' %}
</div>
{% endblock %}
{% block appFooter %}
    <script src=\"./assets/jscontrollers/origen/crear.js\"></script>
    <script src=\"./assets/jscontrollers/origen/editar.js\"></script>
    <script src=\"views/propios/js/delete_item.js\"></script>   
{% endblock %}", "origen/origen.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\origen\\origen.twig");
    }
}

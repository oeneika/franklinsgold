<?php

/* origen/editar.twig */
class __TwigTemplate_0f8bcd82c7ee3ffa56034e9cc98065e12b3590d60503bc6dbcd5c2bc01dc3eb8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarorigen\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Edición de origen</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"editar_origen_form\">
                    <input name=\"id_origen\" id=\"id_id_origen\" type=\"hidden\">

                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre</label>
                                <input name=\"nombre\" id=\"id_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editarorigenbtn\" class=\"btn btn-primary\">editar</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "origen/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"editarorigen\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Edición de origen</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"editar_origen_form\">
                    <input name=\"id_origen\" id=\"id_id_origen\" type=\"hidden\">

                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre</label>
                                <input name=\"nombre\" id=\"id_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editarorigenbtn\" class=\"btn btn-primary\">editar</button>
            </div>
        </div>
    </div>
</div>", "origen/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\origen\\editar.twig");
    }
}

<?php

/* transaccion/venta.twig */
class __TwigTemplate_f203a03848a0d4a91931834b800331766382759cdbb0223bb0cc9780dc29920b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "transaccion/venta.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function block_appBody($context, array $blocks = array())
    {
        // line 2
        echo "<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        ";
        // line 4
        $this->loadTemplate("overall/header", "transaccion/venta.twig", 4)->display($context);
        // line 5
        echo "    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money\"></i> Ventas</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Ventas</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <a onclick=\"crearTransaccion(2)\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-tags\"></i> Crear Venta</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Ventas registradas en el sistema</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transacciones"] ?? null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 53
            echo "                                    <tr>
                                        <td>";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id_transaccion", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_nombre", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "primer_apellido", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "id_user", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "codigo", array()), "html", null, true);
            echo "</td>
                                        <td>\$";
            // line 57
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "precio_moneda1", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "nombre_sucursal", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->fecha("D, d F, Y h:i a", twig_get_attribute($this->env, $this->getSourceContext(), $context["t"], "fecha", array())), "html", null, true);
            echo "</td>
                                    </tr>
                                    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 62
            echo "                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
        // line 85
        $this->loadTemplate("transaccion/crear", "transaccion/venta.twig", 85)->display($context);
        echo " 
    ";
        // line 86
        $this->loadTemplate("overall/footer", "transaccion/venta.twig", 86)->display($context);
        // line 87
        echo "</div>
";
    }

    // line 88
    public function block_appFooter($context, array $blocks = array())
    {
        // line 89
        echo "    <script src=\"./assets/jscontrollers/transaccion/crear.js\"></script>
<script>
    \$(document).ready(function () {
        \$('.dataTables-example').DataTable({
            dom: '<\"html5buttons\"B>lTfgitp',
            buttons: [
                { extend: 'excel', title: 'ExampleFile' },
                { extend: 'pdf', title: 'ExampleFile' },

                {
                    extend: 'print',
                    customize: function (win) {
                        \$(win.document.body).addClass('white-bg');
                        \$(win.document.body).css('font-size', '10px');

                        \$(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });


    });
</script> ";
    }

    public function getTemplateName()
    {
        return "transaccion/venta.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 89,  167 => 88,  162 => 87,  160 => 86,  156 => 85,  135 => 66,  126 => 62,  118 => 59,  114 => 58,  110 => 57,  106 => 56,  98 => 55,  94 => 54,  91 => 53,  86 => 52,  37 => 5,  35 => 4,  31 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %} {% block appBody %}
<div id=\"page-wrapper\" class=\"gray-bg\">
    <div class=\"row border-bottom\">
        {% include 'overall/header' %}
    </div>
    <div class=\"row wrapper border-bottom white-bg page-heading\">
        <div class=\"col-lg-10\">
            <h2>
                <i class=\"fa fa-money\"></i> Ventas</h2>
            <ol class=\"breadcrumb\">
                <li>
                    <a href=\"home/\">Home</a>
                </li>
                <li class=\"active\">
                    <strong>Ventas</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"wrapper wrapper-content animated fadeInRight\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <a onclick=\"crearTransaccion(2)\" class=\"btn btn-warning btn-rounded\" style=\"float:right; margin-bottom:10px;\">
                    <i class=\"fa fa-tags\"></i> Crear Venta</a>
                <div class=\"ibox float-e-margins\">
                    <div class=\"ibox-title\">
                        <h5>Ventas registradas en el sistema</h5>
                        <div class=\"ibox-tools\">
                            <a class=\"collapse-link\">
                                <i class=\"fa fa-chevron-up\"></i>
                            </a>
                            <a class=\"close-link\">
                                <i class=\"fa fa-times\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"ibox-content\">
                        <div class=\"table-responsive\">
                            <table class=\"table table-striped table-bordered table-hover dataTables-example\">
                                <thead>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for t in transacciones %}
                                    <tr>
                                        <td>{{t.id_transaccion}}</td>
                                        <td>{{t.primer_nombre}} {{t.primer_apellido}} {{t.id_user}}</td>
                                        <td>{{t.codigo}}</td>
                                        <td>\${{t.precio_moneda1}}</td>
                                        <td>{{t.nombre_sucursal}}</td>
                                        <td>{{ fecha('D, d F, Y h:i a', t.fecha) }}</td>
                                    </tr>
                                    {% else %}
                                    <tr>
                                        <td>No hay resultados</td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Número Transacción</th>
                                        <th>Usuario</th>
                                        <th>Moneda</th>
                                        <th>Precio</th>
                                        <th>Sucursal</th>
                                        <th>Fecha</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    {% include 'transaccion/crear' %} 
    {% include 'overall/footer' %}
</div>
{% endblock %} {% block appFooter %}
    <script src=\"./assets/jscontrollers/transaccion/crear.js\"></script>
<script>
    \$(document).ready(function () {
        \$('.dataTables-example').DataTable({
            dom: '<\"html5buttons\"B>lTfgitp',
            buttons: [
                { extend: 'excel', title: 'ExampleFile' },
                { extend: 'pdf', title: 'ExampleFile' },

                {
                    extend: 'print',
                    customize: function (win) {
                        \$(win.document.body).addClass('white-bg');
                        \$(win.document.body).css('font-size', '10px');

                        \$(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });


    });
</script> {% endblock %}", "transaccion/venta.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\transaccion\\venta.twig");
    }
}

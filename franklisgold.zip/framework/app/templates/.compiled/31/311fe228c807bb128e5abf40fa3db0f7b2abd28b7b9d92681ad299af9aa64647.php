<?php

/* login/login.twig */
class __TwigTemplate_f3132aadbc6c0ee531f72aa11783e4968507cd2ce2495975ce5ce92ee70d5639 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-404", "login/login.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-404";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "
<div class=\"middle-box text-center loginscreen animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:200px;\" /></h1>

            </div>
            <h3 class=\"login-text\">Bienvenido a Franklin's Gold</h3>
            <form class=\"m-t\" role=\"form\" id=\"login_form\">
                <div class=\"form-group\">
                    <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Correo\">
                </div>
                <div class=\"form-group\">
                    <input type=\"password\" name=\"pass\" class=\"form-control\" placeholder=\"Password\">
                </div>
                <button type=\"button\" id='login' class=\"btn btn-primary block full-width m-b\">INICIAR SESIÓN</button>

                <a data-toggle=\"modal\" data-target=\"#lostpassModal\"><small>¿Olvidaste tu clave?</small></a>
                <p class=\"text-muted text-center\"><small>¿Aún no estás registrado en el sistema?</small></p>
                <a class=\"btn btn-sm btn-white btn-block\" href=\"registro/\">¡REGISTRATE!</a>
            </form>
        </div>
</div>

";
        // line 28
        $this->loadTemplate("login/lostpass", "login/login.twig", 28)->display($context);
        // line 29
        echo "
";
    }

    // line 31
    public function block_appFooter($context, array $blocks = array())
    {
        // line 32
        echo "    <script src=\"./assets/jscontrollers/login/login.js\"></script>
    <script src=\"./assets/jscontrollers/login/lostpass.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "login/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 32,  66 => 31,  61 => 29,  59 => 28,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout-404' %}
{% block appBody %}

<div class=\"middle-box text-center loginscreen animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:200px;\" /></h1>

            </div>
            <h3 class=\"login-text\">Bienvenido a Franklin's Gold</h3>
            <form class=\"m-t\" role=\"form\" id=\"login_form\">
                <div class=\"form-group\">
                    <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Correo\">
                </div>
                <div class=\"form-group\">
                    <input type=\"password\" name=\"pass\" class=\"form-control\" placeholder=\"Password\">
                </div>
                <button type=\"button\" id='login' class=\"btn btn-primary block full-width m-b\">INICIAR SESIÓN</button>

                <a data-toggle=\"modal\" data-target=\"#lostpassModal\"><small>¿Olvidaste tu clave?</small></a>
                <p class=\"text-muted text-center\"><small>¿Aún no estás registrado en el sistema?</small></p>
                <a class=\"btn btn-sm btn-white btn-block\" href=\"registro/\">¡REGISTRATE!</a>
            </form>
        </div>
</div>

{% include \"login/lostpass\" %}

{% endblock %}
{% block appFooter %}
    <script src=\"./assets/jscontrollers/login/login.js\"></script>
    <script src=\"./assets/jscontrollers/login/lostpass.js\"></script>
{% endblock %}", "login/login.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\login\\login.twig");
    }
}

<?php

/* monedas/crear.twig */
class __TwigTemplate_1fc8715cbb6b15f8c94ee4412e414bf9ce9a47d7fcbf824417ee3641c9466964 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearMoneda\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Monedas</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"crear_moneda_form\">
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"diametro\" class=\"control-label mb-1\">Diametro <span>*</span></label>
                                <input name=\"diametro\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"espesor\" class=\"control-label mb-1\">Espesor<span>*</span></label>
                                <input name=\"espesor\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"composicion\" class=\"control-label mb-1\">Composición<span>*</span></label>
                                <input name=\"composicion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"peso\" class=\"control-label mb-1\">Peso<span>*</span></label>
                                <input name=\"peso\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"origen\" class=\"control-label mb-1\">Origen<span>*</span></label>                               
                                <select class=\"form-control\" name=\"id_origen\"  aria-required=\"true\" aria-invalid=\"false\">
                                    <option selected disabled value></option>
                                    ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["origenes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["ori"]) {
            // line 44
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["ori"], "id_origen", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["ori"], "nombre", array()), "html", null, true);
            echo "</option>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ori'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearMonedabtn\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "monedas/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 46,  67 => 44,  63 => 43,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"crearMoneda\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Creación de Monedas</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"crear_moneda_form\">
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"diametro\" class=\"control-label mb-1\">Diametro <span>*</span></label>
                                <input name=\"diametro\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"espesor\" class=\"control-label mb-1\">Espesor<span>*</span></label>
                                <input name=\"espesor\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"composicion\" class=\"control-label mb-1\">Composición<span>*</span></label>
                                <input name=\"composicion\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"peso\" class=\"control-label mb-1\">Peso<span>*</span></label>
                                <input name=\"peso\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"origen\" class=\"control-label mb-1\">Origen<span>*</span></label>                               
                                <select class=\"form-control\" name=\"id_origen\"  aria-required=\"true\" aria-invalid=\"false\">
                                    <option selected disabled value></option>
                                    {% for ori in origenes %}
                                        <option value=\"{{ ori.id_origen }}\">{{ ori.nombre }}</option>
                                    {% endfor %}
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearMonedabtn\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
", "monedas/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\monedas\\crear.twig");
    }
}

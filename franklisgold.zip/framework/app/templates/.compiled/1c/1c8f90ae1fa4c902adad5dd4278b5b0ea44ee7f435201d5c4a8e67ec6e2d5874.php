<?php

/* lostpass/lostpass.twig */
class __TwigTemplate_8bb5293566dd9006828fb606548233abc4adc1dfe22d61a295403e9289f64386 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout-404", "lostpass/lostpass.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout-404";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "
<div class=\"middle-box text-center loginscreen animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:200px;\" /></h1>

            </div>
            <h3 class=\"login-text\">Bienvenido a Franklin's Gold</h3>
            <form class=\"m-t\" role=\"form\" id=\"login_form\">
                <div class=\"form-group\">
                    <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Username\">
                </div>
                <button type=\"button\" id='login' class=\"btn btn-primary block full-width m-b\">RECUPERAR</button>

                <p class=\"text-muted text-center\"><small>¿Aún no estás registrado en el sistema?</small></p>
                <a class=\"btn btn-sm btn-white btn-block\" href=\"registro/\">¡REGISTRATE!</a>
            </form>
        </div>
</div>


";
    }

    // line 26
    public function block_appFooter($context, array $blocks = array())
    {
        // line 27
        echo "    <script src=\"./assets/jscontrollers/login/lostpass.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "lostpass/lostpass.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 27,  58 => 26,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout-404' %}
{% block appBody %}

<div class=\"middle-box text-center loginscreen animated fadeInDown\">
        <div>
            <div>

                <h1 class=\"logo-name\"><img alt=\"image\" src=\"views/propios/img/logo.png\" style=\"width:200px;\" /></h1>

            </div>
            <h3 class=\"login-text\">Bienvenido a Franklin's Gold</h3>
            <form class=\"m-t\" role=\"form\" id=\"login_form\">
                <div class=\"form-group\">
                    <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Username\">
                </div>
                <button type=\"button\" id='login' class=\"btn btn-primary block full-width m-b\">RECUPERAR</button>

                <p class=\"text-muted text-center\"><small>¿Aún no estás registrado en el sistema?</small></p>
                <a class=\"btn btn-sm btn-white btn-block\" href=\"registro/\">¡REGISTRATE!</a>
            </form>
        </div>
</div>


{% endblock %}
{% block appFooter %}
    <script src=\"./assets/jscontrollers/login/lostpass.js\"></script>
{% endblock %}", "lostpass/lostpass.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\lostpass\\lostpass.twig");
    }
}

<?php

/* usuarios/editar.twig */
class __TwigTemplate_7b888e799e06578469905d26369d499858d2d4a77e03c375cfb4afe36ecf711a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"editarUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Usuarios</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"editar_usuario_form\">
                    <input type=\"hidden\" name=\"id_user\" id=\"id_id_user\" value=\"\" />

                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input id=\"id_primer_nombre\" name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input id=\"id_segundo_nombre\" name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input id=\"id_primer_apellido\" name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido <span>*</span></label>
                                <input id=\"id_segundo_apellido\" name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input id=\"id_sexom\" type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input id=\"id_sexof\" type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input id=\"id_tipoa\" type=\"radio\" checked=\"\" value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input id=\"id_tipov\" type=\"radio\" checked=\"\" value=\"1\"  name=\"tipo\"> Vendedor
                                </div>
                            </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Télefono <span>*</span></label>
                                <input id=\"id_telefono\" name=\"telefono\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editar_usuario_0CR3ND\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "usuarios/editar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"editarUsuario\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                <h4 class=\"modal-title\">Edición de Usuarios</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>
            <div class=\"modal-body\">
                <form id=\"editar_usuario_form\">
                    <input type=\"hidden\" name=\"id_user\" id=\"id_id_user\" value=\"\" />

                    <div class=\"row\">
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer nombre <span>*</span></label>
                                <input id=\"id_primer_nombre\" name=\"primer_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo nombre </label>
                                <input id=\"id_segundo_nombre\" name=\"segundo_nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Primer apellido <span>*</span></label>
                                <input id=\"id_primer_apellido\" name=\"primer_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-3 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Segundo apellido <span>*</span></label>
                                <input id=\"id_segundo_apellido\" name=\"segundo_apellido\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"radio\" class=\"control-label mb-1\">Sexo <span>*</span></label>
                                </br>
                                <input id=\"id_sexom\" type=\"radio\" checked=\"\" value=\"m\" name=\"sexo\"> Masculino
                                </br>
                                <input id=\"id_sexof\" type=\"radio\" checked=\"\" value=\"f\"  name=\"sexo\"> Femenino
                            </div>
                        </div>
                        <div class=\"col-md-4 col-xs-12\">
                                <div class=\"form-group\">
                                    <label for=\"radio\" class=\"control-label mb-1\">Tipo usuario<span>*</span></label>
                                    </br>
                                    <input id=\"id_tipoa\" type=\"radio\" checked=\"\" value=\"0\" name=\"tipo\"> Administrador
                                    </br>
                                    <input id=\"id_tipov\" type=\"radio\" checked=\"\" value=\"1\"  name=\"tipo\"> Vendedor
                                </div>
                            </div>
                        <div class=\"col-md-4 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"telefono\" class=\"control-label mb-1\">Télefono <span>*</span></label>
                                <input id=\"id_telefono\" name=\"telefono\" type=\"number\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>                
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass\" class=\"control-label mb-1\">Contraseña <span>*</span></label>
                                <input name=\"pass\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                        <div class=\"col-md-6 col-xs-12\">
                            <div class=\"form-group\">
                                <label for=\"pass2\" class=\"control-label mb-1\">Repetir Contraseña <span>*</span></label>
                                <input name=\"pass2\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>   
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"editar_usuario_0CR3ND\" class=\"btn btn-primary\">Guardar</button>
            </div>
        </div>
    </div>
</div>
", "usuarios/editar.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\usuarios\\editar.twig");
    }
}

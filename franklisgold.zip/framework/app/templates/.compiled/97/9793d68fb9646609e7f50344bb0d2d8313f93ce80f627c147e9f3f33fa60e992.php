<?php

/* origen/crear.twig */
class __TwigTemplate_ff6ba52e00b29972992c9c5e79f907d7c0fcb40f8c33d6a130a6bbe75a2c85c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"modal inmodal\" id=\"crearOrigen\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Creación de origen</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_origen_form\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre
                                    <span>*</span>
                                </label>
                                <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrigenbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "origen/crear.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"modal inmodal\" id=\"crearOrigen\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content animated flipInY\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                    <span aria-hidden=\"true\">&times;</span>
                    <span class=\"sr-only\">Cerrar</span>
                </button>
                <h4 class=\"modal-title\">Creación de origen</h4>
                <small class=\"font-bold\">Franklins Gold</small>
            </div>

            <div class=\"modal-body\">

                <form id=\"crear_origen_form\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <div class=\"form-group\">
                                <label for=\"cc-payment\" class=\"control-label mb-1\">Nombre
                                    <span>*</span>
                                </label>
                                <input name=\"nombre\" type=\"text\" class=\"form-control\" aria-required=\"true\" aria-invalid=\"false\" placeholder=\"\">
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-white\" data-dismiss=\"modal\">Cerrar</button>
                <button type=\"button\" id=\"crearOrigenbtn\" class=\"btn btn-primary\">Crear</button>
            </div>
        </div>
    </div>
</div>", "origen/crear.twig", "C:\\xampp\\htdocs\\franklinsgold\\framework\\app\\templates\\origen\\crear.twig");
    }
}
